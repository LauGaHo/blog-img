module.exports = {
  root: true,
  parser: 'vue-eslint-parser',
  env: {
    node: true,
    es6: true,
    browser: true,
    jquery: true
  },
  rules: {
    // 禁止对象字面量中出现重复的 key
    'no-dupe-keys': 'error',
    // 禁止出现重复的 case 标签
    'no-duplicate-case': 'error',
    // 禁止出现空语句块,允许catch出现空语句
    'no-empty': ['error', { allowEmptyCatch: true }],
    // 禁止对 catch 子句的参数重新赋值
    'no-ex-assign': 'error',
    // 禁止不必要的布尔转换
    'no-extra-boolean-cast': 'error',
    // 禁止不必要的分号
    'no-extra-semi': 'error',
    // 代码缩进
    "indent": ["error", 2]
  },
  parserOptions: {
    ecmaVersion: 2020, // Allows for the parsing of modern ECMAScript features
    sourceType: 'module', // Allows for the use of imports
    ecmaFeatures: {
      jsx: true
    }
  },
  plugins: ['vue'],
  extends: ['plugin:vue/essential', 'eslint:recommended'],
  // 全局变量配置
  globals: {
    '_config': true,
    '_': true
  }
}
