// 各个系统的 api 请求地址配置
window.VUE_APP_SERVERAPI = 'http://api.devcenter.sieiot.com/'
window.VUE_EAM_SERVERAPI = ''
window.VUE_WSAPI=''
// 登录页域名配置
window.VUE_AUTH_API='http://devcenter.gushen.sieiot.com'
window.VUE_CDN_HOST = 'https://cdn.sieiot.com/'
window.VUE_BAIDU_TJ = 'https://hm.baidu.com/hm.js?96e927633c4a5740d1d376df1c5ea2de'
window.VUE_CONNECT_TO_PUBNET = true
window.writeCDNListToDocument = cdnList => {
  document.open()
  cdnList.forEach(cdn => document.writeln(`<script src='${window.VUE_CDN_HOST}${cdn}'><\/script>`))
  document.close()
}
const cdnList = [
  `vue@2.6.14.min.js`,
  `element-ui@2.15.6.min.js`,
  `echarts@4.2.1.min.js`,
  `lodash@4.17.21.min.js`,
]
window.writeCDNListToDocument(cdnList)