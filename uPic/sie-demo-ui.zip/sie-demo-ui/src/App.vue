<template>
  <div id="app">
    <router-view />
    <collect-button v-if="$route.path !== '/login'" />
  </div>
</template>

<script>
import Watermark from '@/utils/watermark'
import CollectButton from '@/views/CollectButton'

export default {
  name: 'App',
  components: {
    CollectButton
  },
  mounted() {
    Watermark.set()
  }
}
</script>

<style lang=scss>
#app {
  height: 100%;
}
</style>
