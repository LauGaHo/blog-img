import request from '@/utils/request'

export function findDicAll() {
  return request({
    url: `/base/dic/find-all`,
    method: 'get'
  })
}

/**
 * 数据字典
 */
export function findDictionaryType(type) {
  return request({
    url: `/dictionary/dic-items/get-dictype?dicType=${type}`,
    method: 'get'
  })
}

/**
 * 租户树
 */
export function findTenantTree(data) {
  return request({
    url: `/api/base/base-tenant/find-tenant-tree`,
    method: 'post',
    data
  })
}

/**
 * 租户树(带分页)
 */
export function findTenantTreeByPage(data) {
  return request({
    url: `/api/base/base-tenant/find-pagination`,
    method: 'post',
    data
  })
}

/**
 * 获取所有租户及二级租户树
 */
export function getAllTenantTree(data) {
  return request({
    url: `/api/base/base-tenant/find-tenants-tree`,
    method: 'post',
    data
  })
}

/**
 * 根据租户id 和 部门id 查找下级部门
 */
export function getDeptById(params) {
  return request({
    url: `/api/base/dept/find-ldept`,
    method: 'get',
    params
  })
}
/**
 * 获取部门树
 */
export function findDeptTree(params) {
  return request({
    url: `/api/base/dept/get-tree`,
    method: 'get',
    params
  })
}

/**
 * 部门列表
 */
export function findDeptList(depDuty, tenantId) {
  return request({
    url: `/api/base/dept/get-tree-all`,
    method: 'get',
    params: {
      ownerFlag: 'Y',
      depDuty,
      tenantId
    }
  })
}

/**
 * 获取当前租户及其下级租户  get
 */
export function getBaseOwnLowTenant() {
  return request({
    url: `/api/base/base-tenant/get-own-low-tenant`,
    method: 'get'
  })
}

/**
 * 根据租户获取所有部门树
 */
export function findDeptListByTenantId(id) {
  return request({
    url: `/api/base/dept/get-tree?ownerFlag=y&tenantId=${id}`,
    method: 'get'
  })
}

/**
 * 根据部门获取所有人员
 */
export function findBaseUserByDept(id) {
  return request({
    url: `/api/base/base-user/find-by-dep?depId=${id}`,
    method: 'post'
  })
}

/**
 * 获取租户下指定部门的用户
 */
export function findPsnUsersByTenant(data) {
  return request({
    url: `/api/base/base-person/find-psn-users`,
    method: 'post',
    data
  })
}

/**
 * 获取所有人员
 */
export function findAllBaseUser(data) {
  return request({
    url: `/api/base/base-user/find-pagination`,
    method: 'post',
    data
  })
}

/**
 * 根据当前登录租户查询人员
 */
export function findUserByTenant() {
  return request({
    url: `/api/base/base-user/find-by-tenant`,
    method: 'get'
  })
}

/**
 * 根据租户ID查询人员
 */
export function findUserByTenantId(params) {
  return request({
    url: `/api/base/base-user/find-users-by-tenant`,
    method: 'get',
    params
  })
}

/**
 * 当获取前租户所在集团的所有租户及子租户的部门
 */
export function findDeptByTenant(data) {
  return request({
    url: `/api/base/dept/find-dept-tenant`,
    method: 'post',
    data
  })
}

/**
 * 分页查询当前用户的部门数据权限
 */
export function findDeptByUserPermiss(data) {
  return request({
    url: `/equipledger/user-data-permissions/find-pagination-dept`,
    method: 'post',
    data
  })
}

/**
 * 获取部门所有数据
 */

export function findPermissionDept() {
  return request({
    url: `/equipledger/user-data-permissions/get-dept-tree`,
    method: 'get'
  })
}

/**
 * 首页用户访问总数
 */
export function getLoginTotal(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/list/gushen/login-total7`,
    method: 'post',
    data
  })
}

/**
 * 首页用户浏览总数
 */
export function getBehaviorTotal() {
  return request({
    url: `/log/base-behavior/behavior-total7`,
    method: 'get',

  })
}

/**
 * 设置默认菜单页面
 */
export function defaultMenuSave(data) {
  return request({
    url: `/api/base/base-default-menu/save`,
    method: 'post',
    data
  })
}

/**
 * 修改用户账号密码
 */
export function updateUserPsw(data) {
  return request({
    url: `/api/base/base-user/update-pwd`,
    method: 'post',
    data
  })
}

/**
 * sso登录
 */
 export function getBaseUserLoginSso() {
  return request({
      url: `/api/base/base-user/get-login-user`,
      method: 'get'
  })
}

/**
* sso根据portalCode 获取token
*/
export function getTokenByPortalCode(params) {
  return request({
      url: `/api/base/sso/token?${params}`,
      method: 'get'
  })
}