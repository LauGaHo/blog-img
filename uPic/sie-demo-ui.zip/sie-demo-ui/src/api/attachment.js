
import request from '@/utils/request'

/**
 * 查询图片-附件信息
 * @param {*} data 
 * data.businessId 关联主表id
 * data.businessTableName 关联主表名
 */
export function queryAttachmentInfo(data) {
  return request({
    url: `/api/file/iot-base-attachment/query-attachment-info`,
    method: 'post',
    data
  })
}

//根据ID删除图片
export function deleteAttachmentById(id) {
  return request({
    url: `/api/file/iot-base-attachment/delete-id?id=${id}`,
    method: 'get',
  })
}


//上传附件 图片
export function uploadAttachment(file) {
  return new Promise(resolve => {
    let form = new FormData();
    form.append("file", file, file.name);
    let config = {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "multipart/form-data"
      }
    };
    request.post(`/api/file/iot-base-attachment/single/file-upload`, form, config).then(response => {
      resolve(response);
    });
  });
}
//运行管理导入
export function uploadMenage(file) {
  return new Promise(resolve => {
    let form = new FormData();
    form.append("file", file, file.name);
    let config = {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "multipart/form-data"
      }
    };
    request.post(`/api/base/common-runrecord/rec-import`, form, config).then(response => {
      resolve(response);
    });
  });
}
