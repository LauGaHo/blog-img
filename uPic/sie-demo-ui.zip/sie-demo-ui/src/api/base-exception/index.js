import request from '@/utils/request'

// 保存一条反馈
export function saveException(data) {
  return request({
    url: `/api/base/base-exception/save`,
    method: 'post',
    data
  })
}

// 删除某一条意见反馈
export function deleteException(id) {
  return request({
    url: `/api/base/base-exception/delete-id?id=${id}`,
    method: 'get'
  })
}

// 更新某一条意见反馈
export function updateException(data) {
  return request({
    url: `/api/base/base-exception/update`,
    method: 'post',
    data
  })
}

//意见反馈列表
export function getException(data) {
  return request({
    url: `/api/base/base-exception/find-pagination`,
    method: 'post',
    data
  })
}

// 获取某一条意见反馈的具体信息
export function getExceptionDetail(id) {
  return request({
    url: `/api/base/base-exception/get-Id?id=${id}`,
    method: 'get'
  })
}

// 回复详情
export function getExceptionReplyDetail(id) {
  return request({
    url: `/api/base/base-exception-reply/get-Id?id=${id}`,
    method: 'get'
  })
}

// 回复列表
export function getExceptionReply(data) {
  return request({
    url: `/api/base/base-exception-reply/find-pagination`,
    method: 'post',
    data
  })
}

// 保存回复
export function saveExceptionReply(data) {
  return request({
    url: `/api/base/base-exception-reply/save`,
    method: 'post',
    data
  })
}

// 删除回复
export function deleteExceptionReply(id) {
  return request({
    url: `/api/base/base-exception-reply/delete-id?id=${id}`,
    method: 'get'
  })
}

// 更新回复
export function updateExceptionReply(data) {
  return request({
    url: `/api/base/base-exception-reply/update`,
    method: 'post',
    data
  })
}
