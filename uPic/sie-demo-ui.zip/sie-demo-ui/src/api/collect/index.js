import request from '@/utils/request'

/**
 * 查询是否收藏了
 */
export function checkIsCollect(params) {
  let data = {
    params
  }
  return request({
    url: `/api/base/portal-favourite/find-user-menu`,
    method: 'post',
    data
  })
}
/**
 * 收藏
 */
export function setCollect(params) {
  let data = {
    params
  }
  return request({
    url: `/api/base/portal-favourite/save-one-click`,
    method: 'post',
    data
  })
}
/**
 * 删除收藏
 */
export function deleteCollectById(id) {
  return request({
    url: `/api/base/portal-favourite/delete-id?id=${id}`,
    method: 'get'
  })
}
