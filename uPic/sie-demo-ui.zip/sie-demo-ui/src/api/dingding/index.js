import request from '@/utils/request'

// export function getTenantTotal(data = {}) {
//   return request({
//     url: '/dyapi/baseDynamicApiController/one/tenant-total',
//     method: 'post',
//     data
//   })
// }

export function dingdingLogin(code, corpId) {
  return request({
    url: `/api/base/auth-dingtalk-login/login?code=${code}&corpId=${corpId}`,
    method: "get"
  })
}