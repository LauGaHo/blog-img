
import request from '@/utils/request'

export function dataExport(data) {
    return request({
        url: '/dataexport/dataExportController/export',
        method: 'post',
        data
    })
}
export function getExportResult(data) {
    return request({
        url: '/dataexport/dataExportController/get-export-result',
        method: 'post',
        data
    })
}

export function getExportDataRecord(data) {
    return request({
        url: '/dataexport/export-data-record/find-pagination',
        method: 'post',
        data
    })
}
