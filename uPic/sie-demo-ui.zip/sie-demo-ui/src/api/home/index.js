import request from '@/utils/request'
import { toFormData } from '@/utils'
import _config from '@/config'
/**
 * 查询待办列表
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findTodoTasks({ params = {}, pageIndex = 1, pageRows = 5 }) {
  return request.post(`/bpm/bpmTaskService/findTodoTasks`, toFormData({ params, pageIndex, pageRows }))
}
//未阅
export function findNotifyTasks({ params = {}, pageIndex = 1, pageRows = 5 }) {
  return request.post(`/bpm/bpmNotifyTaskService/findNotifyTasks`, toFormData({ params, pageIndex, pageRows }))
}
//我的流程
export function findBpmLists({ params = {}, pageIndex = 1, pageRows = 5 }) {
  return request.post(`/bpm/bpmListService/findBpmLists`, toFormData({ params, pageIndex, pageRows }))
}

export function getRoleMenuByKeyWord(queryString) {
  return request({
    url: `/api/base/base-rolemenu/get-keyword?keyword=${queryString}`,
    method: 'get'
  })
}

export function getRoleMenuByKeyWordAndSysCode(queryString) {
  // console.log('sideBar')
  return request({
    url: `/api/base/base-rolemenu/get-keyword?keyword=${queryString}&systemCode=${_config.systemCode}`,
    method: 'get'
  })
}

export function baseUserChangeTenant(tenantId) {
  return request({
    url: `/api/base/base-user/change-tenant?tenantId=${tenantId}&systemCode=${_config.systemCode}`,
    method: 'post'
  })
}

export function baseTenantFindUserTenants() {
  return request({
    url: `/api/base/base-tenant/find-user-tenants`,
    method: 'post'
  })
}

export function gsearchKnowledgeFindPagin(data) {
  return request({
    url: `/gsearch/knowledge-es/find-pagination`,
    method: 'post',
    data
  })
}

export function gsearchKnowledgeById(id, t) {
  return request({
    url: `/gsearch/knowledge-es/get-by-id`,
    method: 'get',
    params: { id, t }
  })
}
export function findCatalogKnowledge() {
  return request({
    url: `/gsearch/knowledge-es/find-catalog`,
    method: 'get'
  })
}

export function setDefaultSystem(systemCode) {
  return request({
    url: `/api/base/base-system/default-system?systemCode=${systemCode}`,
    method: 'get'
  })
}

// 获取用户最新布局
// export function getLastestLayout(systemCode) {
//   return request({
//     url: '/api/base/panel-user-instance/get-by-systemCode',
//     method: 'get',
//     params: {
//       systemCode
//     }
//   })
// }


// 获取组件面板列表
export function getPanelList(data) {
  return request({
    url: '/api/base/panel-model/find-pagination',
    method: 'post',
    data
  })
}

// 获取用户最新布局
export function getUserLayout(systemCode, roleId) {
  return request({
    url: `/api/base/panel-user-instance/get-by-systemCode?systemCode=${systemCode}&roleId=${roleId}`,
    method: 'get'
  })
}

// 更新用户布局
export function updateUserLayout(data) {
  return request({
    url: '/api/base/panel-user-instance/update',
    method: 'post',
    data
  })
}

