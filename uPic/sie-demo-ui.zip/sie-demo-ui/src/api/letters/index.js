import request from '@/utils/request'

// 获取未读消息类型统计
export function getMessageCount(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/pagination/unread-message-total`,
    method: 'post',
    data
  })
}

//消息删除
export function deleteMessageById(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/delete/message-delete`,
    method: 'post',
    data
  })
}

// 未读消息数量
export function unreadMessageTotal(data) {
  return request({
    url: `/iot-message/iotBaseMessageLogController/unread-message-total`,
    method: 'post',
    data
  })
}

//消息分页
export function getMessageList(data) {
  return request({
    url: `/iot-message/iotBaseMessageLogController/message-find`,
    method: 'post',
    data
  })
}



//消息详情
export function getMessageDetail(params) {
  return request({
    url: `/iot-message/base-message/get-Id`,
    method: 'get',
    params
  })
}

//更新消息状态为已读
export function updateMessageStatus(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/update/message-update`,
    method: 'post',
    data
  })
}

//功能帮助中心
export function HcPageControllerFindPageinfo(data) {
  return request({
    url: `/hc/hcPageController/find-pageinfo`,
    method: 'post',
    data
  })
}

/**
 * @description: 批量删除消息中心站内信息
 * @param {Object} data
 * @param {Array<String>} msgInstanceIds 消息id集合
 * @return {*}
 */
 export function messageDelete(data) {
  return request({
    url: `/iot-message/iotBaseMessageLogController/message-delete`,
    method: 'post',
    data
  })
}

/**
 * @description: 批量已读站内信息
 * @param {Object} data
 * @param {Array<String>} systemCodes 系统编码合集
 * @param {Array<String>} msgInstanceIds 消息id集合
 * @return {*}
 */
export function messageRead(data) {
  return request({
    url: `/iot-message/iotBaseMessageLogController/read`,
    method: 'post',
    data
  })
}