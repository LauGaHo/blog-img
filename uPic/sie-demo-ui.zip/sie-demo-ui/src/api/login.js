import request from '@/utils/request'

export function login(username, password) {
  return request({
    url:`/api/base/base-user/login`,
    method: 'post',
    data: {
      params: {
        requestData: {
          username,
          password,
          loginFrom: "PC",
          systemCode: _config.systemCode
        }
      }
    }
  })
}

export function autoLogin(systemCode) {
  return request({
    url: `/api/base/base-user/going-system?loginFrom=PC&systemCode=${systemCode}`,
    method: 'post',
  })
}

export function findTenantDefind(params) {
  return request({
    url: `/api/base/base-tenant-system/find-tenant-defined`,
    method: 'get',
    params
  })
}

export function logout() {
  return request({
    url: `/api/base/base-user/logout`,
    method: 'get'
  })
}

export function getInfo(token) {
  return request({
    url: '/api/account',
    method: 'get',
    params: { token }
  })
}
