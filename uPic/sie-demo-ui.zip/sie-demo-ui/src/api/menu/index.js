import _config from '@/config'
import request from '@/utils/request'

export function fetchMenu() {
  return request({
    url: '/api/base/base-menu/find-menutree?systemCode=iot',
    method: 'get'
  })
}

// 获取快捷入口菜单
export function getFetchMenu(data) {
  return request({
    url: '/api/base/base-menu-fetch/find-list',
    method: 'post',
    data
  })
}
//获取菜单按钮权限
export const getButtonAuth = menuId => {
  return request({
    url: `api/base/resource/find-resource?menuId=${menuId}`,
    method: 'get'
  })
}
//获取导入模板
export const getImportTemplate = menuId => {
  let data = {
    params: {
      menuId,
      systemCode: _config.systemCode
    }
  }
  return request({
    url: `api/base/base-template/find-system-function`,
    method: 'post',
    data
  })
}

/**
 * 下载
 * @param {*} data
 * data.systemCode 系统编码
 * data.functionName 功能名称
 */
export const downloadImportList = data => {
  return request({
    url: `/api/base/base-template/download`,
    method: 'post',
    data
  })
}

/**
 * 获取功能页面导入模板权限
 * @param {*} menuCode
 * @param {*} pageOrder
 * @returns
 */
export const getImportMenuCode = (menuCode, pageOrder) => {
  return request({
    url: `/dataimport/import-header/get-menu-code?menuCode=${menuCode}&pageOrder=${pageOrder}`,
    method: 'get'
  })
}
