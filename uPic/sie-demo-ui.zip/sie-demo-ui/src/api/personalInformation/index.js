import request from '@/utils/request'

export function updateAvatar(url, fileId) {
  console.log(url, fileId)
  return request({
    url: `api/base/base-user/update-avatar?imgUrl=${url}&fileId=${fileId}`,
    method: 'post'
  })
}