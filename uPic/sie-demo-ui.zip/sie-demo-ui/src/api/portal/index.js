import request from '@/utils/request';

// 用户组织列表
export function findUserTenants() {
  return request({
    url: '/api/base/base-tenant/find-user-tenants',
    method: 'post'
  })
}

// 切换组织
export function changeTenants(data) {
  return request({
    url: `/api/base/base-user/change-tenant?tenantId=${data.tenantId}&systemCode=${data.systemCode}`,
    method: 'post'
  })
}

// 收藏列表
export function portalFavourite(data) {
  return request({
    url: '/api/base/portal-favourite/find-pagination',
    method: 'post',
    data
  })
}

// 通知提醒
export function findTodoList(data) {
  return request({
    url: '/bpm/bpmTaskService/findTodoTasks',
    method: 'post',
    data
  })
}

// 工单执行情况统计图表
export function findWorkorderComplete(data) {
  return request({
    url: '/eam-report/report-workorder/find-workorder-complete',
    method: 'post',
    data
  })
}

// 设备完好率分月统计图表
export function findIntactTotal(data) {
  return request({
    url: '/eam-report/report-asset/find-intact-total',
    method: 'post',
    data
  })
}

// 设备故障率分月统计图表
export function findFaultTotal(data) {
  return request({
    url: '/eam-report/report-asset/find-fault-total',
    method: 'post',
    data
  })
}
// 设备MTBF&MTTR分月统计图表
export function findMtbfMttrTotal(data) {
  return request({
    url: 'eam-report/report-asset/find-mtbf-mttr-total',
    method: 'post',
    data
  })
}

// 设备状态按资产类别分类统计图表
export function findClassifyStatusTotal(data) {
  return request({
    url: '/eam-report/report-asset/find-classify-status-total',
    method: 'post',
    data
  })
}

// 设备状态按重要性分类统计图表
export function findPositionStatusTotal(data) {
  return request({
    url: '/eam-report/report-asset/find-position-status-total',
    method: 'post',
    data
  })
}

export function findListByLoginUser() {
  return request({
    url: `/api/base/page-content/find-list-by-loginUser`,
    method: 'get'
  })
}