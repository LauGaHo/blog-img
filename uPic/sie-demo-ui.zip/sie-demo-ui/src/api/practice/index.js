import request from '@/utils/request'

export function deleteInfo(id) {
    return request({
        url: `/api/other/dept-shenzhou/delete?id=${id}`,
        method: 'get',
    })
}

export function saveInfo(data) {
    return request({
        url: `/api/other/dept-shenzhou/save`,
        method: 'post',
        data
    })
}

export function updateInfo(data) {
    return request({
        url: `/api/other/dept-shenzhou/update`,
        method: 'post',
        data
    })
}

export function findInfoList(data) {
    return request({
        url: `/api/other/dept-shenzhou/find-pagination`,
        method: 'post',
        data
    })
}