import request from '@/utils/request'

export function resetPassword(data) {
  return request({
    // url:'/api/noauth/resetUserPassword',
    url: `/api/base/base-pa/pwd-find?phone=${data.phone}&numberCaptcha=${data.numberCaptcha}&newMagic=${data.newMagic}&confirmMagic=${data.confirmMagic}`,
    method: "post"
  })
}

export function sendCode(data) {
  return request({
    url: `/api/base/base-pa/sms-send?phone=${data.phone}&type=${data.type}&imageCaptcha=${data.imageCaptcha}`,
    method: 'post'
  })
}
