import request from '@/utils/request'

/**
 * 主表列表
 * @param {*} data
 * @returns
 */
export function findImportHeaderData(data) {
  return request({
    url: `/dataimport/import-header/find-pagination`,
    method: 'post',
    data
  })
}

export function saveImportData(data) {
  return request({
    url: `/dataimport/import-header/save`,
    method: 'post',
    data
  })
}

export function getImportDataById(params) {
  return request({
    url: `/dataimport/import-header/get-Id`,
    method: 'get',
    params
  })
}

export function updateImportData(data) {
  return request({
    url: `/dataimport/import-header/update`,
    method: 'post',
    data
  })
}

export function deleteImportData(params) {
  return request({
    url: `/dataimport/import-header/delete-id`,
    method: 'get',
    params
  })
}

/**
 * 删除
 * @param {*} id
 * @returns
 */
export function deleteImportHeaderById(id) {
  return request({
    url: `/dataimport/import-header/delete-id?id=${id}`,
    method: 'get'
  })
}

export function importHeaderData(file, importId) {
  return new Promise(resolve => {
    let form = new FormData()
    form.append('file', file)
    form.append('importId', importId)
    let config = {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'multipart/form-data'
      }
    }
    request.post(`/dataimport/import-header/import-data`, form, config).then(response => {
      resolve(response)
    })
  })
}

/**
 * 获取菜单api信息
 * @param menuId
 */
export const getImportMenuApi = menuId => request.get(`/api/base/base-menu-api/menu-api/${menuId}`)

/**
 * 生成导入模板
 * @param params
 */
export const postImportTelConfig = params => request.post(`/dataimport/import-header/autoCreateTel`, params)
