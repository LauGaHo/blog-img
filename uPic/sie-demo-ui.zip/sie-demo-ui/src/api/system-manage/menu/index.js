import request from '@/utils/request'

export function getPic(params) {
  return request({
    url: "api/base/base-menu/get-id",
    method: "get",
    params,
  })
}

export function updateMenu(data) {
  return request({
    url: "api/base/base-menu/update",
    method: "post",
    data
  })
}

export function addMenu(data) {
  return request({
    url: "api/base/base-menu/add-menu",
    method: "post",
    data
  })
}

export function deleteMenu(menuId) {
  return request({
    url: `api/base/base-menu/delete?menuId=${menuId}`,
    method: "post",
    data: {}
  })
}

export function getTree(data) {
  return request({
    url: 'api/base/base-menu/find-all-menutree',
    method: "post",
    data
  })
}

export function findDic() {
  return request({
    url: "dictionary/dic/find-dicid?dicId=14",
    method: 'get',
    params: {}
  })
}

export function findAssignedMenuList(params) {
  return request({
    url: "api/base/base-tenant-menu/find-tenant-menu-checked",
    method: "get",
    params,
  })
}

export function getSystemList(params) {
  return request({
    url: "api/base/base-tenant-system/find-tenant-system",
    method: "get",
    params,
  })
}


export function findSystemChecked(data) {
  return request({
    url: "/api/base/base-tenant-system/find-system-checked",
    method: "post",
    data,
  })
}

export function getResource(params) {
  return request({
    url: "/api/base/resource/get-by-menuId",
    method: "get",
    params
  })
}

export function getResourceList(params) {
  return request({
    url: `/api/base/resource/get-resource-by-menuId`,
    method: "get",
    params
  })
}

export function getAllButtons(data) {
  return request({
    url: "/api/base/button/find-pagination",
    method: "post",
    data
  })
}

export function submit(act, data) {
  return request({
    url: `/api/base/resource/${act}`,
    method: "post",
    data,
  })
}

export function deleteButton(params) {
  return request({
    url: "/api/base/resource/delete-id",
    method: "get",
    params
  })
}
//水印保存
export function WaterMarkformsave(data) {
  return request({
    url: `/api/file/iotBaseFuncWaterController/save`,
    method: "post",
    data
  })
}
//水印详情
export function WaterMarkformgetId(ffwFunctionCode) {
  return request({
    url: `/api/file/iotBaseFuncWaterController/get-Id?ffwFunctionCode=${ffwFunctionCode}`,
    method: "get",
  })
}

//水印修改
export function WaterMarkformUpdate(data) {
  return request({
    url: `/api/file/iotBaseFuncWaterController/update`,
    method: "post",
    data

  })
}
//水印删除
export function WaterMarkformDelete(id) {
  return request({
    url: `/api/file/iotBaseFuncWaterController/delete-id?id=${id}`,
    method: "get",


  })
}

//菜单水印预览 pdf
//http://10.10.3.195:9020
export function WaterMarkformyulanpdf(data) {
  return request({
    url: `/api/file/iot-base-attachment/previewFile`,
    method: "post",
    data


  })
}
//获取最近租户的水印
//http://10.10.3.195:9020
export function getlatelywatermark(ffwFunctionCode) {
  return request({
    url: `/api/file/iotBaseFuncWaterController/get-lately-watermark?ffwFunctionCode=${ffwFunctionCode}&ffwPoint=${'review'}`,
    method: "get",


  })
}
// 获取系统列表数据
export function getSystemModuleList(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/pagination/query_sieiot_gushen_iot_base_system_model_SIE`,
    method: "post",
    data
  })
}
// 获取模块分配模块
export function getModuleList(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/pagination/query_sieiot_gushen_iot_base_menu_system_model_SIE`,
    method: "post",
    data
  })
}
// 新增模块分配数据
export function insertModuleList(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/save/insert_sieiot_gushen_iot_base_menu_system_model_SIE`,
    method: "post",
    data
  })
}
// 删除模块分配数据
export function deleteModuleList(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/delete/delete_sieiot_gushen_iot_base_menu_system_model_SIE`,
    method: "post",
    data
  })
}
/**
 * @description: 保存数据归档设置
 * @param {*}
 * @return {*}
 */
export function dataArchivingSave(data) {
  return request({
    url: `/api/base/base-data-archiving/save`,
    method: "post",
    data


  })
}

/**
 * 获取api options
 * @param menuId
 */
export const getExportApiOptions = (menuId) => request.get(`api/base/base-menu-api/menu-api/${menuId}`)

/**
 * @description: 保存新增api信息
 * @param {*}
 * @return {*}
 */
export function apiAddSave(data) {
  return request({
    url: `/api/base/base-menu-api/menu-bind-api`,
    method: "post",
    data
  })
}
//获取最近租户的水印
//http://10.10.3.195:9020
export function getsystemwatermark(systemCode,flag,tenantId) {
  // flag：1-系统维护详情接口  2-租户系统详情接口
  return request({
    url: `/api/file/iotBaseFuncWaterController/get-system-watermark?ffwFunctionCode=${systemCode}&flag=${flag}&tenantId=${tenantId}`,
    method: "get",


  })
}
//获取最近租户的水印
//http://10.10.3.195:9020
export function getpdfwatermark(url,funcCode) {
  // flag：1-系统维护详情接口  2-租户系统详情接口
  return request({
    url: `/api/file/iot-base-attachment/previewFile-base64?url=${url}&funcCode=${funcCode}`,
    method: "get",
    responseType: 'blob',


  })
}
// api/file/iot-base-attachment/previewFile-base64?authorization=${getToken()}&


