import request from '@/utils/request'

export function getSystemListByUser() {
  return request({
    url: '/api/base/base-tenant-system/find-user-system',
    method: 'post',
    data: {}
  })
}
