import request from '@/utils/request'

/**
 *
 * @param {*} data
 * @returns 获取table数据
 */
export function getDataList(data) {
  return request({
    url: `/dyapi/baseDynamicApiController/pagination/find-login-log-zou`,
    method: 'post',
    data
  })
}
