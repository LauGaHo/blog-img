import request from '@/utils/request'

/**
 * 获取table数据
 * @param {*} data 
 * @returns 
 */
export function getDataList(data) {
    return request({
        url: `/api/demoa/test-leave/find-pagination`,
        method: 'post',
        data
    })
}


/**
 * 保存
 * @param {*} data 
 * @returns 
 */
export function save(data) {
    return request({
        url: `/api/demoa/test-leave/save`,
        method: 'post',
        data
    })
}

/**
 * 修改
 * @param {*} data 
 * @returns 
 */
export function update(data) {
    return request({
        url: `/api/demoa/test-leave/update`,
        method: 'post',
        data
    })
}

/**
 * 保存
 * @param {*} data 
 * @returns 
 */
export function getObj(id) {
    return request({
        url: `/api/demoa/test-leave/get-Id?id=${id}`,
        method: 'get',
    })
}