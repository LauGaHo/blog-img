import request from '@/utils/request'

/**
 * 获取table数据
 * @param {*} data 
 * @returns 
 */
export function getDataList(data) {
    return request({
        url: `/api/demoa/testMetadataController/find-pagination`,
        method: 'post',
        data
    })
}


/**
 * 保存
 * @param {*} data 
 * @returns 
 */
export function save(data) {
    return request({
        url: `/api/demoa/testMetadataController/save`,
        method: 'post',
        data
    })
}

/**
 * 修改
 * @param {*} data 
 * @returns 
 */
export function update(data) {
    return request({
        url: `/api/demoa/testMetadataController/update`,
        method: 'post',
        data
    })
}

/**
 * get
 * @param {*} data 
 * @returns 
 */
export function getObj(id) {
    return request({
        url: `/api/demoa/testMetadataController/get-Id?id=${id}`,
        method: 'get',
    })
}


/**
 * 删除
 * @param {*} data 
 * @returns 
 */
export function deleteDemoa(id) {
    return request({
        url: `/api/demoa/testMetadataController/delete-id?id=${id}`,
        method: 'get',
    })
}