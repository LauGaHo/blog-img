import request from '@/utils/request'
//上传附件 图片
export function uploadAttachment(file, menuId) {
  let ismenuId = menuId || ''
  return new Promise(resolve => {
    let form = new FormData()
    form.append('file', file, file.name)
    let config = {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'multipart/form-data'
      }
    }
    if (ismenuId !== '') 
    {request.post(`/api/file/iot-base-attachment/single/file-upload?funcCode=${menuId}`, form, config).then(response => {
      resolve(response)
    })}
    else 
    {request.post(`/api/file/iot-base-attachment/single/file-upload`, form, config).then(response => {
      let resFile = { ...response }
      if (menuId) 
      {attachmentgetUrl(response.data.filePath).then(res => {
        if (res.code === 200 || res.code === 800) {
          resFile.data.filePath = res.data
          resolve(resFile)
        }
      })}
      else 
      {resolve(response)}
        
    })}
    
  })
}

//根据ID删除文件
export function deleteAttachmentById(id) {
  return request.get(`/api/file/iot-base-attachment/delete-id?id=${id}`)
}
//解密url
export function attachmentgetUrl(url) {
  return request.get(`/api/file/iot-base-attachment/getUrl?url=${url}`)
}
