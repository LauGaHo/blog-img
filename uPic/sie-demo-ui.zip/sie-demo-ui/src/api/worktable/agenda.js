import request from '@/utils/request'
import { toFormData, urlencode } from '@/utils'
/**
 * 查询待办列表
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findTodoTasks({ params = {}, pageIndex = 1, pageRows = 15 }) {
  return request({
    url: '/bpm/bpmTaskService/findTodoTasks',
    method: 'post',
    data: toFormData({
      params,
      pageIndex,
      pageRows
    })
  })
}
/**
 * 获取审批人历史
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findHistoricActivities({ params = {}, pageIndex = 1, pageRows = 10 }) {
  return request({
    url: '/bpm/bpmHistoryService/findHistoricActivities',
    method: 'post',
    data: toFormData({
      params,
      pageIndex,
      pageRows
    })
  })
}
/**
 * 查询快速回复下拉
 */
export function findHistoricOpinions(data) {
  return request({
    url: '/bpm/bpmHistoryService/findHistoricOpinions',
    method: 'post',
    data: data
    // data: toFormData({ params, pageIndex, pageRows })
  })
}
/**
 * 审批
 * @param params
 */
export function batchComplete(data) {
  return request({
    url: `/bpm/bpmTaskService/batchComplete?params=${urlencode(data)}`,
    method: 'post'
    // data
  })
}

/**
 * 审批通过
 * @params params
 */
export function completePass({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskService/complete',
    method: 'post',
    data: toFormData({
      params
    })
  })
}
/**
 * 获取发起人节点
 * @params params
 */
export function findTaskNodes({ params = {} }) {
  return request({
    url: '/bpm/bpmHistoryService/findTaskNodes',
    method: 'post',
    data: toFormData({
      params
    })
  })
}
/**
 * 获取下一个节点
 * @params params
 */
export function findAssigneeUserTasks({ params = {} }) {
  return request({
    url: '/bpm/bpmProcessService/findAssigneeUserTasks',
    method: 'post',
    data: toFormData({
      params
    })
  })
}
/**
 * 获取权限系统中设置的url
 * @params params
 */
export function getServiceUrl({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskConfigService/get-form',
    method: 'post',
    data: toFormData({
      params
    })
  })
}
/**
 * 获取权限系统中设置的url
 * @params params
 */
export function addSubTask({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskService/addSubTask',
    method: 'post',
    data: toFormData({
      params
    })
  })
}
/**
 * 获取助审人列表
 * @params params
 */
export function findAllInfoOnlyOnePosition(data) {
  return request({
    url: '/api/base/base-person/find-pagination-person',
    method: 'post',
    data
  })
}
/**
 * 获取流程图json
 * @params params
 */
export function getGooflowProcessJSON({ params = {} }) {
  return request({
    url: '/bpm/bpmProcessService/getGooflowProcessJSON',
    method: 'post',
    data: toFormData({
      params
    })
  })
}
/**
 * 获取计算审批人
 * @param params
 */
export function findTaskAllassigns(data) {
  return request({
    url: `/bpm/bpmTaskConfigService/findTaskAllassigns?params=${urlencode(data)}`,
    method: 'post'
    // data
  })
}

/**
 * 流程保存评论
 */
export function saveComment(data) {
  return request({
    url: `/bpm/bpm-comment/save`,
    method: 'post',
    data
  })
}

/**
 * 流程保存评论极光推送到app
 */
export function pushComment(data) {
  return request({
    url: `/bpm/bpm-comment/push`,
    method: 'post',
    data
  })
}

//上传附件 图片
export function fileUploadAttachment(file) {
  return new Promise(resolve => {
    let form = new FormData()
    form.append('file', file, file.name)
    let config = {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'multipart/form-data'
      }
    }
    request.post(`/api/file/iot-base-attachment/single/file-upload`, form, config).then(response => {
      resolve(response)
    })
  })
}

//获取任务节点下拉
export const findActiveTasks = data => {
  return request({
    url: `bpm/bpmTaskService/findActiveTasks?params=${urlencode(data.params)}`,
    method: 'post',
    data
  })
}
//获取任务节点下拉
export const transfer = data => {
  return request({
    url: `bpm/bpmTaskService/transfer?params=${urlencode(data.params)}`,
    method: 'post',
    data
  })
}

/**
 * @description: 查询流程状态
 * @param {*}
 * @return {*}
 */
export function getProcessStatus({ params = {} }) {
  return request({
    url: '/bpm/bpmProcessService/getProcessStatus',
    method: 'post',
    data: toFormData({ params })
  })
}

/**
 * @description: 查询流程申请单
 * @param {*}
 * @return {*}
 */
export function getProcessData({ params = {} }) {
  return request({
    url: '/bpm/bpmListService/get',
    method: 'post',
    data: toFormData({ params })
  })
}

export const getProcessDetail = id =>
  request({
    url: `/bpmTaskService/get?id=${id}`,
    method: 'get'
  })

/**
 * 获取审批节点状态
 * @param params
 * @returns {AxiosPromise}
 */
export const getBpmTaskService = params => {
  console.log('参数', params)
  request({ url: '/bpm/bpmTaskService/get', method: 'post', data: toFormData(params) })
}
