import request from '@/utils/request'
import { toFormData } from '@/utils'
/**
 * 查询已审批列表
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findHistoricTasks({ params = {}, pageIndex, pageRows = 10 }) {
  return request({
    url: '/bpm/bpmHistoryService/findHistoricTasks',
    method: 'post',
    data: toFormData({ params, pageIndex, pageRows })
  })
}
//撤回
export function revoke({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskService/eamRevoke',
    // url: '/bpm/bpmTaskService/revoke',
    method: 'post',
    data: toFormData({ params })
  })
}
//是否可撤回
export function getRevokeStatus({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskService/getRevokeStatus',
    method: 'post',
    data: toFormData({ params })
  })
}
