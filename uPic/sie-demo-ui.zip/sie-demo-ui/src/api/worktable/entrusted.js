import request from '@/utils/request'
import { toFormData, urlencode } from '@/utils'

/**
 * 获取我的委托
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findDelegateConfig({ params = {}, pageIndex, pageRows = 10 }) {
  return request({
    url: '/bpm/bpmTaskDelegateConfigService/findDelegateConfig',
    method: 'post',
    data: toFormData({
      params,
      pageIndex,
      pageRows
    })
  })
}

/**
 * 获取我的委托
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findCategories({ params = {}, pageIndex = 1, pageRows = 10000 }) {
  return request({
    url: '/bpm/bpmCategoryService/findCategories',
    method: 'post',
    data: toFormData({
      params,
      pageIndex,
      pageRows
    })
  })
}

/**
 * 保存新增、编辑
 * @param params
 */
export function saveDelegate({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskDelegateConfigService/save',
    method: 'post',
    data: toFormData({
      params
    })
  })
}

/**
 * 删除列表
 * @param params
 */
export function deleteDelegate({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskDelegateConfigService/delete',
    method: 'post',
    data: toFormData({
      params
    })
  })
}

/**
 * 失效
 * @param params
 */
export function updateStatus({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskDelegateConfigService/updateStatus',
    method: 'post',
    data: toFormData({
      params
    })
  })
}

/**
 * 租户列表
 */
export const findCurrentUserTenants = params =>
  request({
    url: '/bpm/bpmUserService/findCurrentUserTenants ',
    method: 'post',
    data: toFormData({
      params
    })
  })
