import request from '@/utils/request'
import { toFormData } from '@/utils'
/**
 * 查询我的流程列表
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findBpmLists({ params = {}, pageIndex = 1, pageRows = 10 }) {
  return request({
    url: '/bpm/bpmListService/findBpmLists',
    method: 'post',
    params: { params, pageIndex, pageRows }
  })
}
/**
 * 获取催办人员列表下拉
 * @param params
 */
export function findActiveTasks({ params = {} }) {
  return request({
    url: '/bpm/bpmTaskService/findActiveTasks',
    method: 'post',
    data: toFormData({ params })
  })
}
/**
 * 催办
 * @param params
 */
export function findActivePress({ params = {} }) {
  return request({
    url: '/bpm/bpmCommunicateService/save',
    method: 'post',
    data: toFormData({ params })
  })
}
/**
 * 终止
 * @param params
 */
export function stopFlow({ params = {} }) {
  return request({
    url: '/bpm/bpmProcessService/stop',
    method: 'post',
    data: toFormData({ params })
  })
}
