import request from '@/utils/request'
import { urlencode } from '@/utils'
// 获取表单接口
export function getFormList(data) {
  return request({
    url: '/workorder/api/act-commit-demo/find-pagination',
    method: 'post',
    data
  })
}
// 删除
export function deleteFormList(id) {
  return request({
    url: `/workorder/api/act-commit-demo/delete-id?id=${id}`,
    method: 'get'
  })
}
// 新增
export function addFormList(data) {
  return request({
    url: '/workorder/api/act-commit-demo/save',
    method: 'post',
    data
  })
}
// 先要获取流程引擎的模型是否已被创建完毕，返回值成功才可进入添加界面
export function bpmTaskService(data) {
  return request({
    url: `bpm/bpmTaskService/get?params=${urlencode(data)}`,
    method: 'post'
    // data
  })
}
// 提交流程引擎
export function startRun(data) {
  return request({
    url: `/bpm/bpmProcessService/start?params=${urlencode(data)}`,
    method: 'post'
    // data
  })
}
// 编辑
export function editFormList(data) {
  return request({
    url: '/workorder/api/act-commit-demo/update',
    method: 'post',
    data
  })
}
// 根据id查询单据
export function getFormListById(id) {
  return request({
    url: `/workorder/api/act-commit-demo/get-Id?id=${id}`,
    method: 'get'
  })
}
