import request from '@/utils/request'
import { toFormData } from '@/utils'
/**
 * 查询待阅列表
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function findNotifyTasks({ params = {}, pageIndex = 1, pageRows = 10 }) {
  return request({
    url: '/bpm/bpmNotifyTaskService/findNotifyTasks',
    method: 'post',
    params: { params, pageIndex, pageRows }
  })
}
/**
 * 批量已读
 * @param params
 * @param pageIndex
 * @param pageRows
 */
export function updateStatus({ params = {} }) {
  return request({
    url: '/bpm/bpmNotifyTaskService/updateStatus',
    method: 'post',
    data: toFormData({ params })
  })
}
