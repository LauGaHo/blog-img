import request from '@/utils/request'

// export function getTenantTotal(data = {}) {
//   return request({
//     url: '/dyapi/baseDynamicApiController/one/tenant-total',
//     method: 'post',
//     data
//   })
// }

export function getWxLoginUrl() {
  let host = 'http://' + window.location.host
  return request({
    url: `/api/base/auth-wx-login/login-url?tenantDomain=${host}`,
    method: "get"
  })
}


export function authWxLogin(code, state) {
  return request({
    url: `/api/base/auth-wx-login/callback?code=${code}&state=${state}`,
    method: "get"
  })
}