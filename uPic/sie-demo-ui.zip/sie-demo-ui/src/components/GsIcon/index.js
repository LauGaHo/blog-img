import GsIcon from './index.vue'

GsIcon.install = Vue => {
  Vue.component(GsIcon.name, GsIcon)
}

export default GsIcon