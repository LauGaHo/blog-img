<!--公用组件：Icon
/**
  * GsIcon
  * @module component
  * @desc 封装了对 iconfont 的调用
  * @author cmh
  * @date 2021年11月18日
  * @param {String} [icon] 必传，值为 iconfont 上的图标名
  * @param {String} [iconPrefix] 图标前置类名
  * @param {String} [iconType] 图标的类型，如： iconfont 、 gsfont
  * @param {String} [size] 图标大小
  * @param {String} [color] 图标颜色
  * @param {Boolean} [svg] 是否渲染为 svg
  * @param {String} [className] 用户自定义 css 类名
  * @example 调用示例
  *  <gs-icon icon="home" icon-type="iconfont" icon-prefix="iconfont" size="18px" color="#fff" svg />
*/
-->
<template>
  <span>
    <template v-if="svg"><svg-icon :icon-class="icon" :svg-class="className" /></template>
    <template v-else>
      <i :class="[iconType, `${iconPrefix}-${icon}`, className]" :style="{ color: color, fontSize: size }" />
    </template>
  </span>
</template>

<script>
export default {
  name: 'GsIcon',
  props: {
    icon: {
      type: String,
      require: true
    },
    iconPrefix: {
      type: String,
      default: 'gs-icon'
    },
    iconType: {
      type: String,
      default: 'gsfont'
    },
    size: {
      type: String
    },
    color: {
      type: String
    },
    svg: {
      type: Boolean,
      default: false
    },
    className: {
      type: String,
      default: ''
    }
  }
}
</script>
