<template>
  <el-dialog
    title="选择图标"
    :visible.sync="dialogVisible"
    width="840px"
    top="5vh"
    append-to-body
    destroy-on-close
    :close-on-click-modal="false"
    @close="closeHandle"
  >
    <div>
      <el-input
        v-model="keyword"
        type="text"
        size="small"
        clearable
        placeholder="输入关键字搜索"
        @keypress.enter.native="filterHandle"
        @clear="filterHandle"
      >
        <el-button
          slot="append"
          icon="el-icon-search"
          @click="filterHandle"
        ></el-button>
      </el-input>
      <ul class="icon-list">
        <li
          v-for="(item, index) of iconList"
          :key="index"
          :class="{ active: item.font_class === iconName }"
          @click="iconName = item.font_class"
        >
          <div class="icon-block">
            <gs-icon :icon="item.font_class" size="18px"></gs-icon>
          </div>
          <el-tooltip
            class="item"
            effect="dark"
            :content="item.name"
            placement="bottom"
          >
            <div class="icon-name">{{ item.name }}</div>
          </el-tooltip>
        </li>
      </ul>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-row>
        <el-col :span="24" class="txt-right">
          <el-button size="small" type="danger" plain @click="iconName = ''">{{
            $t('button.clear')
          }}</el-button>
          <el-button size="small" @click="closeHandle">{{
            $t('button.cancel')
          }}</el-button>
          <el-button size="small" type="primary" @click="confirmHandle">{{
            $t('button.sure')
          }}</el-button>
        </el-col>
      </el-row>
    </span>
  </el-dialog>
</template>

<script>
import icons from './icons';

export default {
  name: 'SelectorDialog',
  data() {
    return {
      iconList: [],
      iconName: '',
      keyword: '',
      dialogVisible: false,
    };
  },
  methods: {
    open(val) {
      this.iconList = _.cloneDeep(icons);
      this.iconName = val || '';
      this.dialogVisible = true;
    },
    close() {
      this.iconName = '';
      this.keyword = '';
      this.dialogVisible = false;
    },
    closeHandle() {
      this.$emit('cancel');
      this.close();
    },
    confirmHandle() {
      this.$emit('confirm', this.iconName);
      this.close();
    },
    filterHandle() {
      const iconList = _.cloneDeep(icons);
      if (this.keyword !== '') {
        this.iconList = iconList.filter((item) => {
          return (
            item.font_class.includes(this.keyword) ||
            item.name.includes(this.keyword)
          );
        });
      } else {
        this.iconList = iconList;
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.icon-list {
  margin: 10px 0 0 0;
  max-height: 55vh;
  min-height: 300px;
  overflow: auto;
  border: 1px solid #eaeaea;
  border-radius: 2px;
  padding: 0;
  li {
    display: inline-block;
    width: 80px;
    padding: 10px;
    color: #6a6a6a;
    text-align: center;
    font-size: 12px;
    border-bottom: 1px solid #eaeaea;
    border-right: 1px solid #eaeaea;
    margin-right: -1px;
    cursor: pointer;
    transition: color 0.2s;
    &:hover {
      color: rgb(0, 140, 255);
    }
    .icon-block {
      font-size: 30px;
      color: inherit;
      margin-bottom: 2px;
    }
    .icon-name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
  .active {
    color: rgb(0, 140, 255) !important;
  }
}
</style>