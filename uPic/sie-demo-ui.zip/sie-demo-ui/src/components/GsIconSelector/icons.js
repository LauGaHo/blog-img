const icons = [
  {
    "icon_id": "14996042",
    "name": "模块",
    "font_class": "mokuai",
    "unicode": "e692",
    "unicode_decimal": 59026
  },
  {
    "icon_id": "6429564",
    "name": "主页",
    "font_class": "zhuye",
    "unicode": "e670",
    "unicode_decimal": 58992
  },
  {
    "icon_id": "1305477",
    "name": "日历",
    "font_class": "rili",
    "unicode": "e66f",
    "unicode_decimal": 58991
  },
  {
    "icon_id": "5638788",
    "name": "复制",
    "font_class": "fuzhi",
    "unicode": "e66e",
    "unicode_decimal": 58990
  },
  {
    "icon_id": "21489486",
    "name": "line-barcode box（条形码）-02",
    "font_class": "line-barcode",
    "unicode": "e717",
    "unicode_decimal": 59159
  },
  {
    "icon_id": "22928467",
    "name": "粘贴",
    "font_class": "niantie",
    "unicode": "e677",
    "unicode_decimal": 58999
  },
  {
    "icon_id": "7789608",
    "name": "撤销",
    "font_class": "chexiao",
    "unicode": "e66c",
    "unicode_decimal": 58988
  },
  {
    "icon_id": "7789621",
    "name": "重做",
    "font_class": "zhongzuo",
    "unicode": "e66d",
    "unicode_decimal": 58989
  },
  {
    "icon_id": "26622357",
    "name": "监控规则集",
    "font_class": "jiankongguizeji",
    "unicode": "e662",
    "unicode_decimal": 58978
  },
  {
    "icon_id": "26622358",
    "name": "我的流程",
    "font_class": "wodeliucheng",
    "unicode": "e663",
    "unicode_decimal": 58979
  },
  {
    "icon_id": "26622359",
    "name": "我的工作台",
    "font_class": "wodegongzuotai",
    "unicode": "e664",
    "unicode_decimal": 58980
  },
  {
    "icon_id": "26622360",
    "name": "我的待办",
    "font_class": "wodedaiban",
    "unicode": "e665",
    "unicode_decimal": 58981
  },
  {
    "icon_id": "26622361",
    "name": "我的待阅",
    "font_class": "wodedaiyue",
    "unicode": "e666",
    "unicode_decimal": 58982
  },
  {
    "icon_id": "26622362",
    "name": "我的已办",
    "font_class": "wodeyiban",
    "unicode": "e667",
    "unicode_decimal": 58983
  },
  {
    "icon_id": "26622363",
    "name": "指标关系",
    "font_class": "zhibiaoguanxi",
    "unicode": "e668",
    "unicode_decimal": 58984
  },
  {
    "icon_id": "26622364",
    "name": "规则参数",
    "font_class": "guizecanshu",
    "unicode": "e669",
    "unicode_decimal": 58985
  },
  {
    "icon_id": "26622365",
    "name": "影响分析",
    "font_class": "yingxiangfenxi",
    "unicode": "e66a",
    "unicode_decimal": 58986
  },
  {
    "icon_id": "26622366",
    "name": "规则运算日志",
    "font_class": "guizeyunsuanrizhi",
    "unicode": "e66b",
    "unicode_decimal": 58987
  },
  {
    "icon_id": "26065142",
    "name": "表间关系",
    "font_class": "biaodanguanxi",
    "unicode": "e60c",
    "unicode_decimal": 58892
  },
  {
    "icon_id": "26065143",
    "name": "API监控",
    "font_class": "apijiankong",
    "unicode": "e63c",
    "unicode_decimal": 58940
  },
  {
    "icon_id": "26065144",
    "name": "API组",
    "font_class": "apizu",
    "unicode": "e646",
    "unicode_decimal": 58950
  },
  {
    "icon_id": "26065145",
    "name": "API服务",
    "font_class": "apifuwu",
    "unicode": "e647",
    "unicode_decimal": 58951
  },
  {
    "icon_id": "26065146",
    "name": "规范定义",
    "font_class": "guifandingyi",
    "unicode": "e648",
    "unicode_decimal": 58952
  },
  {
    "icon_id": "26065147",
    "name": "基础配置",
    "font_class": "jichupeizhi",
    "unicode": "e649",
    "unicode_decimal": 58953
  },
  {
    "icon_id": "26065148",
    "name": "表注册",
    "font_class": "biaozhuce",
    "unicode": "e64a",
    "unicode_decimal": 58954
  },
  {
    "icon_id": "26065149",
    "name": "数据开发",
    "font_class": "shujukaifa",
    "unicode": "e64b",
    "unicode_decimal": 58955
  },
  {
    "icon_id": "26065150",
    "name": "规则计算执行",
    "font_class": "guizejisuan",
    "unicode": "e64c",
    "unicode_decimal": 58956
  },
  {
    "icon_id": "26065151",
    "name": "规则分组",
    "font_class": "guizefenzu",
    "unicode": "e64d",
    "unicode_decimal": 58957
  },
  {
    "icon_id": "26065152",
    "name": "数据标准",
    "font_class": "shujubiaozhun",
    "unicode": "e64e",
    "unicode_decimal": 58958
  },
  {
    "icon_id": "26065153",
    "name": "数仓设置",
    "font_class": "shucangshezhi",
    "unicode": "e64f",
    "unicode_decimal": 58959
  },
  {
    "icon_id": "26065154",
    "name": "任务管理",
    "font_class": "renwuguanli",
    "unicode": "e650",
    "unicode_decimal": 58960
  },
  {
    "icon_id": "26065155",
    "name": "日志查询",
    "font_class": "rizhichaxun",
    "unicode": "e651",
    "unicode_decimal": 58961
  },
  {
    "icon_id": "26065156",
    "name": "数据资产",
    "font_class": "shujuzichan",
    "unicode": "e652",
    "unicode_decimal": 58962
  },
  {
    "icon_id": "26065157",
    "name": "资产质量报告",
    "font_class": "zichanzhiliang",
    "unicode": "e653",
    "unicode_decimal": 58963
  },
  {
    "icon_id": "26065158",
    "name": "规则配置",
    "font_class": "guizepeizhi",
    "unicode": "e654",
    "unicode_decimal": 58964
  },
  {
    "icon_id": "26065159",
    "name": "数据API",
    "font_class": "shujuapi",
    "unicode": "e655",
    "unicode_decimal": 58965
  },
  {
    "icon_id": "26065160",
    "name": "数据源管理",
    "font_class": "shujuyuanguanli",
    "unicode": "e656",
    "unicode_decimal": 58966
  },
  {
    "icon_id": "26065161",
    "name": "项目管理",
    "font_class": "xiangmuguanli",
    "unicode": "e657",
    "unicode_decimal": 58967
  },
  {
    "icon_id": "26065162",
    "name": "子主题",
    "font_class": "zizhuti",
    "unicode": "e658",
    "unicode_decimal": 58968
  },
  {
    "icon_id": "26065163",
    "name": "领域配置",
    "font_class": "lingyupeizhi",
    "unicode": "e659",
    "unicode_decimal": 58969
  },
  {
    "icon_id": "26065164",
    "name": "血缘关系",
    "font_class": "xieyuanguanxi",
    "unicode": "e65a",
    "unicode_decimal": 58970
  },
  {
    "icon_id": "26065165",
    "name": "数据仓建模",
    "font_class": "shujucangjianmo",
    "unicode": "e65b",
    "unicode_decimal": 58971
  },
  {
    "icon_id": "26065166",
    "name": "调度配置",
    "font_class": "tiaodupeizhi",
    "unicode": "e65c",
    "unicode_decimal": 58972
  },
  {
    "icon_id": "26065167",
    "name": "维度定义",
    "font_class": "weidudingyi",
    "unicode": "e65d",
    "unicode_decimal": 58973
  },
  {
    "icon_id": "26065168",
    "name": "指标管理",
    "font_class": "zhibiaoguanli",
    "unicode": "e65e",
    "unicode_decimal": 58974
  },
  {
    "icon_id": "26065169",
    "name": "数据字典",
    "font_class": "shujuzidian",
    "unicode": "e65f",
    "unicode_decimal": 58975
  },
  {
    "icon_id": "26065170",
    "name": "元数据管理",
    "font_class": "yuanshujuguanli",
    "unicode": "e660",
    "unicode_decimal": 58976
  },
  {
    "icon_id": "26065171",
    "name": "指标地图",
    "font_class": "zhibiaoditu",
    "unicode": "e661",
    "unicode_decimal": 58977
  },
  {
    "icon_id": "5317118",
    "name": "database",
    "font_class": "shujuku",
    "unicode": "e758",
    "unicode_decimal": 59224
  },
  {
    "icon_id": "25817520",
    "name": "用户行为",
    "font_class": "yhxw",
    "unicode": "e645",
    "unicode_decimal": 58949
  },
  {
    "icon_id": "25817467",
    "name": "链路追踪",
    "font_class": "llzz",
    "unicode": "e644",
    "unicode_decimal": 58948
  },
  {
    "icon_id": "25817452",
    "name": "日志中心",
    "font_class": "rzzz",
    "unicode": "e643",
    "unicode_decimal": 58947
  },
  {
    "icon_id": "25817388",
    "name": "快递中心",
    "font_class": "kdzx",
    "unicode": "e642",
    "unicode_decimal": 58946
  },
  {
    "icon_id": "25817376",
    "name": "调度异常监控",
    "font_class": "ddycjk",
    "unicode": "e641",
    "unicode_decimal": 58945
  },
  {
    "icon_id": "25817365",
    "name": "提交请求",
    "font_class": "tjqq",
    "unicode": "e640",
    "unicode_decimal": 58944
  },
  {
    "icon_id": "25817342",
    "name": "开放文档",
    "font_class": "kfwd",
    "unicode": "e63f",
    "unicode_decimal": 58943
  },
  {
    "icon_id": "25817262",
    "name": "服务设计",
    "font_class": "fwsj",
    "unicode": "e63e",
    "unicode_decimal": 58942
  },
  {
    "icon_id": "25817226",
    "name": "服务管理",
    "font_class": "fwgl",
    "unicode": "e63d",
    "unicode_decimal": 58941
  },
  {
    "icon_id": "25816781",
    "name": "表单类型",
    "font_class": "blxpz",
    "unicode": "e63b",
    "unicode_decimal": 58939
  },
  {
    "icon_id": "25816770",
    "name": "仪表板",
    "font_class": "ybb",
    "unicode": "e63a",
    "unicode_decimal": 58938
  },
  {
    "icon_id": "25816766",
    "name": "视图",
    "font_class": "st",
    "unicode": "e639",
    "unicode_decimal": 58937
  },
  {
    "icon_id": "25816763",
    "name": "数据集",
    "font_class": "sjj",
    "unicode": "e637",
    "unicode_decimal": 58935
  },
  {
    "icon_id": "25816750",
    "name": "数据源管理",
    "font_class": "sjygl",
    "unicode": "e636",
    "unicode_decimal": 58934
  },
  {
    "icon_id": "25816731",
    "name": "动态报表",
    "font_class": "dtbbpz",
    "unicode": "e635",
    "unicode_decimal": 58933
  },
  {
    "icon_id": "25816615",
    "name": "消息模板",
    "font_class": "xxmb",
    "unicode": "e634",
    "unicode_decimal": 58932
  },
  {
    "icon_id": "25816610",
    "name": "消息渠道",
    "font_class": "xxqd",
    "unicode": "e633",
    "unicode_decimal": 58931
  },
  {
    "icon_id": "25816587",
    "name": "导入模板管理",
    "font_class": "drmbgl",
    "unicode": "e632",
    "unicode_decimal": 58930
  },
  {
    "icon_id": "25816557",
    "name": "意见反馈",
    "font_class": "yjfk",
    "unicode": "e630",
    "unicode_decimal": 58928
  },
  {
    "icon_id": "25816543",
    "name": "角色门户分配",
    "font_class": "jsmhfp",
    "unicode": "e62f",
    "unicode_decimal": 58927
  },
  {
    "icon_id": "25816535",
    "name": "门户显示维护",
    "font_class": "mhxswh",
    "unicode": "e62e",
    "unicode_decimal": 58926
  },
  {
    "icon_id": "25816507",
    "name": "门户内容管理",
    "font_class": "mhnrgl",
    "unicode": "e62d",
    "unicode_decimal": 58925
  },
  {
    "icon_id": "25816420",
    "name": "流程监控",
    "font_class": "lcjk",
    "unicode": "e62c",
    "unicode_decimal": 58924
  },
  {
    "icon_id": "25816358",
    "name": "流程表单",
    "font_class": "lcbd",
    "unicode": "e62b",
    "unicode_decimal": 58923
  },
  {
    "icon_id": "25816321",
    "name": "流程设计",
    "font_class": "lcsj",
    "unicode": "e62a",
    "unicode_decimal": 58922
  },
  {
    "icon_id": "25816156",
    "name": "发起流程",
    "font_class": "fqlc",
    "unicode": "e629",
    "unicode_decimal": 58921
  },
  {
    "icon_id": "25816143",
    "name": "服务配置",
    "font_class": "cbsz",
    "unicode": "e628",
    "unicode_decimal": 58920
  },
  {
    "icon_id": "25816118",
    "name": "我的最爱",
    "font_class": "zdbs",
    "unicode": "e627",
    "unicode_decimal": 58919
  },
  {
    "icon_id": "25816112",
    "name": "系统升级日志",
    "font_class": "xtsjrz",
    "unicode": "e626",
    "unicode_decimal": 58918
  },
  {
    "icon_id": "25816067",
    "name": "角色菜单管理",
    "font_class": "jscdgl",
    "unicode": "e625",
    "unicode_decimal": 58917
  },
  {
    "icon_id": "25815969",
    "name": "角色管理",
    "font_class": "jsgl",
    "unicode": "e624",
    "unicode_decimal": 58916
  },
  {
    "icon_id": "25815966",
    "name": "用户管理",
    "font_class": "yhgl",
    "unicode": "e623",
    "unicode_decimal": 58915
  },
  {
    "icon_id": "25815960",
    "name": "人员管理",
    "font_class": "rygl",
    "unicode": "e622",
    "unicode_decimal": 58914
  },
  {
    "icon_id": "25815932",
    "name": "组织管理",
    "font_class": "bmgl",
    "unicode": "e621",
    "unicode_decimal": 58913
  },
  {
    "icon_id": "25815898",
    "name": "资源管理",
    "font_class": "zygl",
    "unicode": "e620",
    "unicode_decimal": 58912
  },
  {
    "icon_id": "25815765",
    "name": "菜单管理",
    "font_class": "cdgl",
    "unicode": "e614",
    "unicode_decimal": 58900
  },
  {
    "icon_id": "25815744",
    "name": "数据字典",
    "font_class": "sjzd",
    "unicode": "e61f",
    "unicode_decimal": 58911
  },
  {
    "icon_id": "25815743",
    "name": "全局配置",
    "font_class": "xtqjpz",
    "unicode": "e61e",
    "unicode_decimal": 58910
  },
  {
    "icon_id": "25815717",
    "name": "Redis管理",
    "font_class": "redisgl",
    "unicode": "e61d",
    "unicode_decimal": 58909
  },
  {
    "icon_id": "15726799",
    "name": "规则引擎",
    "font_class": "gzyq",
    "unicode": "e61c",
    "unicode_decimal": 58908
  },
  {
    "icon_id": "25809772",
    "name": "运维管理",
    "font_class": "ywgl",
    "unicode": "e61b",
    "unicode_decimal": 58907
  },
  {
    "icon_id": "25809652",
    "name": "词库管理",
    "font_class": "ck-01",
    "unicode": "e61a",
    "unicode_decimal": 58906
  },
  {
    "icon_id": "25809628",
    "name": "DataX管理",
    "font_class": "sj",
    "unicode": "e618",
    "unicode_decimal": 58904
  },
  {
    "icon_id": "25809611",
    "name": "调度管理",
    "font_class": "ddgl",
    "unicode": "e617",
    "unicode_decimal": 58903
  },
  {
    "icon_id": "25809598",
    "name": "默认",
    "font_class": "default",
    "unicode": "e616",
    "unicode_decimal": 58902
  },
  {
    "icon_id": "25809563",
    "name": "动态表单",
    "font_class": "dtbd",
    "unicode": "e613",
    "unicode_decimal": 58899
  },
  {
    "icon_id": "25809555",
    "name": "动态报表",
    "font_class": "dtbb",
    "unicode": "e612",
    "unicode_decimal": 58898
  },
  {
    "icon_id": "25809549",
    "name": "消息管理",
    "font_class": "xxgl",
    "unicode": "e611",
    "unicode_decimal": 58897
  },
  {
    "icon_id": "25809543",
    "name": "门户管理",
    "font_class": "mhgl",
    "unicode": "e610",
    "unicode_decimal": 58896
  },
  {
    "icon_id": "25809507",
    "name": "流程中心",
    "font_class": "lczx",
    "unicode": "e60f",
    "unicode_decimal": 58895
  },
  {
    "icon_id": "25809488",
    "name": "系统管理",
    "font_class": "xtgl",
    "unicode": "e60e",
    "unicode_decimal": 58894
  },
  {
    "icon_id": "25809472",
    "name": "元数据管理",
    "font_class": "ysjgl",
    "unicode": "e60d",
    "unicode_decimal": 58893
  },
  {
    "icon_id": "25807190",
    "name": "租户管理",
    "font_class": "zhgl",
    "unicode": "e60b",
    "unicode_decimal": 58891
  },
  {
    "icon_id": "4766297",
    "name": "area chart",
    "font_class": "areachart",
    "unicode": "e7af",
    "unicode_decimal": 59311
  },
  {
    "icon_id": "4766912",
    "name": "qrcode",
    "font_class": "qrcode",
    "unicode": "e7dd",
    "unicode_decimal": 59357
  },
  {
    "icon_id": "4779612",
    "name": "表单组件-表格",
    "font_class": "form",
    "unicode": "ec15",
    "unicode_decimal": 60437
  },
  {
    "icon_id": "4942647",
    "name": "禁用",
    "font_class": "ban",
    "unicode": "e615",
    "unicode_decimal": 58901
  },
  {
    "icon_id": "9586215",
    "name": "仪表盘",
    "font_class": "yibiaopan",
    "unicode": "e619",
    "unicode_decimal": 58905
  },
  {
    "icon_id": "18592520",
    "name": "drawer",
    "font_class": "drawer",
    "unicode": "e694",
    "unicode_decimal": 59028
  },
  {
    "icon_id": "19835693",
    "name": "dot-chart",
    "font_class": "dot-chart",
    "unicode": "e638",
    "unicode_decimal": 58936
  },
  {
    "icon_id": "1727596",
    "name": "409折线图-线性",
    "font_class": "line-chart",
    "unicode": "e904",
    "unicode_decimal": 59652
  },
  {
    "icon_id": "4354243",
    "name": "图表-饼图",
    "font_class": "pie-chart",
    "unicode": "eb95",
    "unicode_decimal": 60309
  },
  {
    "icon_id": "8559549",
    "name": "堆叠柱状图",
    "font_class": "stack-bar-chart",
    "unicode": "e600",
    "unicode_decimal": 58880
  },
  {
    "icon_id": "15644419",
    "name": "柱状图",
    "font_class": "bar-chart",
    "unicode": "e6d5",
    "unicode_decimal": 59093
  },
  {
    "icon_id": "25577288",
    "name": "bdsj",
    "font_class": "bdsj",
    "unicode": "e60a",
    "unicode_decimal": 58890
  },
  {
    "icon_id": "25577285",
    "name": "bar-stack",
    "font_class": "bar-stack",
    "unicode": "e609",
    "unicode_decimal": 58889
  },
  {
    "icon_id": "25577282",
    "name": "bar-stack-horizontal",
    "font_class": "bar-stack-horizontal",
    "unicode": "e608",
    "unicode_decimal": 58888
  },
  {
    "icon_id": "25577281",
    "name": "bar-horizontal",
    "font_class": "bar-horizontal",
    "unicode": "e607",
    "unicode_decimal": 58887
  },
  {
    "icon_id": "25577278",
    "name": "bannertwh",
    "font_class": "bannertwh",
    "unicode": "e606",
    "unicode_decimal": 58886
  },
  {
    "icon_id": "25577276",
    "name": "app",
    "font_class": "app",
    "unicode": "e605",
    "unicode_decimal": 58885
  },
  {
    "icon_id": "25577275",
    "name": "apizx",
    "font_class": "apizx",
    "unicode": "e604",
    "unicode_decimal": 58884
  },
  {
    "icon_id": "25577273",
    "name": "all-msg",
    "font_class": "all-msg",
    "unicode": "e603",
    "unicode_decimal": 58883
  },
  {
    "icon_id": "25577272",
    "name": "angl",
    "font_class": "angl",
    "unicode": "e602",
    "unicode_decimal": 58882
  },
  {
    "icon_id": "25573469",
    "name": "apigl",
    "font_class": "apigl",
    "unicode": "e601",
    "unicode_decimal": 58881
  },
  {
    "icon_id": "31335",
    "name": "question",
    "font_class": "question",
    "unicode": "e691",
    "unicode_decimal": 59025
  },
  {
    "icon_id": "695379",
    "name": "et-task",
    "font_class": "et-task",
    "unicode": "e631",
    "unicode_decimal": 58929
  },
  {
    "icon_id": "4765723",
    "name": "Dollar",
    "font_class": "dollar",
    "unicode": "e77d",
    "unicode_decimal": 59261
  },
  {
    "icon_id": "5756280",
    "name": "apartment",
    "font_class": "apartment",
    "unicode": "e897",
    "unicode_decimal": 59543
  },
  {
    "icon_id": "6151277",
    "name": "cloud download",
    "font_class": "clouddownload",
    "unicode": "e81b",
    "unicode_decimal": 59419
  },
  {
    "icon_id": "7712696",
    "name": "list",
    "font_class": "list",
    "unicode": "e730",
    "unicode_decimal": 59184
  },
  {
    "icon_id": "7770173",
    "name": "money",
    "font_class": "jiage",
    "unicode": "e7eb",
    "unicode_decimal": 59371
  },
  {
    "icon_id": "11488030",
    "name": "download",
    "font_class": "download",
    "unicode": "e74d",
    "unicode_decimal": 59213
  },
  {
    "icon_id": "3987317",
    "name": "退出全屏",
    "font_class": "out-fullscreen",
    "unicode": "e671",
    "unicode_decimal": 58993
  },
  {
    "icon_id": "5387948",
    "name": "全屏_o",
    "font_class": "fullscrren",
    "unicode": "eb99",
    "unicode_decimal": 60313
  }
]

export default icons

