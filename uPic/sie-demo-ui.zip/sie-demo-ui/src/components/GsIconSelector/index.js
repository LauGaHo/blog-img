import GsIconSelector from './index.vue'

GsIconSelector.install = Vue => {
  Vue.component(GsIconSelector.name, GsIconSelector)
}

export default GsIconSelector