<!--公用组件：Icon Selector
/**
  * GsIconSelector
  * @module component
  * @desc iconfont input选择器，可将弹窗单独调用
  * @author cmh
  * @date 2021年11月18日
  * @param {String} [model] 双向绑定值，图标的 font_class
  * @param {String} [placeholder] 输入框的 placeholder
  * @param {String} [disabled] 输入框的 disabled
  * @example 调用示例
  *  <gs-icon-selector v-model="name" />
*/
-->

<template>
  <div>
    <el-input
      :value="model"
      :placeholder="placeholder || '选择图标'"
      readonly
      :disabled="disabled"
      @focus="showDialog"
    />

    <selector-dialog ref="selectorDialog" @confirm="confirmHandle" />
  </div>
</template>
<script>
import SelectorDialog from '@/components/GsIconSelector/SelectorDialog';

export default {
  name: 'GsIconSelector',
  components: {
    SelectorDialog,
  },
  props: ['model', 'placeholder', 'disabled'],
  model: {
    prop: 'model',
    event: 'update:model',
  },
  data() {
    return {};
  },
  methods: {
    showDialog() {
      this.$refs.selectorDialog.open(this.model);
    },
    confirmHandle(val) {
      this.$emit('update:model', val);
    },
  },
};
</script>
<style lang="scss" scoped>
</style>