import ImportData from './index.vue'

ImportData.install = Vue => {
  Vue.component(ImportData.name, ImportData)
}

export default ImportData