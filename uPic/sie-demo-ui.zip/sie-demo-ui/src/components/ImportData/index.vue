<template>
  <div>
    <el-dialog title="上传数据" :visible.sync="dialogVisible" append-to-body>
      <div class="import-upload" v-loading="loading">
        <el-upload :drag="true" ref="upload" action="action" :show-file-list="false" :http-request="uploadFile">
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">
            将文件拖到此处，或
            <em>点击上传</em>
          </div>
          <div class="el-upload__tip" slot="tip">只能上传xls/xlsx文件</div>
        </el-upload>
      </div>
    </el-dialog>
    <el-dialog
      title="提示"
      :visible.sync="messageVisible"
      width="30%"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      append-to-body
    >
      <div style="height: 120px">
        <p>
          导入完成，共{{ totalCount }}行，{{ successCount }}行成功，<b style="color: red">{{ totalCount - successCount }}</b
          >行失败，请检查数据格式后重试。
        </p>
        <p v-if="checkMsg" v-html="checkMsg"></p>
        <p v-if="excelUrl">
          <a :href="excelUrl" target="_blank">查看导入失败的数据</a>
        </p>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { importHeaderData } from '@/api/system-manage/dataImport'

export default {
  name: 'ImportData',
  props: {
    importId: [String, Number],
    importInfo: Object
  },
  data() {
    return {
      dialogVisible: false,
      selectedData: {},
      loading: false,
      uploadData: {},
      messageVisible: false,
      checkMsg: '',
      excelUrl: '',
      totalCount: '',
      successCount: ''
    }
  },
  mounted() {},
  methods: {
    async uploadFile(param) {
      console.log(param)
      //accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
      const fileTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel']
      if (!fileTypes.includes(param.file.type)) {
        this.$message.warning('只能上传xls/xlsx文件！')
        return false
      }
      this.loading = true
      const { importH } = this.importInfo || {}
      const importId = this.importId || importH ? importH.importId : ''
      const res = await importHeaderData(param.file, importId)

      //const res = await importHeaderData(param.file, this.importId);
      this.loading = false
      if (res.code === 800) {
        this.uploadData = res.data
        this.dialogVisible = false
        this.$emit('refresh-data')
        this.open(res)
      } else {
        this.$message.error(res.msg)
      }
    },
    open(res) {
      if (res.data.hasExcel) {
        this.checkMsg = res.data.checkMsg || ''
        this.excelUrl = res.data.excelUrl || ''
        this.totalCount = res.data.totalCount || ''
        this.successCount = res.data.successCount || ''
        this.messageVisible = true
      } else {
        if (res.data.errorMsg) {
          this.$message.error(`${res.data.errorMsg}`)
        } else {
          this.$message.success(`${res.msg}`)
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.import-upload {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 25px 0px;
  > div {
    width: 360px;
    ::v-deep .el-upload {
      border: none;
      outline: none;
    }
  }
}
</style>
