import MonitorOffice from './index.vue'

MonitorOffice.install = Vue => {
  Vue.component(MonitorOffice.name, MonitorOffice)
}

export default MonitorOffice