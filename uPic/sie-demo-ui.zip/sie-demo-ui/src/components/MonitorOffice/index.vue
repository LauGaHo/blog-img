<template>
  <div class="office">
    <iframe
      ref="docEdit"
      name="docEdit"
      id="docEdit"
      :src="iframeUrl"
      width="100%"
      height="100%"
      class="frame"
      frameborder="0"
      scrolling="yes"
    />
  </div>
</template>
<script>
export default {
  name: 'MonitorOffice',
  props: {
    id: {
      type: Number | String,
      default: ''
    },
    isEdit: {
      type: Boolean,
      default: ''
    }
  },

  data() {
    return {}
  },

  computed: {
    iframeUrl() {
      return `/docEdit/index.html?id=${this.id}&isEdit=${this.isEdit}&requestUrl=${process.env.VUE_APP_SERVERAPI}`
    }
  },

  mounted() {
    window.requestUrl = process.env.VUE_APP_SERVERAPI
  }
}
</script>
<style lang="less" scoped>
.office {
  height: 100%;
}
</style>
