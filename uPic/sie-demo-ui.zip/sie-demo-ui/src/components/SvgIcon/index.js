import SvgIcon from './index.vue'

SvgIcon.install = Vue => {
  Vue.component(SvgIcon.name, SvgIcon)
}

export default SvgIcon