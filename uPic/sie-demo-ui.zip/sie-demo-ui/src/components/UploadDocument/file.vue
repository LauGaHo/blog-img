<template>
  <div class="upload-file">
    <slot :clickEvent="triggerSelect">
      <div class="trigger" @click="triggerSelect">
        <i class="el-icon-plus" />
      </div>
    </slot>
    <input
      :id="inputId"
      type="file"
      @change="getFile($event)"
      style="opacity: 0; position: absolute;"
      :disabled="!editable"
    />
  </div>
</template>

<script>
import { randomString } from '@/utils';
// import { debounce } from "../utils";

/**
 * 图片上传组件, 有剪裁以及压缩功能
 */
export default {
  name: 'uploadFile',
  components: {},
  props: {
    disabled: Boolean,
    accepts: {
      type: Array,
      default: () => {
        return ['xls', 'xlsx', 'pdf', 'doc', 'docx', 'txt', 'jpg', 'png', 'jpeg', 'gif']
      }
    }
  },
  data() {
    return {
      editable: true,
      inputId: randomString()
    };
  },
  computed: {},
  mounted() {},
  methods: {
    triggerSelect() {
      if (this.disabled) {
        this.$message.warning('不可编辑');
        return;
      }
      document.getElementById(this.inputId).click();
    },
    getFile(e) {
      let file = e.target.files[0];
      // const isPDF = file.type === 'application/pdf';
      // const isTxt = file.type === 'text/plain';
      const index = file.name.lastIndexOf('.')
      let fileSuffix = file.name.substr(index + 1).toLowerCase()
      if (!this.accepts.includes(fileSuffix)) {
        //this.$message.warning('上传图片只能是 PDF 或 .txt 格式!');
        this.$message.warning('不支持上传该文件类型！')
        return;
      }
      this.$emit('fileSource', file);
    }
  }
};
</script>

<style lang="scss" scoped>
.upload-file {
  display: inline-block;
  vertical-align: top;
  .trigger {
    cursor: pointer;
    height: 80px;
    width: 80px;
    border: 1px solid #eaedf1;
    display: flex;
    align-items: center;
    justify-content: center;
    .el-icon-plus::before {
      font-size: 36px;
    }
  }
}
</style>
