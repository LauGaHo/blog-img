import UploadDocument from './index.vue'

UploadDocument.install = Vue => {
  Vue.component(UploadDocument.name, UploadDocument)
}

export default UploadDocument