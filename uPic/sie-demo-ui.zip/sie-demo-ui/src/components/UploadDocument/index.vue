<template>
  <!-- 附件列表 -->
  <div class="file-dialig">
    <div style="display: flex; justify-content: flex-end" v-if="btnModifi">
      <el-upload action :http-request="fileSource" :show-file-list="false">
        <slot name="importBtn"></slot>
        <el-button type="primary" :loading="uploading" icon="el-icon-upload" :disabled="disabled" :size="size">
          {{ $t('button.upload') }}
        </el-button>
      </el-upload>
    </div>
    <el-table stripe :data="fileList" style="width: 100%" :size="size" :border="border" v-loading="loading">
      <el-table-column type="index" :label="$t('index')" width="100"></el-table-column>
      <el-table-column sortable property="sourceFileName" :label="$t('upload_file_index.sourceFileName')" width="300">
        <template v-slot="{ row }">
          <a v-if="isRestName" target="_blank" @click="downloadPath(row.filePath, row.sourceFileName)" style="color: #248cf7">{{
            row.sourceFileName
          }}</a>
          <a v-else target="_blank" :href="row.filePath" style="color: #248cf7" :download="row.sourceFileName">{{ row.sourceFileName }}</a>
        </template>
      </el-table-column>
      <el-table-column sortable property="creationName" :label="$t('upload_file_index.creationName')"></el-table-column>
      <el-table-column sortable :label="$t('upload_file_index.creationDate')">
        <template slot-scope="scope">
          <span>{{ scope.row.creationDate || scope.row.uploadDate }}</span>
        </template>
      </el-table-column>
      <el-table-column sortable :label="$t('upload_file_index.action')" align="center" min-width="80">
        <template slot-scope="scope">
          <el-link size="mini" type="danger" :underline="false" :disabled="!btnModifi" @click="handleDelete(scope.row)"
            >{{ $t('button.delete') }}
          </el-link>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import httpUtil from '@/utils/request'
import { uploadAttachment, deleteAttachmentById } from '@/api/update'
import { ArrayTool } from '@/utils/ArrayExtension'

export default {
  name: 'UploadDocument',
  props: {
    isRestName: {
      type: Boolean,
      default: false
    },
    fileList: {
      type: Array
    },
    btnModifi: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    size: String,
    border: null
  },
  data() {
    return {
      fileForm: {
        sourceFileName: '',
        sourceFileType: ''
      },
      uploading: false,
      loading: false
    }
  },
  methods: {
    downloadPath(access, fileName) {
      httpUtil.get(`api/file/iot-base-attachment/getDownUrlByName?fileName=${encodeURI(fileName)}&oldUrl=${access}`).then(res => {
        if (res.code === 800 && !this.fileUrl) {
          this.fileUrl = res.data
          window.open(this.fileUrl)
        }
      })
    },
    async fileSource(data) {
      this.uploading = true
      let resp = await uploadAttachment(data)
      this.uploading = false
      if (resp.code == 800 && resp.data) {
        this.$emit('changeFile', resp.data)
        this.fileList.push(resp.data)
      }
    },
    handleDelete(row) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteAttachmentById(row.fileId).then(resp => {
          if (resp.code === 800) {
            ArrayTool.remove(this.fileList, row)
            this.$message.success(resp.msg)
          }
        })
      })
    },
    //生成模板
    handleImportFileGenter(data) {
      this.$emit('changeFile', data)
    }
  },
  created() {}
}
</script>
<style lang="scss" scoped></style>
