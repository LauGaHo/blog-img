import UploadImg from './index.vue'

UploadImg.install = Vue => {
  Vue.component(UploadImg.name, UploadImg)
}

export default UploadImg