<!--UploadImg
/**
  * UploadImg
  * @module component
  * @desc 对 el-upload 进行的二次封装，用于图片上传
  * @author Calvin
  * @date 2022年3月17日
  * @param {Array} [dataList] 默认上传列表，[{url:xxxxx}]，每个元素必须包含url属性
  * @param {Number} [uploadLimit] 最大上传限制，默认为5
  * @param {Boolean} [deleteDisabled] 上传后是否能删除，false为可删除，默认为false
  * @param {function} [handle-upload] 监听上传完成或删除图片回调，每上传一张触发一次，第一参数上传后文件信息，第二参数回调类型（add/delete）
  * @example 调用示例
  * <UploadImg :data-list.sync="dataList" :upload-limit="1" @handle-upload="handleUpload" /> 
*/
-->

<template>
  <div class="upload-img">
    <!-- 显示已上传图片 -->
    <div class="demo-upload-list" v-for="(item, index) in imgDataList" :key="index">
      <img :src="item.url" />
      <div class="demo-upload-list-cover">
        <i class="el-icon-view" @click="handleView(item.url)" />
        <i v-if="!deleteDisabled" class="el-icon-delete" @click="handleRemove(index)" />
      </div>
    </div>
    <!-- 上传组件 -->
    <div class="demo-upload-list" v-if="imgDataList.length < uploadLimit" v-loading="uploading">
      <el-upload action :show-file-list="false" :http-request="handleBeforeUpload" accept="image/jpeg,image/png">
        <i slot="default" class="el-icon-plus" />
      </el-upload>
    </div>
    <!-- 查看图片弹窗 -->
    <el-dialog title="查看图片" :visible.sync="visible" :append-to-body="true">
      <div class="dialog-box">
        <el-image :src="imgUrl" v-if="noWaterMark" />
        <el-image :src="PreviewUrl" v-if="PreviewUrl && !noWaterMark" />
      </div>
    </el-dialog>
  </div>
</template>
<script>
// 导入API
import { deleteAttachmentById, uploadAttachment } from '@/api/update'
import { getlatelywatermark, WaterMarkformyulanpdf } from '@/api/system-manage/menu'
export default {
  name: 'UploadImg',
  props: {
    // 上传数据
    dataList: {
      type: Array,
      default: () => []
    },
    // 最大允许上传个数
    uploadLimit: {
      type: Number,
      default: 5
    },
    // 是否允许删除
    deleteDisabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 上传Loading标识
      uploading: false,
      // 查看图片地址
      imgUrl: '',
      // 查看图片弹窗标识
      visible: false,
      // 水印
      watermarkData: {},
      // 水印标识
      noWaterMark: false,
      // 带水印的图片地址
      PreviewUrl: ''
    }
  },
  computed: {
    // 过滤props传入的变量为null的元素
    imgDataList() {
      return this.dataList.filter(item => item.url)
    }
  },
  methods: {
    // 查看图片
    handleView(url) {
      this.imgUrl = url
      this.visible = true
      this.noWaterMark = false
      this.PreviewUrl = ''
      this.getWaterMarkformgetId(url)
    },
    // 获取水印ID
    getWaterMarkformgetId(url) {
      getlatelywatermark(this.$route.meta.menuId).then(res => {
        if (res.code == 800 || res.code == 200) {
          this.watermarkData = res.data || {}
          if (Object.keys(this.watermarkData).length > 0) {
            this.noWaterMark = false
            let data = {
              params: {
                url: url,
                funcCode: this.$route.meta.menuId,
                watermarkBean: {
                  ...this.watermarkData
                }
              }
            }
            WaterMarkformyulanpdf(data).then(res => {
              if (res.code == 200 || res.code == 800) this.PreviewUrl = 'data:image/jpg;base64,' + res.data
            })
          } else {
            this.$nextTick(() => {
              this.noWaterMark = true
            })
          }
        }
      })
    },
    // 删除图片
    handleRemove(fileIndex) {
      let file = this.dataList[fileIndex]
      this.$confirm('确定删除图片？', '提示').then(() => {
        // 如果没有fileId，就不真正删除附件文件
        if (file.fileId) deleteAttachmentById(file.fileId)
        this.dataList.splice(fileIndex, 1)
        this.$emit('handle-upload', file, 'delete')
      })
    },
    // 上传图片
    async handleBeforeUpload(e) {
      this.uploading = true
      e = e.file
      const { size, type } = e
      await this.checkFile(size <= 2 * 1024 * 1024, '上传图片大小不能超过 2MB!')
      const format = type.split('/')[1]
      await this.checkFile(
        !!['jpg', 'jpeg', 'png'].find(it => (format ? format.toLowerCase() === it : false)),
        '上传图片只能是 JPEG, JPG 或 PNG 格式!'
      )
      let resp = await uploadAttachment(e, this.$route.meta.menuId)
      if (resp.code === 800) {
        this.$emit('handle-upload', resp.data, 'add')
        this.uploading = false
        this.dataList.push({
          url: resp.data.filePath,
          fileId: resp.data.fileId
        })
      }
    },
    // 检查文件
    checkFile(validate, msg) {
      return new Promise((res, rej) => {
        if (validate) {
          res()
        } else {
          rej(msg)
          this.$message.warning(msg)
          this.uploading = false
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.demo-upload-list {
  display: inline-block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  margin-right: 5px;
}
.demo-upload-list img {
  width: 100%;
  height: 100%;
  vertical-align: inherit;
}
.demo-upload-list-cover {
  display: none;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
  display: block;
}
.demo-upload-list-cover i {
  color: #fff;
  font-size: 16px;
  cursor: pointer;
  margin: 0 2px;
}
.dialog-box {
  text-align: center;
}
</style>
