import Vue from 'vue'

// 需要全局注册的组件
import GsCommonComponents from '@gushen/gushen-common-components'
import GsIcon from "@/components/GsIcon"
import GsIconSelector from '@/components/GsIconSelector'
import ImportData from '@/components/ImportData'
import MonitorOffice from '@/components/MonitorOffice'
import SvgIcon from '@/components/SvgIcon'
import UploadDocument from '@/components/UploadDocument'
import UploadImg from '@/components/UploadImg'

// 动态表单渲染器
import GsFormRender from '@gushen/gushen-form-render'
// 引入样式文件
import '@gushen/gushen-common-components/lib/gushen-common-components.css'
import '@gushen/gushen-form-render/lib/gushen-form-render.css'
Vue.use(GsFormRender)

// 打印组件
import print from '@gushen/gushen-print/src/installComponents.js'
Vue.use(print)

import VueFullScreen from 'vue-fullscreen'
Vue.use(VueFullScreen)

// 右键
import VContentMenu from 'v-contextmenu'
Vue.use(VContentMenu)

import BaiduMap from 'vue-baidu-map'
Vue.use(BaiduMap, { ak: 'nd0OFwRS8qWWi8S9mTzXNR2bD2GVMWSu' })


const components = [
  ...GsCommonComponents,
  print.GsPrintPreview, print.gushenPrint,
  GsIcon, GsIconSelector, ImportData, SvgIcon, UploadDocument, UploadImg
]

components.forEach(component => {
  component.name && Vue.component(component.name, Object.assign({}, component))
})

// 注入到Vue的全局变量
const vueGlobals = {}

// 将全局组件挂载到 window 上，微应用可以自行获取注册
if (typeof window !== 'undefined' && !window.components) {
  window.components = components
}
if (!window.vueGlobals) {
  window.vueGlobals = vueGlobals
}
