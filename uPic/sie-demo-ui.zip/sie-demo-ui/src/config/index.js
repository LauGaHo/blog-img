/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-18 10:06:44
 * @LastEditTime: 2019-10-23 14:24:57
 * @LastEditors: Please set LastEditors
 */
export default {
  /**
   * @description 配置显示在浏览器标签的title
   */
  title: 'SIEIOT权限管理系统',
  /**
   * @description 当前系统的系统编码 systemCode
   */
  systemCode: 'gushen-demo',
  /**
   * @description token在Cookie中存储的天数，默认1天
   */
  cookieExpires: 1,
  /**
   * @description 是否使用国际化，默认为false
   *              如果不使用，则需要在路由中给需要在菜单中展示的路由设置meta: {title: 'xxx'}
   *              用来在菜单中显示文字
   */
  // useI18n: true,
  /**
   * @description api请求基础路径
   */
  baseUrl: {
    designUrl: "http://eam.auth.sieiot.com:9304/modeler.html", // 流程设计iframe地址
    eamBaseUrl: "http://dev.eam.sieiot.com/", //eam功能项目的url
    iotBaseUrl: "http://dev.ibracelet.sieiot.com/", //iot手环功能项目的url
    iotStandardBaseUrl: "http://dev.iiot.sieiot.com/", //iot标准平台功能项目的url
    avueDataUrl: 'http://dev.view-data.sieiot.com',
    gkbarcodeUrl:'http://dev.gkbarcode.sieiot.com/#/',//服务编排
  },
  /** 各个系统URL */
  systemURL: {
    eam() { return process.env.NODE_ENV === 'development' ? '//localhost:9021' : 'http://dev.eam.sieiot.com/' },
    iot() { return process.env.NODE_ENV === 'development' ? '//localhost:9023' : 'http://dev.iiot.sieiot.com/' }
  },
  /**
   * @description 默认打开的首页的路由name值，默认为home
   */
  homeName: 'home',
  /**
   * 白名单
   * 不登录允许跳转
   */
  whiteList: ['register', 'bindCompany', 'createCompany', 'joinCompany', 'agreement', 'openapi', 'resetpassword'],
  /**
   * @description 需要加载的插件
   */
  plugin: {
    'error-store': {
      showInHeader: true, // 设为false后不会在顶部显示错误日志徽标
      developmentOff: true, // 设为true后在开发环境不会收集错误信息，方便开发中排查错误
    },
  },
  /**
   * @description 条码导入模板地址
   */
  barcodeImportAddress: 'https://jgoss1.oss-cn-shenzhen.aliyuncs.com/file/%E6%9D%A1%E7%A0%81%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF.xlsx',
  backToIndexTime: 1000,
}
