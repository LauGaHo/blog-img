// elementUI 语言包
import enLocale from 'element-ui/lib/locale/lang/en'
import setLang from '@/lang/utils'

export default {
  index: 'No.',
  tenantName: 'Tenant Name',
  search: 'Search',
  hiddenAndShow: 'Column Visiable/Unvisiable',
  characterName: 'Role Name',
  creationDate: 'Creation Date',
  roleType: 'Role Type',
  remarks: 'Remarks',
  operate: 'Operation',
  active: 'Active',
  inactive: 'Inactive',
  psnName: 'Personnel Name',
  loginAccount: 'Login Account',
  mobile: 'Mobile',
  roleName: 'Role Name',
  newtenatName: 'Company Name',
  approverState: 'Approval Status',
  applicant: 'Contact',
  applicantPhone: 'Contact Number',
  applicantEmail: 'Contact Email',
  tenantId: 'Tenant Id',
  mail: 'Email',
  roleNames: 'Role Name',
  enterpriseCode: 'enterprise Code',
  country: 'country',
  state: 'state',
  dashboard: 'dashboard',
  yes: 'yes',
  no: 'no',

  ...enLocale,
  ...setLang('en-us')
}