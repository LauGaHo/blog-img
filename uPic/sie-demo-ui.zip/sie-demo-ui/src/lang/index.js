import Vue from 'vue'
import VueI18n from 'vue-i18n'
import axios from 'axios'
import { getLanguage } from '@/utils/auth'

// 本地语言包
import zhCN from '@/lang/zh-CN'
import enUS from '@/lang/en-US'

Vue.use(VueI18n)

export const i18n = new VueI18n({
  locale: getLanguage() || 'zh-cn',
  fallbackLocale: 'zh-cn',
  messages: {
    'zh-cn': { ...zhCN },
    'en-us': { ...enUS }
  }
})

// 我们的预装默认语言
const loadedLanguages = ['zh-cn', 'en-us']

function setI18nLanguage(lang) {
  i18n.locale = lang
  axios.defaults.headers.common['Accept-Language'] = lang
  document.querySelector('html').setAttribute('lang', lang)
  return lang
}

export function loadLanguageAsync(lang) {
  // 如果语言相同
  if (i18n.locale === lang) 
    return Promise.resolve(setI18nLanguage(lang))
  

  // 如果语言已经加载
  if (loadedLanguages.includes(lang)) 
    return Promise.resolve(setI18nLanguage(lang))
  

  // 如果尚未加载语言
  return import(/* webpackChunkName: "lang-[request]" */ `@/lang/${lang}.js`).then(
    messages => {
      i18n.setLocaleMessage(lang, messages.default)
      loadedLanguages.push(lang)
      return setI18nLanguage(lang)
    }
  )
}

export function initLanguage() {
  // 获取语言配置信息
  let lang = getLanguage() || 'zh-cn'
  if (lang === 'undefined') {
    lang = 'zh-cn'
  }else if (lang === 'en') {
    lang = 'en-us'
  }
  loadLanguageAsync(lang)
}
