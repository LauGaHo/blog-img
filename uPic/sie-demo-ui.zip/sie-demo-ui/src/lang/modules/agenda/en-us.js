export default {
  bpm_title: "Process Title",
  bpm_categoryName: "Process Classification",
  bpm_userFullName: "Process Initiator",
  bpm_startTime: "Application Time",
  taskName: "Approval Node",
  status: "To Do Status",
  bpm_resultName: "Task Status",
  createTime: "Start Time",
  durationDHM: "Waiting Time",
  bpm_result: "Task Status"
}