export default {
  bpm_title: "流程标题",
  bpm_categoryName: "流程分类",
  bpm_userFullName: "流程发起人",
  bpm_startTime: "申请时间",
  taskName: "审批节点",
  status: "待办状态",
  bpm_resultName: "任务状态",
  createTime: "待办开始时间",
  durationDHM: "待办处理时长",
  bpm_result: "任务状态"
}