export default {
  bpm_title: 'Process Title',
  bpm_categoryName: 'Process Classification',
  bpm_userFullName: 'Process Initiator',
  bpm_creationDate: 'Application Time',
  cur_taskName: 'Approval Node',
  cur_userFullName: 'Approver',
  bpm_statusName: 'Document Status',
  endTime: 'Approval Time',
  durationDHMS: 'Processing Time',
  approvalTime: 'Approval Time'
}
