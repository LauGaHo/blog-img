export default {
  bpm_title: "流程标题",
  bpm_categoryName: "流程分类",
  bpm_userFullName: "流程发起人",
  bpm_creationDate: "申请时间",
  cur_taskName: "审批节点",
  cur_userFullName: "审批人",
  bpm_statusName: "单据状态",
  endTime: "审批时间",
  durationDHMS: "处理时长",
  "approvalTime": "审批时间",

}