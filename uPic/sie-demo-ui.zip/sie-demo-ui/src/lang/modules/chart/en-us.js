export default {
    chart_details: 'view details',
    export_details: 'export details',
    total: 'total',
    items: 'item',
    panel_details: 'panel details',
}