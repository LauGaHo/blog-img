export default {
  chart_details: '视图明细',
  export_details: '导出明细',
  total: '共',
  items: '条数据',
  panel_details: '详情',
}