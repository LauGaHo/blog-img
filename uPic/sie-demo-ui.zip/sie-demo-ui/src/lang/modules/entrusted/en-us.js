export default {
  configId: "Commission Number",
  client_userFullName: "Client",
  startTime: "Start Time",
  endTime: "End Time",
  enabled: "Status"
}
