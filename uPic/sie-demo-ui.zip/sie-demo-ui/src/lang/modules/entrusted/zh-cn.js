export default {
  configId: "委托编号",
  client_userFullName: "委托人",
  startTime: "委托开始时间",
  endTime: "委托结束时间",
  enabled: "状态"
}
