export default {
  processClassification: 'Process Classification',
  commissionNumber: 'Commission Number',
  client: 'Client',
  clientUserId: 'Client Admin',
  consignee: 'Consignee',
  commissionTime: 'Commission Time',
  myCommission: 'My Commission',
  commissioned: 'Commissioned',
  startTime: 'Start Time',
  endTime: 'End Time',
  status: 'Status',
  entrustedApproval: 'Entrusted Approval',
  processScope: 'Process Scope'
}
