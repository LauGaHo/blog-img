export default {
  processClassification: '流程分类',
  commissionNumber: '委托编号',
  client: '委托人',
  clientUserId: '由管理员委托',
  consignee: '被委托人',
  commissionTime: '委托时间',
  myCommission: '我的委托',
  commissioned: '我被委托',
  startTime: '委托开始时间',
  endTime: '委托结束时间',
  status: '状态',
  entrustedApproval: '委托审批',
  processScope: '流程范围'
}
