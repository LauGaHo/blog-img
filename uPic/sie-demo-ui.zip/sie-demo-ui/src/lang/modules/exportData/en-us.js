export default  {
  export: 'Export',
  asynchronousDataViewing: 'Asynchronous data viewing',
  advancedOptions: 'Advanced options',
  advancedConfiguration: 'Advanced configuration',
  customFileName: 'custom FileName',
  maximumRowsPerSheet: 'Maximum rows per sheet',
  maximumSheetNumberOfFiles: 'Maximum sheet number of files',
  asynchronous: 'Asynchronous',
  selectExportColumn: 'Select export column',
  exportDetail: 'Export Detail',
  projectID: 'projectID',
  exportProgress: "Export progress",
  exportRecord: 'Export record',
  currentTaskID: 'Current taskID'
}