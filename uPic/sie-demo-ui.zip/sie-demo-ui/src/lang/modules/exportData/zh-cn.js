export default  {
  export: '导出',
  asynchronousDataViewing: '异步数据查看',
  advancedOptions: '高级选项',
  advancedConfiguration: '高级配置',
  customFileName: '自定义文件名',
  maximumRowsPerSheet: '单sheet最大行数',
  maximumSheetNumberOfFiles: '文件最大sheet数',
  asynchronous: '是否异步',
  selectExportColumn: '选择导出列',
  exportDetail: '导出详情',
  projectID: '项目ID',
  exportProgress: "导出进度",
  exportRecord: '导出记录',
  currentTaskID: '当前任务 ID'
}