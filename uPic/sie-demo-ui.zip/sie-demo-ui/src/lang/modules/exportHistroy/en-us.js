export default {
  exportId: 'Export Id',
  status: 'Status',
  requestUrl: 'Request Url',
  creationDate: 'Creation Date',
  functionName: 'Function Name',
  userName: 'User Name',
  action: 'Action'
}