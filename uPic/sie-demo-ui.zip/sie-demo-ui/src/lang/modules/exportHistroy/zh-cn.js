export default {
  exportId: '导出ID',
  status: '状态',
  requestUrl: '请求地址',
  creationDate: '创建日期',
  fileName: '导出项目',
  userName: '操作人',
  action: '操作'
}