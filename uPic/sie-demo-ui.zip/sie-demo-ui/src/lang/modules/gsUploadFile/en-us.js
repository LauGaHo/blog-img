export default {
  fileTypeWarning: 'File format error, the correct file format for:',
  sourceFileName: 'Source File Name',
  creationName: 'Creation Name',
  creationDate: 'Creation Date',
  action: 'Action'
}