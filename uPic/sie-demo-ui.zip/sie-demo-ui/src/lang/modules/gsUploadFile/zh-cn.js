export default {
  fileTypeWarning: '文件格式错误，文件格式应为：',
  sourceFileName: '文档名称',
  creationName: '上传用户',
  creationDate: '上传日期',
  action: '操作'
}
