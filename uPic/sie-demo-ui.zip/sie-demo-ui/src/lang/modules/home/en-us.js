export default {
  tenantTotal: 'Tenant Total',
  clicksTotal: 'Clicks Total',
  usersTotal: 'Users Total',
  questionsTotal: 'Questions Total',
  exampleCount: 'Running',
  failedCount: 'Failed',
  runningCount: 'Normal',
  deviceAccessTotal: 'Device Access Total',
  topTenant: 'Top 10 active tenants',
  topBpm: 'Total number of weekly process submissions',
  activeUser: 'Top 10 Active User',
  topMenu: 'Top 10 menu click',
  topRecord: 'User Access Analysis',
  topDevice: 'Total number of tenant device access'
}