export default {
  tenantTotal: '租户总数',
  clicksTotal: '点击总数',
  usersTotal: '用户总数',
  questionsTotal: '问题总数',
  exampleCount: '运行中',
  failedCount: '异常',
  runningCount: '正常',
  deviceAccessTotal: '表单数量',
  topTenant: 'Top10活跃租户',
  topBpm: '每周流程提交总数',
  topMenu: 'Top10菜单点击',
  activeUser: '活跃用户top10',
  topRecord: '用户访问分析',
  topDevice: '租户设备接入总数'
}