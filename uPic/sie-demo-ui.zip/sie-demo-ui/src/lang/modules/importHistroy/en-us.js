export default {
  batch: 'Batch',
  status: 'Status',
  dataCount: 'Data Count',
  successCount: 'Success Count',
  creationDate: 'Creation Date',
  createdUserName: 'Created User Name',
  action: 'Action'
}