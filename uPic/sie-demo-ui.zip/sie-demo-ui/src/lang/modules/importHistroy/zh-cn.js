export default {
  batch: '批次号',
  status: '状态',
  dataCount: '总数量',
  successCount: '成功数',
  creationDate: '创建日期',
  createdUserName: '创建人',
  action: '操作'
}