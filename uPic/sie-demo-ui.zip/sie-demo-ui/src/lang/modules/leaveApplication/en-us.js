export default {
  tlName: '请假人',
  startDate: '请假时间',
  tlDay: '请假天数',
  tlExplain: '请假说明',
  tlStatus: '单据状态',
  action: '操作',
}