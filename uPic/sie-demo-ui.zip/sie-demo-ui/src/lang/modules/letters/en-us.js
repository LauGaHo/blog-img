export default {
  inbox: 'Inbox (all)',
  unReadMsg: 'Unread messages',
  messageContent: 'The message content',
  sendTime: 'Send time',
  action: 'Action',
  delete: 'Delete',
  readStatus: 'Reading state',
  read: 'Read',
  unRead: 'Unread',
}
