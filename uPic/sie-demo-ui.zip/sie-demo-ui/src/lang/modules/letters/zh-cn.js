export default {
  inbox: '收件箱(全部)',
  unReadMsg: '未读消息',
  messageContent: '消息内容',
  sendTime: '发送时间',
  action: '操作',
  delete: '删除',
  readStatus: '阅读状态',
  read: '已读',
  unRead: '未读',
  setToUnread: '已设置为未读',
  updateReadSuccess: '更新已读成功'
}
