export default {
  login: 'Login',
  welcomeLogin: 'Welcome to login',
  userLogin: 'User Login',
  codeImgLogin: 'Sweep the login code',
  enterNum: 'Phone number',
  enterPwd: 'Password',
  accEmpty: 'The account cannot be empty',
  pwdEmpty: 'The password cannot be empty',
  forgetPwd: 'Forgot password',
  welcome: 'Welcome to SIE',
  verificationCode: 'Verification Code',
  freeRegistration: 'Free Registration',
  newPwd: 'New Password',
  confirmPassword: 'Confirm Password',
  directLogin: 'Direct Login',
  sendCode: 'Send Code',
  smsVerifyCode: 'SMS Verify Code'
}