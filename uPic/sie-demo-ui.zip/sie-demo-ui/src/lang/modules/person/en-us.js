export default {
  personInfo: 'Personal information',
  staffNo: 'Employee number：',
  name: 'Name：',
  mobile: 'Mobile：',
  email: 'Email：',
  depName: 'Subordinate departments：',
  avatar: 'Avatar：',
  noUpdate: 'No update information',

  changePwd: 'Change the password',
  originalPwd: 'Original password',
  originalPwdTip: 'Please enter your old password',
  newPwd: 'New password',
  newPwdTip: 'Please enter a new password',
  confirmPwd: 'Confirm password',
  confirmPwdTip: 'Please confirm your password',
  confirmPwdAgainTip: 'Please enter the new password again',
  confirmPwdErrorTip: 'The passwords entered twice are inconsistent',
  pwdLengthTip: 'The password must contain at least six characters',

  defaultSystemTip: 'Set the current system to the default login system？',
  confirmMsg: 'Confirm the information'
}