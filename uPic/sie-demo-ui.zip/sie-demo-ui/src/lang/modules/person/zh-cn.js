export default {
  personInfo: '个人信息',
  staffNo: '员工编号：',
  name: '姓名：',
  mobile: '手机号码：',
  email: '邮箱：',
  depName: '所属部门：',
  avatar: '头像：',
  noUpdate: '无更新信息',

  changePwd: '修改密码',
  originalPwd: '原密码',
  originalPwdTip: '请输入原密码',
  newPwd: '新密码',
  newPwdTip: '请输入新密码',
  confirmPwd: '确认密码',
  confirmPwdTip: '请输入确认密码',
  confirmPwdAgainTip: '请再次输入新密码',
  confirmPwdErrorTip: '2次输入的密码不一致',
  pwdLengthTip: '密码不能小于6位',

  defaultSystemTip: '设置当前系统为默认登录系统？',
  confirmMsg: '确认信息'
}