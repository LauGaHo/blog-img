export default {
  styleConfig: 'Style configuration',
  overallStyleSetting: 'Overall style setting',
  navbarStyleSetting: 'Navigation bar Settings',
  controlStyleSetting: 'Control theme color',
  light: 'Light',
  dark: 'Dark',
  oneStop: 'One Stop',
  sie: 'Sie Red',
  skyBlue: 'Blue',
  sapphireBlue: 'Sapphire Blue',
  tangerine: 'Tangerine',
  green: 'Green',
  orange: 'Orange',

  layoutStyle: 'Layout Style',
  defaultLayout: 'Default',
  compactLayout: 'Compact'
}