export default {
  styleConfig: '风格配置',
  overallStyleSetting: '整体风格设置',
  navbarStyleSetting: '顶部背景',
  controlStyleSetting: '主题颜色',
  light: '普通',
  dark: '暗夜',
  oneStop: '一站式',
  sie: '赛意红',
  skyBlue: '铱星蓝',
  sapphireBlue: '宝石蓝',
  tangerine: '珊瑚橙',
  green: '爪哇绿',
  orange: '亮丽黄',

  layoutStyle: '布局风格',
  defaultLayout: '默认布局',
  compactLayout: '紧凑布局'
}