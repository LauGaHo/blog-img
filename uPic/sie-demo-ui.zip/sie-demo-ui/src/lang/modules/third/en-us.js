export default {
  check: 'Please check whether the url you entered is correct, please click the button below to return to the home page or send an error report',
  backHome: 'home page',
  notToPage: "The webmaster says you can't access this page",
  passwordWill: "The password is about to",
  outTime: "Expired, please modify in time",
  changePassword: "Change the password",
  later: "later",
}