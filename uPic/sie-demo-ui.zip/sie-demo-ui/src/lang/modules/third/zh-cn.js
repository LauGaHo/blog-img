export default {
  check: '请检查您输入的网址是否正确，请点击以下按钮返回主页或者发送错误报告',
  backHome: '返回首页',
  notToPage: '网管说这个页面你不能进......',
  passwordWill: '密码即将于',
  outTime: '过期，请及时修改！',
  changePassword: '修改密码',
  later: '以后再说',
}