export default {
  bpm_title: 'Process Title',
  bpm_categoryName: 'Process Classification',
  userFullName: 'Process Initiator',
  bpm_creationDate: 'Application Time',
  taskName: 'Approval Node',
  statusName: 'Reading State',
  bpm_startTime: 'Sending Time',
  durationDHM: 'Document Processing Time',
  readingState: 'Reading State',
  sendingTime: 'Sending Time',
  documentProcessingTime: 'Document Processing Time',
  batchMarkedAsDrainage: 'Batch Marked As Drainage',
  noRead: 'No Read',
  read: 'read'
}
