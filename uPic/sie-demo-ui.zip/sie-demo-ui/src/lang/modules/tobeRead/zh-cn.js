export default {
  bpm_title: '流程标题',
  bpm_categoryName: '流程分类',
  userFullName: '流程发起人',
  bpm_creationDate: '申请时间',
  taskName: '审批节点',
  statusName: '阅读状态',
  bpm_startTime: '发送时间',
  durationDHM: '单据处理时长',
  readingState: '阅读状态',
  sendingTime: '发送时间',
  documentProcessingTime: '单据处理时长',
  batchMarkedAsDrainage: '批量标为已读',
  noRead: '未阅',
  read: '已阅'
}
