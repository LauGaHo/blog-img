export default function(lang) {
  const langFiles = require.context('./modules', true, /\.js$/)

  let result = {}

  langFiles.keys().forEach(fileName => {
    // 根据文件夹名称设置key
    const langKey = fileName.match(/\/(.+?)\//)?.[1]
    if (!langKey)  return 

    if (fileName.includes(lang)) 
    {result = {
      ...result,
      [langKey]: langFiles(fileName).default
    }}
    
  })

  return result
}
