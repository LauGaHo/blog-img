// elementUI 语言包
import zhLocale from 'element-ui/lib/locale/lang/zh-CN'
import setLang from '@/lang/utils'

export default {
  tenantName: '租户',
  psnName: '人员姓名',
  loginAccount: '登录账号',
  mobile: '手机号码',
  roleName: '角色名称',
  active: '启用',
  inactive: '禁用',
  index: '序号',
  search: '搜索',
  hiddenAndShow: '列显示/隐藏',
  characterName: '角色名称',
  creationDate: '创建日期',
  roleType: '角色类型',
  remarks: '备注',
  operate: '操作',
  tenantId: '租户ID',
  newtenatName: '公司名称',
  approverState: '审核状态',
  applicant: '联系人',
  applicantPhone: '联系电话',
  applicantEmail: '联系邮箱',
  identification: '租户类型',
  mail: '邮箱',
  roleNames: '角色',
  enterpriseCode: '企业代码',
  country: '所在国家',
  state: '状态',
  dashboard: '大屏',
  yes: '是',
  no:'否',

  ...zhLocale,
  ...setLang('zh-cn')
}