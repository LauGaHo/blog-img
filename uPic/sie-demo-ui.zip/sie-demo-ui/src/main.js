import Vue from 'vue'
import App from '@/App.vue'
import config from '@/config'
import router from '@/router'
import store from '@/store'
import { i18n, initLanguage } from '@/lang'
import { action } from '@/qiankun'
import appMixin from '@/utils/app-mixin'
import Bus from '@/utils/bus'
import { initTheme } from '@/utils/theme'
import httpUtil from '@/utils/request'
import dayjs from 'dayjs'

// css
import 'normalize.css/normalize.css'
import '@/styles/index.scss'
import '@/styles/iconfont/iconfont.css'
import '@/styles/gsfont/iconfont.css'
import '@gushen/gushen-common-components/lib/gushen-common-components.css'
import 'v-contextmenu/dist/index.css'

// global components
import '@/components/global-register'

// 路由权限
import '@/permission'
// 注册全局过滤器
import '@/filters'
// 注册全局指令
import '@/directives'
// 注册全局icon
import '@/icons'

// element-ui 翻译
Vue.use(ELEMENT, {
  i18n: (key, value) => i18n.t(key, value)
})

// 全局混入
Vue.mixin(appMixin)

Vue.config.productionTip = false
// 若是没有开启Devtools工具，在开发环境中开启，在生产环境中关闭
Vue.config.devtools = process.env.NODE_ENV === 'development'

const VUE_APP_SERVERAPI = window.VUE_APP_SERVERAPI || process.env.VUE_APP_SERVERAPI || ''
// k8s dev 环境开放下Devtools
if (process.env.NODE_ENV === 'development' || VUE_APP_SERVERAPI.indexOf('devcenter') > -1) {
  Vue.config.devtools = true
}

// 全局初始化的时候
// 初始化语言包
initLanguage()

// 初始化主题
initTheme()

// vue全局挂载
Vue.prototype.$moment = dayjs
Vue.prototype.$bus = Bus
Vue.prototype.$_ = window._
Vue.prototype.$microProps = action
Vue.prototype.$http = httpUtil

// echarts挂载到全局，动态表单用到
Vue.prototype.$echarts = window.echarts

// window 全局对象
window._config = config
window.$request = httpUtil;

new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount('#app')
