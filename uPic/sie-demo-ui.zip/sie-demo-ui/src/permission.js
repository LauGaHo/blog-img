import router from './router'
import store from './store'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken, setUserInfo } from '@/utils/auth' // getToken from cookie
import { checkIsHref } from '@/utils'
import { autoLogin } from '@/api/login'
import { getsystemwatermark } from '@/api/system-manage/menu'
import globalConfig from '@/config'
import Layout from '@/views/layout/Layout'
import { i18n } from '@/lang'
import MiddleView from '@/views/layout/MiddleView'
import Watermark from '@/utils/watermark'
import GushenFormRender from '@gushen/gushen-form-render'

const systemCode = globalConfig.systemCode

// NProgress Configuration
NProgress.configure({
  showSpinner: false
})

// no redirect whitelist
let whiteList = [
  '/login',
  '/knowledge-details',
  '/midea-login',
  '/third-login',
  '/third-party/receiveWxMsg',
  '/qrcode',
  '/qrcode-success',
  '/report/preview',
  '/sso/login'
]

let remoteRouters
// 浏览器回车刷新，清空菜单数据，然后请求一份最新的一份数据。
localStorage.removeItem('menuList')
router.beforeEach(async (to, from, next) => {
  
  NProgress.start()
  hmt(to)

  // 对空路由进行跳转重定向
  if (to.fullPath === '/') next({ path: '/home', replace: true })

  const activeRoute = {
    name: to.name,
    path: to.path,
    fullPath: to.fullPath,
    meta: to.meta,
    query: to.query,
    params: to.params
  }
  await store.dispatch('setActiveRoute', activeRoute)
  window.sessionStorage.setItem('activeRoute', JSON.stringify(activeRoute))
  window.sessionStorage.setItem('pageAllData', JSON.stringify({ [activeRoute.path]: {} }))
  let token = getToken()
  if (token && token !== 'undefined') {
    // 请求菜单。
    await fetchMenus()
    let menuId = ''
    let menuCode = ''
    const checkItemIn = function (routes, fullPath) {
      routes.forEach(route => {
        // getRealDynamicFormPath 获取真实的动态表单路由
        if (route.path === fullPath || fullPath === getRealDynamicFormPath(route)) {
          menuId = route.meta.menuId
          menuCode = route.meta.menuCode
        } else if (route.children) {
          checkItemIn(route.children, fullPath)
        }
      })
    }
    checkItemIn(store.state.permission.routers, to.fullPath)
    if (menuId) {
      sessionStorage['menuId'] = menuId
      await store.dispatch('setActiveMenuId', { menuId })
      await store.dispatch('setAuthBTN', { menuId, menuCode })
      await store.dispatch('getCollectStatus', { menuId, query: to.query })
    } else {
      await store.dispatch('setActiveMenuId', { menuId: null })
    }

    if (to.path === '/login') {
      next({
        path: to.query.redirect,
        query: {
          // listData: to.query.listData || null,
          taskId: to.query.taskId || null,
          processInstanceId: to.query.processInstanceId || null,
          routerFromName: to.query.routerFromName || null
        }
      })
      // if current page is dashboard will not trigger	afterEach hook, so manually handle it
      NProgress.done()
    }
    // 判断当前用户是否已拉取完user_info信息
    else if (!remoteRouters) {
      let menuList = JSON.parse(localStorage.getItem('menuList'))
      remoteRouters = formatRoutes(menuList || [])
      router.addRoute('root', { path: '*', name: 'default', component: MiddleView })
      store.commit('SET_ROUTERS', { remoteRouters })
      next({ ...to, replace: true })
    } else {
      next()
    }
  } else if (whiteList.indexOf(to.path) !== -1) {
    /* has no token*/
    // 在免登录白名单，直接进入
    next()
  } else {
    // localStorage.removeItem('watermarkData')
    // if (process.env.NODE_ENV !== 'development') {
    //   window.location.href = `${window.VUE_AUTH_API ? window.VUE_AUTH_API : ''}/login`;
    // } else {
    //   window.location.href = '/login';
    // }
    localStorage.removeItem('watermarkData')
    // 如果没有token又不在登录白名单中的话 清除用户信息
    localStorage.removeItem('userInfo')
    NProgress.done()
    next()
  }
})

router.afterEach(to => {
  // finish progress bar
  NProgress.done()
  const systemSetting = localStorage.getItem('systemSetting')
  if (!systemSetting) return

  let setting = JSON.parse(systemSetting)
  if (setting.systemTitle !== null) {
    const pageTitle = i18n.locale === 'zh-cn' ? to.meta?.title : to.meta?.enTitle
    if (pageTitle) document.title = `${setting.systemTitle} - ${pageTitle}`
  }

  let favicon = document.querySelector("link[rel*='icon']")
  favicon.href = setting.iconUrl
  document.getElementsByTagName('head')[0].appendChild(favicon)
})

// 百度统计
function hmt(route) {
  //百度统计每个路由访问流量
  if (window._hmt && !window.VUE_CONNECT_TO_PUBNET) {
    if (route.path) window._hmt.push(['_trackPageview', '/#' + route.fullPath])
  }
}

// 请求菜单信息
async function fetchMenus() {
  
  // fix 判断下是否请求了，请求过了就不再请求
  if (!remoteRouters) {
    let { data } = await autoLogin(systemCode)
    // 设置水印
    let res = await getsystemwatermark(systemCode, '', data.tenantId)
    if (res.code === 800) {
      if (res.data) {
        // window.localStorage.setItem('watermarkBean', JSON.stringify(res.data))
        Watermark.set(res.data)
      }
    }
    setUserInfo(data)
    store.commit('SET_ROLES_LIST', data.roles)
    // TODO 暂时排除不需要显示的菜单
    // const excludeUrl = ['dynamic-report', 'rule-engine']
    const excludeUrl = ['rule-engine']
    let menus = data.menus.filter(menu => !excludeUrl.includes(menu.menuUrl))
    localStorage.setItem('menuList', JSON.stringify(menus))

    // 保存默认菜单信息
    window.sessionStorage.setItem('defaultMenu', JSON.stringify(data.defaultMenuUrl))
  }
}

/**
 * 多级菜单递归算法
 * @param {*} data 菜单数据
 * @param {*} first 是否为第一个路由
 * @param {*} parentPath 父级路径
 */
function formatRoutes(data, first = true, parentPath = '') {
  const routes = data.map(item => {
    //是否有子路由
    const hasChild = !!item.children && item.children.length !== 0
    // 是否为 http 链接
    const isHttpUrl = checkIsHref(item.menuUrl)
    // 路由名称
    const name = isHttpUrl ? item.menuCode : item.menuUrl
    // path
    const path = generatePath(item, isHttpUrl, parentPath)
    let component = Layout
    // 如果不是一级菜单，但是却有子级
    if (!first && hasChild) component = () => import(`@/views/layout/MiddleView`)
    if (!first && !hasChild) component = () => import(`@/views${path}`)

    let route = {
      name,
      path,
      meta: generateMetaInfo(item),
      component,
      menuName: item.menuName || '',
      menuEnName: item.menuEnName || item.menuName || '',
      children: (() => {
        if (hasChild) return formatRoutes(item.children, false, path)
      })()
    }
    // 只有一级菜单
    if (first && !hasChild) route = handleFirstRoute(item, route)

    // 如果menuUrl是完整http地址则通过iframe打开
    if (isHttpUrl) route = handleHttpRoute(item, route)

    // 如果是动态表单需要渲染固定组件
    route = handleDynamicFormRoute(item, route)

    if (!first && !hasChild) {
      if (!route.path.startsWith('/worktable')) {
        router.addRoute('root', route)
      }
    }

    return route
  })

  return routes
}

// 生成 meta 信息
function generateMetaInfo(item) {
  return {
    icon: item.menuIconurl || 'example',
    noCache: !item.isCache,
    title: item.menuName ? item.menuName.replace('[PC]', '') : '',
    enTitle: item.menuEnName || item.menuName,
    params: item.parameter,
    //这些菜单都是主要的路由菜单，都可以从菜单列表进入。
    isMainRouteMenu: true,
    menuCode: item.menuCode,
    menuId: item.menuId,
    isBootstrap: true
  }
}

// 处理 path 路径
function generatePath(item, isHttpUrl, parentPath) {
  let path = `${parentPath}/${isHttpUrl ? item.menuCode : item.menuUrl}`
  // 菜单URL设置中/开头的，忽略父级URL
  if (path.indexOf('//') > -1 && !item.originalAddr) {
    let pathArr = path.split('//')
    path = '/' + pathArr[1]
  }

  return path
}

// 处理一级菜单路由
function handleFirstRoute(item, route) {
  return {
    ...route,
    icon: item.menuIconurl,
    noChild: true
  }
}

// 处理 http 链接路由
function handleHttpRoute(item, route) {
  return {
    ...route,
    meta: {
      ...route.meta,
      url: item.menuUrl
    },
    component: () => import('@/views/third-view')
  }
}

// 处理 动态表单 路由
function handleDynamicFormRoute(item, route) {
  let params = item.parameter
  if (params && params.length > 10 && (params.indexOf('{') > -1 || params.indexOf('}') > -1)) {
    try {
      let paramJson = JSON.parse(params)
      // 如果是动态表单需要渲染固定组件
      if (paramJson && paramJson.menu_type === 'DYNAMIC_FORM') {
        return {
          ...route,
          path: route.path + `/:formId`,
         // component: () => import('@/views/form-render/FormRender.vue')
          component: GushenFormRender.FormRender
        }
      } else {
        return route
      }
    } catch (e) {
      console.log(new Error(e))
    }
  } else {
    return route
  }
}

// 获取真实的动态表单路由，增加一个动态表单浏览器刷新，按钮权限获取失败 daxiong
function getRealDynamicFormPath(route) {
  let isDynamicForm = ''
  if (route.path.includes(':formId')) {
    let params = (route.meta.params && JSON.parse(route.meta.params)) || {}
    let path = JSON.parse(JSON.stringify(route.path)).replace(':formId', '')
    isDynamicForm = path + params['diy_code']
  }
  return isDynamicForm
}
