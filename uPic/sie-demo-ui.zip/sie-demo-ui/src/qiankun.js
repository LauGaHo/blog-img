import { registerMicroApps, start, initGlobalState } from 'qiankun'
import { i18n } from '@/lang'
import store from '@/store'
import Bus from '@/utils/bus'

// 需要注入到微应用的数据
const props = {
  // 基座的 i18n 翻译，基本上是通用的翻译
  messages: i18n.messages,
  // 当前语言类型
  local: i18n.locale,
  // 子应用关闭系统页签方法
  closeTagView: view => {
    Bus.$emit('close-tag-from-micro', view)
  }
}

// 是否生成环境
const isProd = process.env.NODE_ENV === 'production'

// 微应用部署的域名存储再 .env 文件中，打包时可根据环境替换
const VUE_APP_MICRO_URL = process.env.VUE_APP_MICRO_URL

// 微引用列表
export const apps = () => [
  {
    name: 'worktable',
    entry: isProd ? `/micro/worktable/` : `${VUE_APP_MICRO_URL}:8097`,
    container: '#mainContainer',
    activeRule: ['/worktable', '/FlowCharts', '/form-url'],
    loader: loading => store.commit('SET_MICRO_PAGE_LOADING', loading),
    props
  },
]


// 需要微应用监听的数据
const state = {
  // 国际化
  local: i18n.locale,
  // fix 修复通信国际化变量错误的问题
  locale: i18n.locale,
  // 子应用容器 loading
  pageLoading: true,
  // 需要基座添加 tag 标签页的静态路由
  staticRoute: null,
  // 全屏
  fullscreen: false,
  // 关闭的 tag 名
  closeTagName: null,
  // 需要剩下的 tag 名
  closeOtherTagsToName: null,
  // 按钮权限列表
  authButtonList: null,
  // 子应用容器高度
  appMainHeight: 0,
  // 侧边栏展开状态
  sidebarOpened: true
}
export const action = initGlobalState(state)

