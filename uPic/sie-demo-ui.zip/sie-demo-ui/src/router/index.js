import Vue from 'vue'
import VueRouter from 'vue-router'
import GsFormRender from '@gushen/gushen-form-render'

Vue.use(VueRouter)

export const routes = [
  { path: '/login', component: () => import('@/views/login'), meta: { title: '登录', enTitle: 'Login' } },
  { path: '/portal', component: () => import('@/views/layout/Frame'), meta: { title: '门户', enTitle: 'Portal' } },
  { path: '/404', component: () => import('@/views/404'), meta: { title: '404' } },
  { path: '/third-login', component: () => import('@/views/third-login'), meta: { title: '第三方登录', enTitle: 'thirdPartyLogin' } },

  { path: '/FlowCharts/flow_details', component: () => import('@/views/layout/Frame') },
  { path: '/form-url/form-render/:formId', component: () => import('@/views/layout/Frame') },
  { path: '/sso/login', component: () => import('@/views/sso/login'), meta: { title: 'sso登录', enTitle: 'sLogin' }, hidden: true },
  {
    path: '/',
    name: 'root',
    component: () => import('@/views/layout/Layout'),
    children: [
      {
        path: 'home',
        name: 'home',
        meta: {
          title: '主页',
          enTitle: 'Home',
          icon: 'menu',
          noCache: true,
          hideInMenu: true,
          isMainRouteMenu: true,
          isBootstrap: true
        },
        component: () => import('@/views/home-page')
      },
      {
        path: 'person-info',
        name: 'personInfo',
        meta: {
          title: '个人中心',
          enTitle: 'personalCenter',
          icon: 'menu',
          noCache: true,
          hideInMenu: true,
          isBootstrap: true
        },
        component: () => import('@/views/person-info')
      },
      {
        path: 'dynamic-form/render/:formId',
        name: 'form-render',
        props: { pageMode: true },
        noCache: true,
        hidden: true,
        meta: {
          icon: '',
          title: '动态表单',
          enTitle: 'Form Render',
          noCache: true,
          hideInMenu: true,
          isMainRouteMenu: true,
          isBootstrap: true
        },
        component: GsFormRender.FormRender
      },
      {
        path: 'letters',
        name: 'letters',
        meta: {
          title: '消息中心',
          enTitle: 'letters',
          noCache: true,
          hideInMenu: true,
          isBootstrap: true
        },
        component: () => import('@/views/letters')
      },
      {
        path: 'leave/info',
        name: 'info',
        meta: {
          title: '请假信息',
          enTitle: 'Leave Info',
          noCache: true,
          hideInMenu: true,
          isBootstrap: true
        },
        component: () => import('@/views/test-menu/leave-application/info.vue')
      },
      {
        path: 'dynamic-table',
        name: 'dynamicTable',
        meta: {
          title: '动态表格（测试）',
          enTitle: 'Dynamic Table (test)',
          noCache: true,
          isBootstrap: true
        },
        component: () => import('@/views/dynamic-table')
      }
    ]
  },
  { path: '', redirect: '/portal' }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
  scrollBehavior: () => ({
    y: 0
  }),
  linkActiveClass: 'is-active'
})

export default router
