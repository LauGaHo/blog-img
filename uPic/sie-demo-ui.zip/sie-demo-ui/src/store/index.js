import Vue from "vue"
import Vuex from "vuex"

import user from '@/store/modules/user'
import app from '@/store/modules/app'
import tagsView from '@/store/modules/tagsView'
import permission from '@/store/modules/permission'
import theme from '@/store/modules/theme'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {},
  mutations: {},
  actions: {},
  modules: {
    user,
    app,
    tagsView,
    permission,
    theme,
  }
})

export const useStore = () => store

export default store