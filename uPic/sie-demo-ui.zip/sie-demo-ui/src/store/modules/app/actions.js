import _config from '@/config'
import { getButtonAuth } from '@/api/menu'
import { checkIsCollect } from '@/api/collect'
import { findTenantDefind } from '@/api/login'
import { getUserInfo } from '@/utils/auth'

const actions = {
  ToggleSideBar: ({ commit }) => {
    commit('TOGGLE_SIDEBAR')
  },
  CloseSideBar({ commit }, { withoutAnimation }) {
    commit('CLOSE_SIDEBAR', withoutAnimation)
  },
  ToggleDevice({ commit }, device) {
    commit('TOGGLE_DEVICE', device)
  },
  setActiveMenuId({ commit }, { menuId }) {
    if (!menuId) {
      commit('SET_ACTIVE_MENUID', '')
      return
    }
    commit('SET_ACTIVE_MENUID', menuId)
  },
  setAuthBTN({ commit }, { menuId }) {
    if (!menuId) {
      commit('BTNAUTH', [])
      return
    }
    commit('importTemplate', [])
    //设置按钮权限
    getButtonAuth(menuId).then(res => {
      if (res.code === 800) {
        if (!res.data) 
          return
        
        sessionStorage.setItem('btnAuthList', JSON.stringify(res.data))
        commit('BTNAUTH', res.data)
      }
    })
  },
  getCollectStatus({ commit }, menuData) {
    checkIsCollect({
      menuId: menuData.menuId,
      params: JSON.stringify(menuData.query)
    }).then(res => {
      if (res.code === 800) 
      {commit('CollectStatus', {
        data: res.data,
        menuId: menuData.menuId
      })}
      
    })
  },
  setActiveRoute({ commit }, route) {
    commit('SET_ACTIVE_ROUTE', route)
  },
  SetSystemSetting({ commit }) {
    const params = {
      systemCode: _config.systemCode,
      tenantId: getUserInfo().tenantId
    }
    findTenantDefind(params).then(res => {
      if (res.code === 800 && res.data) 
        commit('SET_SYSTEM_SETTING', JSON.stringify(res.data))
      
    })
  },
  setMessageCount({ commit }, msgInfo) {
    commit('SET_MESSAGE_COUNT', msgInfo)
  },
  setFullscreenGlobal({ commit }, isFull) {
    commit('SET_FULLSCREEN', isFull)
  }
}

export default actions
