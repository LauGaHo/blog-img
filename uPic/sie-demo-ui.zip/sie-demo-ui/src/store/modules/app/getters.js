import { getDicItems } from '@/utils/tool';

const getters = {
  getDicItems: () => (id) => getDicItems(id),
  sidebar: state => state.sidebar,
  avatar: state => state.avatar,
  systemCode: state => state.systemCode,
  appMainHeight: state => state.appMainHeight,
  fullscreenGlobal: state => state.fullscreenGlobal,
  tenantSystemList: state => state.tenantSystemList,
  activeTopMenuId: state => state.activeTopMenuId,
  microPageLoading: state => state.microPageLoading,
  hasCollectButton: state => state.hasCollectButton
}

export default getters