import Cookies from 'js-cookie'
import _config from '@/config'

import getters from '@/store/modules/app/getters'
import mutations from '@/store/modules/app/mutations'
import actions from '@/store/modules/app/actions'

const store = {
  state: () => ({
    sidebar: {
      opened: !+Cookies.get('sidebarStatus'),
      withoutAnimation: false
    },
    device: 'desktop',
    menuId: null,
    garbageDetail: '',
    btnAuth: [],
    importAuth: {},
    importTemplateData: [],
    collectStatus: null,
    activeRoute: '',
    systemSetting: '',
    messageCount: 0,
    unreadLetters: [],
    systemCode: _config.systemCode,
    portalLogo: '',
    // 当前用户可以切换的系统列表
    systems: [],
    // 系统管理可见的系统列表
    tenantSystemList: [],
    // 右侧内容主区域高度
    appMainHeight: 0,
    pageAllData: {},
    fullscreenGlobal: false,
    // 紧凑式布局下，激活的一级菜单menuId
    activeTopMenuId: null,
    // 微应用页面加载的loading
    microPageLoading: false,
    // 是否显示右下需求反馈按钮
    hasCollectButton: false
  }),
  getters,
  mutations,
  actions
}

export default store
