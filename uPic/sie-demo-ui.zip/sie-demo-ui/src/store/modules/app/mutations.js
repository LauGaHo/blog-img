import Cookies from 'js-cookie'

const mutations = {
  // 保存页面所有接口数据
  SAVE_PAGE_DATA: (state, apiObj) => {
    let pageAllData = state.pageAllData
    let routeName = state.activeRoute.name
    let currentPageData = pageAllData[routeName]
    if (!currentPageData) 
    {pageAllData[routeName] = {...apiObj}}
    else 
    {state.pageAllData[routeName] = {
      ...currentPageData,
      ...apiObj
    }}
    
  },
  TOGGLE_SIDEBAR: state => {
    if (state.sidebar.opened) 
      Cookies.set('sidebarStatus', 1)
    else 
      Cookies.set('sidebarStatus', 0)
    
    state.sidebar.opened = !state.sidebar.opened
    state.sidebar.withoutAnimation = false
  },
  CLOSE_SIDEBAR: (state, withoutAnimation) => {
    Cookies.set('sidebarStatus', 1)
    state.sidebar.opened = false
    state.sidebar.withoutAnimation = withoutAnimation
  },
  TOGGLE_DEVICE: (state, device) => {
    state.device = device
  },
  BTNAUTH: (state, buttonList) => {
    state.btnAuth = buttonList
    // console.log(buttonList)
  },
  IMPORTAUTH: (state, importAuth) => {
    state.importAuth = importAuth
  },
  importTemplate: (state, data) => {
    state.importTemplateData = data
  },
  GARBAGE_DETAIL: (state, garbageDetail) => {
    state.garbageDetail = garbageDetail
  },
  CollectStatus: (state, collectStatus) => {
    state.collectStatus = collectStatus
  },
  SET_ACTIVE_ROUTE: (state, route) => {
    state.activeRoute = route
  },
  SET_SYSTEM_SETTING(state, setting) {
    state.systemSetting = setting
    localStorage.setItem('systemSetting', setting)
  },
  SET_MESSAGE_COUNT(state, msgInfo) {
    state.messageCount = msgInfo.count
    state.unreadLetters = msgInfo.msgData
  },
  SET_PORTALLOGO(state, logo) {
    state.portalLogo = logo
    localStorage.setItem('portalLogo', logo)
  },
  SET_ACTIVE_MENUID(state, menuId) {
    state.menuId = menuId
    localStorage.setItem('menuId', menuId)
  },
  SET_FIELD_LIST(state, fieldList) {
    state.fieldList = fieldList
    localStorage.setItem('aa', fieldList)
  },
  SET_SYSTEMS(state, systems) {
    state.systems = systems
    localStorage.setItem('systems', systems)
  },
  SET_TENANT_SYSTEM_LIST(state, systems) {
    state.tenantSystemList = systems
  },
  SET_APP_MAIN_HEIGHT(state, height) {
    state.appMainHeight = height
  },
  SET_FULLSCREEN(state, isFull) {
    state.fullscreenGlobal = isFull
  },
  SET_ACTIVE_TOP_MENU_ID(state, id) {
    state.activeTopMenuId = id
  },
  SET_MICRO_PAGE_LOADING(state, isLoading) {
    state.microPageLoading = isLoading
  },
  SET_COLLECT_BUTTON_STATUS(state, status) {
    state.hasCollectButton = status
  }
}

export default mutations
