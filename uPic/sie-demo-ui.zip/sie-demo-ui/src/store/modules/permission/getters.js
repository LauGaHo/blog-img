const getters = {
  permission_routers: state => state.routers,
}

export default getters