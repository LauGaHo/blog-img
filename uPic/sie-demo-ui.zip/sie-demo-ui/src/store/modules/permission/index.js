import getters from '@/store/modules/permission/getters'
import mutations from '@/store/modules/permission/mutations'
import actions from '@/store/modules/permission/actions'

const store = {
  state: () => ({
    routers: []
  }),
  getters,
  mutations,
  actions
}

export default store