import { routes as constantRouterMap } from '@/router'

const mutations = {
  // 添加路由
  SET_ROUTERS: (state, routers) => {
    // 初始值为 undefined, 并不是 constantRouterMap
    state.routers = state.routers
      ? [...state.routers, ...routers.remoteRouters]
      : [...constantRouterMap, ...routers.remoteRouters];
  }
}

export default mutations