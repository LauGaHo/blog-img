const getters = {
  visitedViews: state => state.visitedViews,
  cachedViews: state => state.cachedViews,
}

export default getters