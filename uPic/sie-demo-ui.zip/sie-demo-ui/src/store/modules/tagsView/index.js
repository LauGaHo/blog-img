import getters from '@/store/modules/tagsView/getters'
import mutations from '@/store/modules/tagsView/mutations'
import actions from '@/store/modules/tagsView/actions'

const store = {
  state: () => ({
    visitedViews: [],
    cachedViews: []
  }),
  getters,
  mutations,
  actions
}

export default store