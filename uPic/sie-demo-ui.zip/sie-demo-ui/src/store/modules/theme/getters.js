const getters = {
  themeColor: state => state.themeColor,
  theme: state => state.theme,
  navbarTheme: state => state.navbarTheme,
  layoutConfig: state => state.layoutConfig
}

export default getters