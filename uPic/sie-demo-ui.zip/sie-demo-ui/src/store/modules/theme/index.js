import { getCookieInDomain } from '@/utils/theme'
import getters from '@/store/modules/theme/getters'
import mutations from '@/store/modules/theme/mutations'
import actions from '@/store/modules/theme/actions'

const normalNavbarTheme = { label: '普通', icon: '', key: 'normal', colors: ['#4ea5ed', '#3c7fff'] }

const store = {
  state: () => ({
    theme: getCookieInDomain('theme') || 'default',
    themeColor: getCookieInDomain('themeColor'),
    navbarTheme: getCookieInDomain('navbarTheme', 'getJSON') || normalNavbarTheme,
    layoutConfig: getCookieInDomain('layoutConfig') || 'default',
    layoutConfigureParams:[],
    panelUserId:null,
    selectPanelData:[],
  }),
  getters,
  mutations,
  actions
}

export default store