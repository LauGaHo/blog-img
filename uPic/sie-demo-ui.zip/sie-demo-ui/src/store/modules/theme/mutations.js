const mutations = {
  SET_THEME(state, theme) {
    state.theme = theme;
  },
  SET_THEME_COLOR(state, color) {
    state.themeColor = color
  },
  SET_NAVBAR_THEME(state, val) {
    state.navbarTheme = _.cloneDeep(val)
  },
  SET_LAYOUT_CONFIG(state, config) {
    state.layoutConfig = config
  },
  SET_LAYOUT_CONFIGURE_PARAMS(state, arr) {
    state.layoutConfigureParams = arr;
  },
  SET_PANEL_USER_ID(state, id) {
    state.panelUserId = id;
  },
  SET_SELECT_PANEL_DATA(state, arr) {
    state.selectPanelData = arr;
  },
}

export default mutations