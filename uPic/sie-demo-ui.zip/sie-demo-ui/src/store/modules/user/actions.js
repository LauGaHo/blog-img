import { setToken, removeToken } from '@/utils/auth'
import Watermark from '@/utils/watermark'
import { encode } from '@/utils/base64'
import { login, getInfo, logout, autoLogin } from '@/api/login'
import { unreadMessageTotal } from '@/api/letters'

const actions = {
  // 登录
  Login({ commit }, userInfo) {
    const account = userInfo.account.trim()
    const password = encode(userInfo.password.trim())
    return new Promise((resolve, reject) => {
      login(account, password).then(response => {
        const data = response;
        const token = data.data['authorization'] || data.token
        commit('SET_USER_FULL_NAME', data.data.userFullName)
        localStorage.userInfo = JSON.stringify(data.data)
        setToken(token, data.data['refresh-authorization'])
        resolve(data)
      }).catch(error => {
        console.warn(error)
        reject(error)
      })
    })
  },
  // 根据token和systemCode自动获取用户信息和菜单
  AutoLogin({ commit }, systemInfo) {
    return new Promise((resolve, reject) => {
      let { token, systemCode, ps } = systemInfo
      autoLogin(systemCode)
        .then(response => {
          const data = response
          const userData = data.data || {}
          token = data.data['authorization'] || token
          setToken(token, data.data['refresh-authorization'])
          commit('SET_TOKEN', token)
          commit('SET_ISSUPERADMIN', userData.isSuperAdmin)
          commit('SET_SUPERVISOR', userData.isAdmin)
          commit('SET_USERID', userData.userId)
          commit('SET_TENANTID', userData.tenantId)
          commit('SET_USER_FULL_NAME', userData.userFullName)
          userData.ps = ps
          resolve()
        })
        .catch(error => {
          console.warn(error)
          reject(error)
        })
    })
  },
  // 获取用户信息
  GetInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      getInfo(state.token)
        .then(response => {
          const data = response.data
          if (typeof data.authority != 'undefined' && data.authority != null && data.authority !== '')
            commit('SET_AUTHORITY', data.authority)
          else
            reject('getInfo: authority must be a non-null string!')

          if (!data.avatar)
            data.avatar = 'http://bpic.588ku.com/element_origin_min_pic/01/30/26/24573b0a9382ae2.jpg'

          commit('SET_ID', data.id)
          commit('SET_FIRSTNAME', data.firstName)
          commit('SET_LASTNAME', data.lastName)
          commit('SET_PHONE', data.phone)
          commit('SET_EMAIL', data.email)
          commit('SET_AVATAR', data.avatar)
          commit('SET_AUTHORITY', data.authority)
          commit('SET_CUSTOMERID', data.customerId)
          commit('SET_TENANTID', data.tenantId)
          commit('SET_ADDITIONALINFO', data.additionalInfo)
          resolve(response)
        })
        .catch(error => {
          reject(error)
        })
    })
  },

  // 前端 登出
  FedLogOut({ commit }) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      removeToken()
      resolve()
    })
  },

  // 登出
  LogOut() {
    console.log('退出登录')
    return new Promise((resolve, reject) => {
      logout({})
        .then(() => {
          Watermark.out()
          localStorage.removeItem('watermarkBean')
          sessionStorage.removeItem('visited-views')
          removeToken()
          resolve()
        })
        .catch(error => {
          reject(error)
        })
    })
  },

  // 获取站内消息数量
  GetUnreadTotal({ commit }) {
    const params = {
      readStatus: 0,
      systemCodes: [window._config.systemCode]
    }
    return new Promise((resolve, reject) => {
      unreadMessageTotal({ params })
        .then((res) => {
          if (res.code === 800) {
            commit('SET_UNREAD_TOTAL', res.data)
            resolve(res.data)
          }
          reject(res.data)
        })
        .catch(error => {
          reject(error)
        })
    })
  },
}

export default actions
