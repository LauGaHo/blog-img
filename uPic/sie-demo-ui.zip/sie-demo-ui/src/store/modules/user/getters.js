const getters = {
  isSuperAdmin: state => state.isSuperAdmin === 1,
  isSupervisor: state => state.isSupervisor === 2,
  lang: state => state.lang,
  userId: state => state.userId,
  tenantId: state => state.tenantId,
  unread: state => state.unread,
}

export default getters