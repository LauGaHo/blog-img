import Cookies from 'js-cookie'
import { getToken, getLanguage } from '@/utils/auth'

import getters from "@/store/modules/user/getters"
import mutations from "@/store/modules/user/mutations"
import actions from "@/store/modules/user/actions"

const store = {
  state: () => ({
    token: getToken(),
    email: '',
    authority: '',
    customerId: {},
    additionalInfo: {},
    userLimit: Cookies.get('USER_LIMIT'),

    userState: 0,
    isSuperAdmin: localStorage.isSuperAdmin || false,
    tenantId: localStorage.tenantId || "",
    tenantName: localStorage.tenantName,
    isSupervisor: localStorage.isSupervisor || false,
    userId: localStorage.userId || "",
    userFullName: localStorage.userFullName || "",
    userHeadImgUrl: localStorage.getItem('userHeadImgUrl'),
    lang: getLanguage(),
    langUpdata: false,
    rolesList: [],
    // 未读站内消息数量
    unread: 0
  }),
  getters,
  mutations,
  actions
}

export default store
