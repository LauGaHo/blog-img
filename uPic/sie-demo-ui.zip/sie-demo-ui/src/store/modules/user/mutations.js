import Cookies from 'js-cookie'
import config from '@/config'
import { setLanguage } from '@/utils/auth'

const mutations = {
  SET_ROLES_LIST: (state, rolesList) => {
    state.rolesList = rolesList;
  },
  SET_LANG: (state, lang) => {
    state.langUpdata = !state.langUpdata
    state.lang = lang
    localStorage.setItem('lang', lang)
    setLanguage(lang)
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_ID: (state, id) => {
    state.id = id
  },
  SET_FIRSTNAME: (state, firstName) => {
    state.firstName = firstName
  },
  SET_LASTNAME: (state, lastName) => {
    state.lastName = lastName
  },
  SET_PHONE: (state, phone) => {
    state.phone = phone
  },
  SET_EMAIL: (state, email) => {
    state.email = email
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_AUTHORITY: (state, authority) => {
    state.authority = authority
  },
  SET_CUSTOMERID: (state, customerId) => {
    state.customerId = customerId
  },
  SET_TENANTID: (state, tenantId) => {
    state.tenantId = tenantId
    localStorage.tenantId = tenantId
  },
  SET_USERLIMIT: (state, code) => {
    state.userLimit = code
    Cookies.set('USER_LIMIT', code, { expires: config.cookieExpires || 1 })
  },
  SET_ADDITIONALINFO: (state, additionalInfo) => {
    state.additionalInfo = additionalInfo
  },
  SET_USERSTATE: (state, userState) => {
    state.userState = userState
  },
  SET_ISSUPERADMIN: (state, isSuperAdmin) => {
    state.isSuperAdmin = isSuperAdmin
    localStorage.isSuperAdmin = isSuperAdmin
  },
  SET_TENANTNAME: (state, tenantName) => {
    state.tenantName = tenantName
    localStorage.tenantName = tenantName
  },
  SET_USERID: (state, userId) => {
    state.userId = userId
    localStorage.userId = userId
  },
  SET_USER_FULL_NAME: (state, userFullName) => {
    state.userFullName = userFullName
    localStorage.userFullName = userFullName
  },
  SET_SUPERVISOR: (state, isSupervisor) => {
    localStorage.isSupervisor = isSupervisor
  },
  setUserHeadImgUrl(state, url) {
    state.userHeadImgUrl = url
    localStorage.setItem('userHeadImgUrl', url)
  },
  SET_UNREAD_TOTAL(state, unread) {
    state.unread = unread
  },
}

export default mutations
