/** 公用的一些方法或属性放在这里 */
import nameAuth from "./name-auth";

export default {
  data() {
    return {
      // 全局组件尺寸控制
      compSize: {
        form: 'medium',
        table: 'small'
      },
    }
  },
  methods: {
    // 检验请求是否成功
    reqIsSucceed(res) {
      const passCodes = [200, 800]
      return passCodes.includes(Number(res.code))
    },
    // 菜单翻译
    langTitle(target) {
      if (target.meta.tagTitle) return target.meta.tagTitle
      if (this.$i18n.locale === 'en-us') {
        return target.meta.enTitle || target.meta.title;
      } else {
        return target.meta.title || '';
      }
    },
    // 获取时候有该功能的权限
    isHaveBtnAuth(btnText) {
      const val = nameAuth[btnText]
      return (
        this.$store.state.app.btnAuth.findIndex(item => val ? item.resourceName === btnText : item.resourceCode === btnText) > -1
      );
    },
    getBtnAuthInfo(btnText) {
      return this.$store.state.app.btnAuth.find(item => item.resourceName === btnText)
    }
  }
}