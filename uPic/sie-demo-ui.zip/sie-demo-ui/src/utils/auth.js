import Cookies from 'js-cookie'
import config from '@/config'
import Storage from './storage'

export const USER_INFO = 'userInfo'
const GU_SHEN_TOKEN = 'GuShen_Token'
const PWD_KEY = 'GuShen-PS'
const GU_SHEN_REFRESH_TOKEN = 'Gushen_Refresh_token'
const LANG_KEY = 'GS_LANG'
const storage = new Storage('GUSHEN')
const { cookieExpires } = config

// 获取token
export function getToken() {
  return Cookies.get(GU_SHEN_TOKEN)
}
// 获取系统语言
export function getLanguage() {
  return Cookies.get(LANG_KEY, { domain: getCookieDomain() })
}
// 设置系统语言
export function setLanguage(value) {
  return Cookies.set(LANG_KEY, value, {
    domain: getCookieDomain(),
    expires: 30
  })
}
// 缓存菜单信息
export const setMenuList = (data) => {
  data && localStorage.setItem('menuList', JSON.stringify(data))
}

// 缓存用户信息
export const setUserInfo = userInfo => {
  if (userInfo) {
    const info = JSON.stringify(userInfo)
    // cookie存不了那么多的数据，只能改用storage
    // Cookies.set(USER_INFO, userInfo, { expires: cookieExpires || 1 })
    storage.setItem(USER_INFO, info, 1)
  }

}

export const getRefreshToken = () => {
  return Cookies.get(GU_SHEN_REFRESH_TOKEN) || ''
}

// 缓存token失效后当前的路由
export const setTokenOutRoute = (href) => {
  sessionStorage.setItem('tokenOutRoute', href)
}
// 返回错误信息，兼容旧数据的报错
export const errorMsg = (lang, response) => {
  if (response === 401 || response === 500) 
    return lang === 'en-us' ? 'The system Token is invalid. Log out and log in again' : '系统Token已经失效，请退出重新登录'
  else if (response === 504) 
    return lang === 'en-us' ? 'Server request times out' : '服务器请求超时'
  else 
    return lang === 'en-us' ? response.data.msg_en || response.data.msg : response.data.msg
  
}

export const setPwdVal = (pwd) => {
  Cookies.set(PWD_KEY, pwd, {
    expires: cookieExpires || 1,
    domain: getCookieDomain()
  })
}
export const setToken = (token, refreshToken) => {
  const domain = getCookieDomain();
  Cookies.set(GU_SHEN_TOKEN, token, {
    expires: cookieExpires || 1,
    domain
  })
  Cookies.set(GU_SHEN_REFRESH_TOKEN, refreshToken, {
    expires: cookieExpires || 1,
    domain
  })
}

// 获取用户信息
export const getUserInfo = () => {
  // const userInfo = Cookies.get(USER_INFO)
  const userInfo = storage.getItem(USER_INFO)
  // console.log('userInfo', typeof (userInfo))
  let userInfoJson = typeof (userInfo) == 'object' ? userInfo : JSON.parse(userInfo);
  // if (userInfo) return JSON.parse(userInfo)
  // else return ''
  return userInfoJson || ''
}

export function getPwd() {
  return Cookies.get(PWD_KEY)
}

export function removeToken() {
  const domain = getCookieDomain();
  Cookies.remove(USER_INFO)
  Cookies.remove(GU_SHEN_TOKEN, {
    expires: -1,
    domain
  })
  Cookies.remove(GU_SHEN_REFRESH_TOKEN, {
    expires: -1,
    domain
  })
}

export function setParentTenantId(parentTenantId) {
  storage.setItem('parentTenantId', parentTenantId)
}

// 从localStorage中清除租户信息
export function removeTenantInfo() {
  localStorage.removeItem('isSuperadmin')
  localStorage.removeItem('tenantId')
  localStorage.removeItem('tenantName')
  localStorage.removeItem('userId')
  localStorage.removeItem('userInfo')
}
export function getCookieDomain() {
  if (process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'docker') {
    const domain = document.domain
    const ipReg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
    // 如果是IP地址访问直接用IP
    if (ipReg.test(domain)) return domain;
    // 返回一级域名
    return document.domain.split('.').slice(-2).join('.')
  }
  //本地开发环境无需指定域名
  return ''
}
// 字段权限分类
export function fieldsAuthSub(data) {
  let man = {
    hidden: [],
    encrypt: []
  }
  if (Array.isArray(data)) 
  {data.forEach(item => {
    // 隐藏
    if (item.hiddenFlag === 1) 
      man.hidden.push(item.name);
      
    // 加密
    if (item.encryptFlag === 1) 
      man.encrypt.push(item.name);
      
  })}
  
  return man
}
