import * as dd from 'dingtalk-jsapi'
import { dingdingLogin } from '@/api/dingding'
import { setToken, setUserInfo, setParentTenantId } from '@/utils/auth'
import store from '@/store'


// 钉钉登录
export function ddLogin() {
  // alert('href' + window.location.href)
  var d = new Date();
  // 获取地址参数
  var query = window.location.search.substring(1);
  var pair = query.split("=")
  let corpId = pair[1]
  // 错误标识位
  let errFlag = 0
  // 获取缓存token
  let tokenObj = localStorage.getItem('dingdingToken') ? JSON.parse(localStorage.getItem('dingdingToken')) : false
  // tokenObj = false
  // // 每5分钟更新一次token
  // alert('tokenObj：' + JSON.stringify(tokenObj))
  // alert('tokenObjFlag：' + !tokenObj || (d.getTime() - tokenObj.time > 300))
  if (!tokenObj || (d.getTime() - tokenObj.time > 300)) {
    // corpId获取后5分钟内有效，使用一次即刻失效
    dd.runtime.permission.requestAuthCode({
      corpId,
      onSuccess: function (info) {
        dingdingLogin(info.code, corpId).then(res => {
          // 设置缓存
          tokenObj = { token: res.data.authorization || res.token, tokenInfo: res, time: d.getTime() }
          // alert('onSuccess tokenObj：' + JSON.stringify(tokenObj))
          localStorage.setItem('dingdingToken', JSON.stringify(tokenObj))
          // 更新cookie及个人信息
          setTokenInfo()
        })
      },
      onFail: function (err) {
        errFlag = err
      }
    })
  }
  if (errFlag == 0) {
    setTokenInfo()
    // 返回token
    return tokenObj.token
  } else {
    alert(JSON.stringify(errFlag))
  }
}

function setTokenInfo() {
  // alert('setTokenInfo')
  let tokenObj = localStorage.getItem('dingdingToken') ? JSON.parse(localStorage.getItem('dingdingToken')) : false
  // alert('setTokenInfo tokenObj' + tokenObj)
  let res = tokenObj.tokenInfo
  // alert('setTokenInfo res' + JSON.stringify(res))
  setToken(res.data.authorization, res.data['refresh-authorization'])
  setUserInfo(res.data)
  setParentTenantId(res.data.parentTenantId)
  store.commit('SET_USERLIMIT', res.data.useLimitCode)
  store.commit('SET_TENANTID', res.data.tenantId)
  store.commit('SET_USERID', res.data.userId)
  if (res.data.userHeadImgUrl !== 'defaultImgUrl' && res.data.userHeadImgUrl !== '') {
    store.commit('setUserHeadImgUrl', res.data.userHeadImgUrl)
  } else {
    // 如果返回defaultImgUrl，要清除缓存，使用默认头像
    store.commit('setUserHeadImgUrl', '')
  }
}