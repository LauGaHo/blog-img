import { getImportMenuCode } from '@/api/menu'
import ImportData from '@/components/ImportData'
export default {
  components: {
    ImportData
  },
  data() {
    return {
      importInfo: null,
      importId: ''
    }
  },
  methods: {
    async handleImport() {
      const { meta } = this.$route
      const resAuth = await getImportMenuCode(meta.menuCode, 1)
      if (resAuth.data && resAuth.data.importH) {
        this.importInfo = resAuth.data
        const { importH } = resAuth.data
        if (importH) 
          this.importId = importH.importId
        
        this.$refs.importData.dialogVisible = true
      } else 
      {this.$message.warning('请先设置导入模板数据！')}
      
    },
    async handleExport() {
      const { meta } = this.$route
      const resAuth = await getImportMenuCode(meta.menuCode, 1)
      if (resAuth.data && resAuth.data.file) {
        const { file } = resAuth.data
        if (file && file.filePath) 
          window.open(file.filePath)
        
      } else 
      {this.$message.warning('请先设置导入模板数据！')}
      
    }
  }
}
