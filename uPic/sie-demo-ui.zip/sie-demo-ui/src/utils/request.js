import axios from 'axios'
import { Base64 } from 'js-base64'
import { JSEncrypt } from 'jsencrypt'
import _config from '@/config'
import store from '@/store'
import Message from '@/utils/onlyMsgBox'
import { toFormData, getApiName, saveApiData } from '@/utils'
import { setToken, getToken, getRefreshToken, removeToken, setTokenOutRoute, errorMsg, getLanguage } from '@/utils/auth'

// 多系统绑定一个全局网关到window里面（作用： 方便运维打包自己可以修改网关）
(function () {
  if (process.env.NODE_ENV !== 'development') {
    if (!window.VUE_APP_SERVERAPI && process.env.VUE_APP_SERVERAPI) {
      window.VUE_APP_SERVERAPI = process.env.VUE_APP_SERVERAPI;
    }
  } else {
    window.VUE_APP_SERVERAPI = process.env.VUE_APP_SERVERAPI
  }
})()

// create an axios instance
const service = axios.create({
  // api的base_url
  baseURL: window.VUE_APP_SERVERAPI,
  // baseURL: 'https://api.gushen.sieiot.com',
  timeout: 50000, // request timeout
  headers: {
    'Access-Control-Allow-Origin': '*'
  }
})
// request interceptor
service.interceptors.request.use(
  config => {
    // VUE_APP_BASEAPI请求有值代表2021服务单独走api网关，其它服务功能使用VUE_APP_SERVERAPI
    if (!!process.env.VUE_APP_BASEAPI && config.url.indexOf('api/base') > -1) {
      config.baseURL = process.env.VUE_APP_BASEAPI;
    }
    if (config.url.indexOf('/api/file/iot-base-attachment/single/file-upload') !== -1) {
      config.timeout = 1000000;
    }
    // 让每个请求携带token
    let token = getToken()
    if (token) {
      const route = store.state.app.activeRoute
      const app = service.$app
      let pageTitle = route?.meta?.title ?? ''
      let pageEnTitle = (route?.meta?.enTitle ?? route?.meta?.title) || ''
      if (app && app.langTitle) {
        pageTitle = app.langTitle(route);
      }
      config.headers['authorization'] = token
      config.headers['refresh-authorization'] = getRefreshToken()
      //添加用户行为分析 headers
      const pathName = window.location.pathname === '/' ? 'portal' : window.location.pathname
      config.headers['requestMenuUrl'] = Base64.encode(pathName)
      config.headers['pageName'] = Base64.encode(pageTitle)
      config.headers['pageEnName'] = Base64.encode(pageEnTitle)
      config.headers['controllerURL'] = Base64.encode(config.url)
      config.headers['systemCode'] = Base64.encode(_config.systemCode)
      config.headers['loginForm'] = Base64.encode('PC')
      if (config.contentType === 'application/x-www-form-urlencoded;charset=UTF-8') {
        config.headers['Content-type'] = config.contentType
        config.data = toFormData(config.data)
      }
      //处理字段权限
      setFieldPrivInfo(config)
    }
    return config
  },
  error => {
    Promise.reject(error)
  }
)

/**
 * 处理字段权限
 */
export const setFieldPrivInfo = config => {
  //判断是否需要清空menuId
  //过滤公共接口关键字数组
  let apiUrlArr = [
    'find-resource',
    'find-user-menu',
    'sockjs-node/info',
    'base-tenant-system/find-tenant-defined',
    '/dictionary/dic-items/get-dictype',
    '/portal-favourite/save-one-click',
    '/base-user/update-pwd',
    '/base-exception/save',
    '/base-rolemenu/get-keyword'
  ]
  //如果请求地址包含公共接口，则把menuId清空
  //apiUrlArr.map(item => { config.url.indexOf(item) > -1 ? sessionStorage['menuIdFlag'] = 1 : '' })
  // 修改记录。 基于
  apiUrlArr.some(item => {
    if (config.url.indexOf(item) > -1) {
      sessionStorage['menuIdFlag'] = 1
      return true
    }
    sessionStorage['menuIdFlag'] = 0
  })
  //headers赋值
  if (sessionStorage['menuIdFlag'] !== 1) {
    if (sessionStorage['menuId']) {
      config.headers["menuId"] = sessionStorage["menuId"];
    } else {
      delete config.headers["menuId"];
    }
  } else {
    delete config.headers['menuId']
  }

  // sessionStorage['menuIdFlag'] == 1 ? null : config.headers['menuId'] = sessionStorage['menuId']
  sessionStorage['menuIdFlag'] = 0

  //菜单ID
  if (config.data && (config.data._preFartherURL_ || (config.data.params && config.data.params._preFartherURL_))) {
    let url = config.data._preFartherURL_ || config.data.params._preFartherURL_
    config.headers['preControllerURL'] = Base64.encode(url)
    let menuId = localStorage.getItem('menuId')
    let key = '_fieldDataList_' + '#' + menuId + '#' + url
    let fieldData = localStorage.getItem(key)
    if (fieldData) {
      let _fieldDataList_ = JSON.parse(fieldData)
      //隐藏字段,进行删除
      const hiddenFieldList = _fieldDataList_.filter(v => v.hiddenFlag)
      hiddenFieldList.forEach(item => {
        // eslint-disable-next-line no-prototype-builtins
        if (config.data.params.hasOwnProperty(item.name))
          delete config.data.params[item.name]

      })
      //没有加密的字段，进行加密处理

      const encryptFieldList = _fieldDataList_.filter(v => v.encryptFlag)
      if (encryptFieldList.length) {
        let pubkey =
          'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCUoHGYCV0xrvQacKnd81bR5jY5ph50bGa8ixpl6siyfdL8GDStVUaatqFrfaExzg0Gi0i399ZG9xSVn5iIsdrUq4HDQHZXqfmC+Ss3GBTPkYickTUpmnPzod9AMyEDnddVD1vyfuePw1JaeEpqhEtyRs6bra8q4LtVQIdYtBmJdwIDAQAB'
        const jsencrypt = new JSEncrypt()
        jsencrypt.setPublicKey(pubkey)
        encryptFieldList.forEach(item => {
          // eslint-disable-next-line no-prototype-builtins
          if (config.data.params.hasOwnProperty(item.name))
          //没有加密，进行加密
          // eslint-disable-next-line no-prototype-builtins
          {
            if (item.hasOwnProperty('noData')) {
              let fieldContent = config.data.params[item.name]
              if (fieldContent) {
                fieldContent = JSON.stringify(fieldContent)
                //加密字段内容
                config.data.params[item.name] = jsencrypt.encrypt(fieldContent)
              }
            }
          }

        })
      }
      if (config.data.params['_preFartherURL_'])
        delete config.data.params['_preFartherURL_']

    }
    if (config.data._preFartherURL_)
      delete config.data._preFartherURL_

  }
}
// respone interceptor
service.interceptors.response.use(
  response => {
    let obj = {
      [getApiName(response.config.url, response.config.baseURL)]: response.data
    }
    // saveApiData(obj)
    let successCodes = [200, 800, 500]
    const lang = getLanguage() || 'zh-cn'


    if (!successCodes.includes(response.data.code) && response.data.status !== 'S' && !response.config.responseType) {
      // 登录页重定向的域名
      const loginHost = process.env.NODE_ENV !== 'development' ? (window?.VUE_AUTH_API ?? '') : ''

      if (response.data.portalType === 'midea') {
        localStorage.setItem('urlLogout', response.data.urlLogout)
        localStorage.setItem('urlLogin', response.data.urlLogin)
        localStorage.setItem('portalType', 'midea')
        let service = window.location.origin + '/midea-login?redirect=' + window.location.pathname
        window.location.href = response.data.urlLogin + '?service=' + encodeURIComponent(service)
        return Promise.resolve(response.data)
      }

      if (response.data.code == -1) {
        //lishuai say:code=-1为登录token生效
        Message.error({
          message: errorMsg(lang, response),
          type: 'error',
          duration: 3 * 1000,
          customClass: 'zindex'
        })
        // 失效时候当前的路由。
        setTokenOutRoute(window.location.href)
        removeToken()
        // sso登录处理
        if (response.data.portalType === 'sso') {
          localStorage.setItem('urlLogout', response.data.urlLogout);
          localStorage.setItem('urlLogin', response.data.urlLogin);
          localStorage.setItem('portalType', response.data.portalType);
          localStorage.setItem('portalCode', response.data.portalCode);
          // 重定向到sso登录页面
          window.location.href = response.data.urlLogin
          return Promise.resolve(response.data);
        }
        setTimeout(() => {
          if (process.env.NODE_ENV !== 'development')
            window.location.href = `${loginHost}/login`
          else
            window.location.href = '/login'

        }, 1000)
      }
      // 请求地图数据没有code、data，特殊处理
      if (response.config.url.includes('_full.json'))
        return Promise.resolve(response.data)


      Message.error({
        message: errorMsg(lang, response),
        type: 'error',
        duration: 3 * 1000,
        customClass: 'zindex',
        dangerouslyUseHTMLString: true
      })
    }
    //更新token
    if (response.headers.authorization)
      setToken(response.headers.authorization, response.headers['refresh-authorization'])

    //bpm 兼容
    if (response.config.url.indexOf('bpm/') > -1 && response.data.code === 800)
      response.data.status = 'S'

    return response.config.importFlag ? Promise.resolve(response) : Promise.resolve(response.data)
  },

  error => {
    const lang = getLanguage() || 'zh-cn'
    let errorCode = error.response ? error.response.status : ''

    // 登录页重定向的域名
    const loginHost = window.VUE_AUTH_API || ''
    if (errorCode === 401) {
      Message.error({
        message: errorMsg(lang, 401),
        type: 'error',
        duration: 3 * 1000,
        customClass: 'zindex'
      })
      // 失效时候当前的路由。
      setTokenOutRoute(window.location.href)
      setTimeout(() => {
        window.localStorage.removeItem('watermarkData')
        if (process.env.NODE_ENV !== 'development')
          window.location.href = `${loginHost}/login`
        else
          window.location.href = '/login'

      }, 1000)
    }
    if (errorCode === 500) {
      if (
        //Token失效的情况
        error.response.data.message.indexOf('OAuth2TokenRelayFilter') !== -1 ||
        error.response.data.message === '-1'
      ) {
        Message.error({
          message: errorMsg(lang, 500),
          type: 'error',
          duration: 3 * 1000,
          customClass: 'zindex'
        })
        // 失效时候当前的路由。
        setTokenOutRoute(window.location.href)
        removeToken()
        setTimeout(() => {
          window.localStorage.removeItem('watermarkData')
          if (process.env.NODE_ENV !== 'development')
            window.location.href = `${loginHost}/login`
          else
            window.location.href = '/login'

        }, 1000)
        return false
      }
    }

    const data = error.response ? error.response.data : null
    if (data) {
      let errMsg = data.message
      Message.error({
        message: errMsg,
        type: 'error',
        duration: 3 * 1000,
        customClass: 'zindex'
      })
    }
    // 请求超时提示
    if (error.message.includes('timeout')) {
      Message.error({
        message: errorMsg(lang, 504),
        type: 'error',
        duration: 3 * 1000,
        customClass: 'zindex'
      })
    }

    return Promise.reject(error)
  }
)

export default service
