import router from '@/router'
import store from '@/store'
import { formatDynamicFormPath } from '@/views/layout/utils/dynamicFormHelper'

/*
 * 微前端架构下，无法通过 $route 获取到当前路由信息（子应用路由）
 * 通过遍历基座生成的菜单路由信息获取
 * 基座自己的静态页面在遍历完动态之后再判断需不需要遍历
 * TODO: 子应用的静态路由目前无法获取到，后续需要通过通信事件处理
 */
export function findActiveRoute(currentRoute) {
  // 静态路由表
  const staticRoutes = router.getRoutes()
  // 查找当前进入的路由信息，菜单有层级关系，所以先找到和一级菜单匹配的菜单信息
  const routes = store.state.permission.routers
  // 激活的一级菜单
  let activeTopMenu = routes.find(route => route.meta.menuId === store.state.app.activeTopMenuId)
  // 激活的菜单，优先匹配静态路由表
  const PATH = currentRoute?.path ?? window.location.pathname
  let activeMenu = staticRoutes.find(route => route.path === PATH)
  if (activeMenu) return activeMenu
  // 静态路由找不到信息，去动态路由里找
  // 如果当前激活的菜单 id 和激活的一级菜单 id 不同，查找该一级菜单下的 所有菜单及其 children
  if (store.state.app.menuId !== store.state.app.activeTopMenuId) {
    // 创建一个遍历队列
    const routeQueue = _.cloneDeep(activeTopMenu?.children ?? [])
    while(routeQueue.length > 0) {
      for (let route of _.cloneDeep(routeQueue)) {
        if (formatDynamicFormPath(route) === PATH) {
          // 如果找到匹配路由清空队列，跳出循环
          routeQueue.length = 0
          activeMenu = route
          break
        } else {
          // 如果队列里的路由没找到，向队列里再添加当前遍历路由的 children
          routeQueue.push(...(route?.children ?? []))
        }
        // 移出当前遍历过的路由
        routeQueue.shift()
      }
    }
  } else {
    return activeTopMenu
  }

  // 如果都匹配不到，可能是子应用的静态路由页面，直接返回 store.app.activeRoute
  // 子应用的静态页面信息通过 qiankun 的通信发送到基座
  if (!activeMenu && currentRoute) {
    return store.state.app.activeRoute
  }

  return activeMenu
}