import zhLang from '@/lang/zh-CN'
import enLang from '@/lang/en-US'
import eventHub from '@/utils/event-hub'
let menuData = localStorage.getItem('lang') == 'en' ? enLang.menu : zhLang.menu;

// 监听语言切换，切换至相应的翻译包
eventHub.$on('change-lang', lang => {
  menuData = lang == 'en' ? enLang.menu : zhLang.menu;
})

export default function translationMenu(name) {
  let result = ''
  let trimName = name.replace(/\[.*\]/, '') + ''
  let clientFlag = name.match(/\[.*\]/)
  try {
    if (menuData[trimName])
      result = menuData[trimName]
    if (clientFlag && result) 
      result = `${clientFlag[0]}${result}`
    
  } catch (err) { }
  return result ? result : name
}

/**
 * //根据当前选择语言获取对应翻译
 * @param {父参数} firstName 
 * @param {子参数} secondName 
 */
export function translateLang(firstName, secondName) {
  const curLang = localStorage.getItem('lang') || 'zh-cn';
  const data = curLang == 'zh-cn' ? zhLang : enLang
  return data[firstName][secondName];
}