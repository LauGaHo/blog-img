export function isvalidUsername(str) {
  const valid_map = ['admin', 'editor']
  return valid_map.indexOf(str.trim()) >= 0
}

/* 合法uri*/
export function validateURL(textval) {
  const urlregex = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/
  return urlregex.test(textval)
}

/* 小写字母*/
export function validateLowerCase(str) {
  const reg = /^[a-z]+$/
  return reg.test(str)
}

/* 大写字母*/
export function validateUpperCase(str) {
  const reg = /^[A-Z]+$/
  return reg.test(str)
}

/* 大小写字母*/
export function validatAlphabets(str) {
  const reg = /^[A-Za-z]+$/
  return reg.test(str)
}

/* 合法手机号码 */
export function validatePhone(str) {
  const reg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/
  return reg.test(str)
}

/* 合法邮箱地址 */
export function validateEmail(str) {
  const reg = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/
  return reg.test(str)
}

/* 合法设备组名称 */
export function validateInputString(str) {
  const reg = /^[\u4E00-\u9FA5A-Za-z0-9_-]+$/
  return reg.test(str)
}

/* 合法数字 */
export function validatePoint(str) {
  const reg = /^[0-9.]+$/
  return reg.test(str)
}


/* 合法数字 */
export function validateNumber(str) {
  const reg = /^[0-9]*$/
  return reg.test(str)
}

/* 合法简体中文 */
export function validateChinese(str) {
  const reg = /^[\u4e00-\u9fa5]{0,20}$/
  return reg.test(str)
}

/* 指标最值检测 */
export function validateIndexNumber(str) {
  const reg = /^-?\d+(\.\d+)?$/
  return reg.test(str)
}

export function validateCertificateNumber(str) {
  const reg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
  return reg.test(str);
}

/* 字母数字下划线 */
export function validateAlphanumericUnderline(str) {
  const reg = /^\w+$/
  return reg.test(str);
}

/* 字母开头 */
export function validateBeginningLetter(str) {
  const reg = /^[a-zA-Z]([-_a-zA-Z0-9]{2,20})$/;
  return reg.test(str);
}

/**
 * 判断是否是json
 *
 * @param str
 * @returns {boolean}
 */
export function isJSON(str) {
  if (typeof str === 'string') 
  {try {
    JSON.parse(str)
    return true
  } catch (e) {
    return false
  }}
  
  return false
}
