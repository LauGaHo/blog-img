import { getUserInfo } from '@/utils/auth'

let watermark = {}
let concentList = []
let textConnt = ''

let setWatermark = viewform => {
  concentList = []
  let id = '1.23452384164.123412416'
  let watermarkData = window.localStorage.getItem('watermarkBean')
  watermarkData = JSON.parse(watermarkData)

  if (viewform) 
    watermarkData = { ...viewform }
  
  if (watermarkData && watermarkData.fwContent !== '' && watermarkData.fwContent !== null && watermarkData.isTakeEffect) {
    if (document.getElementById(id) !== null) 
      document.body.removeChild(document.getElementById(id))
    

    //创建一个画布
    let can = document.createElement('canvas')
    //设置画布的长宽
    can.width = 250
    can.height = 250

    let cans = can.getContext('2d')
    //旋转角度
    // cans.rotate(-15 * Math.PI / 180);
    if (watermarkData.fwRotationAngle) 
    {cans.rotate((Math.PI / 180) * watermarkData.fwRotationAngle)}
    else {
      // cans.rotate(-15 * Math.PI / 180);
    }

    cans.font = '18px Vedana'
    //设置填充绘画的颜色、渐变或者模式
    // cans.fillStyle = 'rgba(200, 200, 200, 0.40)';
    // cans.fillStyle = '#dbdbdb'
    //设置文本内容的当前对齐方式
    if (watermarkData.fwTransparent) 
      cans.globalAlpha = watermarkData.fwTransparent
    

    cans.fillStyle = '#' + watermarkData.fwColor
    let fontsty = ''
    if (watermarkData.fwFont === '宋体') 
      fontsty = 'SimSun'
    else if (watermarkData.fwFont === '黑体') 
      fontsty = 'SimHei'
    else if (watermarkData.fwFont === '微软雅黑') 
      fontsty = 'Microsoft Yahei'
    else if (watermarkData.fwFont === '楷体') 
      fontsty = 'KaiTi'
    else if (watermarkData.fwFont === '楷体') 
      fontsty = 'FangSong'
    

    let sty = watermarkData.fwFontSize + 'px' + ' ' + fontsty
    cans.font = sty
    cans.textAlign = 'left'
    //设置在绘制文本时使用的当前文本基线
    cans.textBaseline = 'Middle'
    //在画布上绘制填色的文本（输出的文本，开始绘制文本的X坐标位置，开始绘制文本的Y坐标位置）
    if (watermarkData.isView) {
      let textvalue = ''
      if (watermarkData.fwType === 'dynamic') {
        getdynamicconcent(watermarkData.fwContent)
        let _text = ''
        concentList.forEach(v => {
          _text += getUserInfo()[v]
        })
        textvalue = _text + ',' + textConnt
      } else 
      {textvalue = watermarkData.fwContent}
      
      cans.fillText(textvalue, can.width / 8, can.height / 2)
    } else 
    {cans.fillText(watermarkData.content, can.width / 8, can.height / 2)}
    

    let div = document.createElement('div')
    div.id = id
    div.style.pointerEvents = 'none'
    div.style.top = '0px'
    div.style.left = '0px'
    div.style.position = 'fixed'
    div.style.zIndex = '100000'
    div.style.overflow = 'hidden'
    // div.style.width = document.documentElement.clientWidth - 230 + 'px';
    // div.style.height = document.documentElement.clientHeight - 50 + 'px';
    div.style.width = document.documentElement.clientWidth + 'px'
    div.style.height = document.documentElement.clientHeight + 'px'
    div.style.background = 'url(' + can.toDataURL('image/png') + ') left top repeat'
    // document.getElementById('site-content').append(div)
    document.body.appendChild(div)
    return id
  }
}

function getdynamicconcent(str) {
  let _index = str.indexOf('{')
  if (_index > -1) {
    let _index2 = str.indexOf('}')
    let strArr = str.slice(_index + 1, _index2)
    str = str.slice(_index2 + 1)
    concentList.push(strArr)
    console.log('concentList', concentList)
    getdynamicconcent(str)
  } else {
    let _index = str.indexOf(',')
    if (_index > -1) {
      let _text = str.slice(_index + 1)
      textConnt = _text
    }
  }
}

// 该方法只允许调用一次
watermark.set = str => {
  let id = setWatermark(str)
  setInterval(() => {
    if (document.getElementById(id) === null) 
      id = setWatermark(str)
    
  }, 500)
  window.onresize = () => {
    setWatermark(str)
  }
}

// 在watermark.js文件中
const outWatermark = id => {
  if (document.getElementById(id) !== null) {
    const div = document.getElementById(id)
    div.style.display = 'none'
  }
}

watermark.out = () => {
  const str = '1.23452384164.123412416'
  outWatermark(str)
}

export default watermark
