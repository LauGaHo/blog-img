export default class Ws {
  constructor({ url, params, operate, onClose }) {
    let wsUrl = window.VUE_WSAPI ||`wss://websocket.sieiot.com/ws`
    if (window.WebSocket) {
      this.websocket = new WebSocket(wsUrl)
      // 建立连接 
      this.websocket.onopen = this.onopen(params)
      // 接收消息
      this.websocket.onmessage = this.onmessage(operate)
      // 连接出错
      this.websocket.onerror = this.onerror
      // 关闭连接
      this.websocket.onclose = onClose || this.onclose

      window.onclose = this.close
    }
  }
  onopen(params) {
    return async event => {
      // 绑定 websocket 服务
      this.websocket.send(JSON.stringify({ ...params }))
      return event
    }
  }
  onmessage(operate) {
    return event => {
      operate(event)
    }
  }
  close() {
    if (this.websocket.readyState !== this.websocket.CLOSED) 
      this.websocket.close()
    
  }
  // 防止 websocket 掉线，发送 params 为字符串 'heartbeat'
  send(params) {
    this.websocket.send(params)
  }
}

/**
 * 区分开发生产和测试环境的地址
 */
// function getUrl() {
//   const url = {
//     development: `ws://139.159.225.165:9004/ws`,
//     test: `wss://test.websocket.sieiot.com/ws`,
//     production: `wss://websocket.sieiot.com/ws`
//   }
//   const { host } = location
//   if (/test\.sz\.sieiot/.test(host)) 
//     return url.test
//   else if (/www\.sieiot/.test(host)) 
//     return url.production
//   else 
//     return url.development
  
// }
