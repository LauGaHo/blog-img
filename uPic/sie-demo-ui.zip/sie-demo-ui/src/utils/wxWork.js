
import { getWxLoginUrl, authWxLogin } from '@/api/wx-work'
import { setToken, setUserInfo } from '@/utils/auth'


// 获取企业微信登录URL
export async function getLoginUrl() {
  let urlData = await getWxLoginUrl()
  if (urlData.code == 800) {
    window.location.href = urlData.data
  }
}

// 通过页面返回的code和state获取token，更新登录状态，返回token
export async function wxWorkLogin() {
  let search = window.location.search.substr(1)
  var code = search.split("&")[0].split("=")[1];
  var state = search.split("&")[1].split("=")[1];
  let res = await authWxLogin(code, state)
  setToken(res.data.authorization, res.data['refresh-authorization'])
  setUserInfo(res.data)
  setParentTenantId(res.data.parentTenantId)
  store.commit('SET_USERLIMIT', res.data.useLimitCode)
  store.commit('SET_TENANTID', res.data.tenantId)
  store.commit('SET_USERID', res.data.userId)
  if (res.data.userHeadImgUrl !== 'defaultImgUrl' && res.data.userHeadImgUrl !== '') {
    store.commit('setUserHeadImgUrl', res.data.userHeadImgUrl)
  } else {
    // 如果返回defaultImgUrl，要清除缓存，使用默认头像
    store.commit('setUserHeadImgUrl', '')
  }
  return res.data.authorization || res.token
}