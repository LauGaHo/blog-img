<template>
  <div>
    <gs-dialog width="70%" top="3vh" :visible.sync="visible" :show-footer="false">
      <form-render ref="render" style="width: 96%; margin-left: 2%" :render-id="formId" type="modal"></form-render>
      <div slot="footer"></div>
    </gs-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      visible: false,
      formId: 429275137
    }
  },
  methods: {
    showDialog() {
      this.visible = true
    },
    close() {
      this.visible = false
    }
  }
}
</script>
