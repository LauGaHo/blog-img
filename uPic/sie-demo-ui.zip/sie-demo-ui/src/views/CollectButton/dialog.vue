<template>
  <gs-dialog title="意见反馈" :visible.sync="dialogFormVisible" width="40%" @save="submitFeedback">
    <el-form :model="form" :rules="rules" ref="ruleForm" :label-width="formLabelWidth">
      <el-form-item label="反馈原因" prop="reason">
        <el-select v-model="form.reason" placeholder="请选择反馈原因" clearable>
          <el-option :label="item.dicName" :value="item.dicName" v-for="item in feedback" :key="item.diId"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="详细描述" prop="desc">
        <el-input type="textarea" v-model="form.desc" placeholder="请输入意见或建议" :rows="6" maxlength="200" show-word-limit></el-input>
      </el-form-item>
      <el-form-item label="上传图片">
        <UploadImg v-if="forceUpdate" ref="uploadimg" @img="uploadFeedback" />
        <span style="color: #999; font-size: 12px">提示:(可使用ctrl+v上传图片)</span>
      </el-form-item>
    </el-form>
  </gs-dialog>
</template>

<script>
import { findDictionaryType } from '@/api/app'
import { saveException } from '@/api/base-exception'

export default {
  data() {
    return {
      forceUpdate: true,
      fileIds: [],
      feedback: [],
      dialogFormVisible: false,
      form: {
        reason: '',
        desc: ''
      },
      formLabelWidth: '100px',
      rules: {
        reason: [{ required: true, message: '请选择反馈原因', trigger: 'change' }],
        desc: [{ message: '请输入意见或建议', trigger: 'blur' }]
      }
    }
  },
  methods: {
    submitFeedback() {
      this.$refs['ruleForm'].validate(async valid => {
        if (valid) 
        {try {
          const result = await saveException({
            params: {
              ibeOutside: this.form.reason,
              ibeFunctionName: document.querySelector('.tags-view-item.router-link-exact-active').innerText.trim(),
              ibeServiceUrl: this.$route.fullPath,
              ibeDeviceType: 'PC',
              ibeExceptionDesc: this.form.desc,
              fileIds: this.fileIds
            }
          })
          if (result.code === 800) {
            this.dialogFormVisible = false
            this.$message.success('提交成功，感谢您的反馈，我们会尽快处理')
            this.$refs['ruleForm'].resetFields()
            this.fileIds = []
            this.forceUpdate = false
          }
        } catch (e) {
          this.$message.warning(e)
        }}
        else 
        {return false}
        
      })
    },
    async uploadFeedback(data, type) {
      if (type === 'add') 
      {this.fileIds.push(data.fileId)}
      else if (type === 'delete') 
      {this.fileIds.splice(
        this.fileIds.findIndex(f => f === data.fileId),
        1
      )}
      
    },
    open() {
      this.dialogFormVisible = true
      this.forceUpdate = true
      this.$nextTick(() => {
        document.onpaste = event => {
          if (this.dialogFormVisible) {
            const items = event.clipboardData.items
            for (let i = 0; i < items.length; i++) 
            {if (items[i].kind === 'file' && items[i].type === 'image/png') 
            {this.$refs.uploadimg.handleBeforeUpload({
              file: items[i].getAsFile()
            })}}
              
            
          }
        }
      })
    },
    async getTabs() {
      const result = await findDictionaryType('FEEDBACK_DIC')
      if (result.code === 800) 
        this.feedback = result.data
      
    }
  },
  mounted() {
    this.getTabs()
  }
}
</script>

<style lang="scss" scoped>
[aria-label='意见反馈'] {
  .el-textarea {
    min-height: 140px !important;
  }
  .el-icon-plus.avatar-uploader-icon::before {
    font-size: 14px !important;
  }
  .el-upload.el-upload--text {
    border: none !important;
  }
}
</style>
