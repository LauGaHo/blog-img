<template>
  <div class="panel-side">
    <div class="entry-btn">
      <i class="el-icon-arrow-left el-icon"></i>
    </div>
    <div class="side-tool">
      <div class="collect" draggable="true" :class="{ active: iscollect }" @click="handleCollet">
        <a v-if="iscollect" class="el-icon-star-on fav"></a>
        <a v-else class="el-icon-star-on fav"></a>
        <p class="fav-text">{{ iscollect ? '已' : '' }}收藏</p>
      </div>
      <div class="feedback" @click="openFeedback">
        <img src="@/assets/images/feedback.png" width="20" alt="意见反馈" />
        <p class="fav-text">意见反馈</p>
        <Dialog ref="dialogDom" />
      </div>
      <el-popover placement="left" class="qr-popover" width="150" trigger="hover">
        <vue-qr :margin="0" :text="qrcodeContent" :size="126"></vue-qr>
        <div class="feedback" slot="reference" @click="showDemand">
          <img src="@/assets/images/demand.png" width="20" alt="需求收集" />
          <p class="fav-text">需求收集</p>
        </div>
        <demand-collection ref="demand"></demand-collection>
      </el-popover>
    </div>
  </div>
</template>
<script>
import { setCollect, deleteCollectById } from '@/api/collect'
import DemandCollection from './demand'
import VueQr from 'vue-qr'
import Dialog from './dialog'

export default {
  components: {
    Dialog,
    DemandCollection,
    VueQr
  },
  data() {
    return {}
  },
  computed: {
    iscollect() {
      return this.$store.state.app.collectStatus ? this.$store.state.app.collectStatus.data : null
    },
    menuId() {
      return this.$store.state.app.collectStatus ? this.$store.state.app.collectStatus.menuId : ''
    },
    qrcodeContent() {
      return 'http://dev.mobile.sieiot.com/#/?form_id=429353855'
    }
  },
  mounted() {
    this.$bus.$on('close-demand', () => {
      this.$refs.demand.close()
    })
  },
  methods: {
    openFeedback() {
      this.$refs.dialogDom.open()
    },
    showDemand() {
      this.$refs.demand.showDialog()
    },
    async handleCollet() {
      if (this.iscollect) 
        await this.deleteCollectClick()
      else 
        await this.collectClick()
      
    },
    //删除
    async deleteCollectClick() {
      if (!this.iscollect.favouriteId) 
        return
      
      let res = await deleteCollectById(this.iscollect.favouriteId)
      if (this.reqIsSucceed(res)) {
        await this.$store.dispatch('getCollectStatus', {
          menuId: this.menuId,
          query: this.$route.query
        })
        this.$message.success('取消收藏成功')
      } else 
      {this.$message.error(res.msg)}
      
    },
    //收藏
    async collectClick() {
      if (!this.menuId) {
        this.$message.error('该页面不可收藏')
        return
      }
      let params = {
        menuId: this.menuId,
        functionUrl: this.$route.path.slice(1, this.$route.path.length),
        params: JSON.stringify(this.$route.query)
      }
      let res = await setCollect(params)
      if (this.reqIsSucceed(res)) {
        await this.$store.dispatch('getCollectStatus', {
          menuId: this.menuId,
          query: this.$route.query
        })
        this.$message.success('收藏成功~')
      } else 
      {this.$message.error(res.msg)}
      
    }
  }
}
</script>
<style lang="scss" scoped>
.panel-side {
  z-index: 999;
  position: fixed;
  right: -60px;
  bottom: 60px;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: 0.5s all;
  padding-right: 5px;
  .entry-btn {
    width: 25px;
    height: 50px;
    background-color: var(--color-primary);
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    .el-icon {
      font-size: 20px;
      font-weight: 700;
      color: #fff;
    }
  }
  .side-tool {
    .collect,
    .feedback {
      background-color: #fff;
      border-radius: 6px;
      box-shadow: -1px 0px 11px 0px #ccc;
      width: 55px;
      height: 55px;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      cursor: pointer;
      transition: all 0.5s;
      .fav-text {
        margin: 2px 0 0;
        font-size: 12px;
      }
      .fav {
        font-size: 28px;
        color: #333;
      }
      a.fav:hover {
        color: inherit !important;
      }
    }
    .collect.active {
      background-color: #409eff;
      .fav-text,
      .fav {
        color: #fff;
      }
    }
    .feedback {
      margin-top: 5px;
      .fav-text {
        margin: 6px 0 0;
      }
    }
  }
}
.panel-side:hover {
  right: 0;
  .entry-btn {
    opacity: 0;
  }
}
</style>
