<template>
  <div class="tempForm">
    <el-card class="box-card">
      <div class="flowSubmit">
        <el-button v-if="isSubmit" type="primary" @click="submitForm(false,true)">{{$t('button.submit')}}</el-button>
        <el-button v-if="isSubmit" type="primary" @click="submitForm(true)">{{$t('button.SaveDrafts')}}</el-button>
      </div>
      <el-form :inline="true" :model="flowForm" ref="flowForm" class="search-form-inline">
        <el-row>
          <el-col :span="8">
            <el-form-item :label="$t('common.Name')" prop="name">
              <el-input
                style="width: 300px; margin-right:15px;"
                placeholder
                clearable
                v-model="flowForm.name"
                :disabled="!editFlag"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item :label="$t('common.Sex')">
              <el-radio-group :disabled="!editFlag" v-model="flowForm.sex">
                <el-radio :label="$t('common.male')"></el-radio>
                <el-radio :label="$t('common.female')"></el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </el-card>
  </div>
</template>
<script>
import {
  addFormList,
  getFormListById,
  editFormList,
  bpmTaskService,
  startRun,
} from '@/api/worktable/startTask';
export default {
  props: {
    isSubmit: {
      //是否显示页面本来操作按钮 例如 提交，保存草稿按钮
      type: Boolean,
      default: false,
    },
    editStatus: {
      //从后端获取的 是否可编辑全部字段表格 0否 1 是 如果被驳回 这个字段应该返回1 否则0
      type: String | Number,
      default: 0,
    },
    bpm_businessKey: {
      //表单对应ID 原本从query传 得支持两种方式
      type: Number | String,
      default: '',
    },
    //需要动态设置的表单赋值 variables
    taskServiceParams: Array,
    isAddPageIn: {
      //非必要  *是否是从新增或编辑页面进来 是：从新增编辑过来的 否：从详情进来的 可用来判断是否跳转页面
      type: Boolean,
      default: true,
    },
  },
  // inject: ['getVariablesParams'],
  data() {
    return {
      flowForm: {},
      process_variables: [],
    };
  },
  computed: {
    editFlag() {
      // console.log('editStatus:',this.editStatus)
      //如果父组件传过来可以操作或者路由带参数可操作
      return this.editStatus == 1 || this.$route.query.editStatus == 1;
    },
    companyId() {
      return JSON.parse(localStorage.getItem('userInfo')).tenantId;
    },
  },
  created() {
    //如果是从新增编辑页面过的才调取这个接口  不然 varables通过props来拿
    if (this.isAddPageIn) this.bpmTaskService();
    this.getFormListById();
    // console.log(this.getVariablesParams)
  },
  methods: {
    //流程中需要设置的variables,可以拿了之后再相应赋值 有这个方法便可 不需要在此页面调用
    get_process_variables() {
      return this.taskServiceParams.map((item) => {
        if (item.name == 'tenantId') {
          item.value = this.companyId;
        }
        if (item.name == 'name') {
          item.value = '流程启动测试';
        }
        if (item.name == 'name2') {
          item.value = '流程启动测试2';
        }
        return item;
      });
    },
    startRunFlow(saveonly, businessKey) {
      let data = {
        extend: {
          tasks_assignees: [],
        },
        variables: this.process_variables,
        processDefinitionKey: 'TEST1.1', // --流程标识
        saveonly, //--是否保存标识，false为直接启动流程，true为保存草稿
        businessKey, //--业务id
        title: `流程启动测试-${businessKey}`, // --标题
        orgId: this.companyId, // --取tenantid
        companyId: this.companyId, //--取tenantid
        systemType: 'demo', // --固定为EAM
        applyPersonId: JSON.parse(localStorage.getItem('userId')), //--取user_id
      };
      startRun(data).then((res) => {
        console.log(res);
        if (res.status === 'S') {
          this.$message.success(res.msg); //返回上一级
          if (this.isAddPageIn) this.$router.go(-1);
        } else {
          // this.$message.error(res.msg);
        }
      });
    },
    //根据id查表单
    async getFormListById() {
      // console.log(this.bpm_businessKey,this.$route.query.id)
      if (!this.bpm_businessKey && !this.$route.query.id) return;
      let res = await getFormListById(
        this.$route.query.id || this.bpm_businessKey
      );
      if (res.code === 800) {
        console.log(res);
        this.flowForm = res.data || {};
      } else {
        this.$message.error(res.msg);
      }
    },
    //必须要有的方法 保存草稿 方法名固定 内容自定义 可直接返回编辑中的保存接口promise函数
    ap_save() {
      return new Promise((resolt, reject) => {
        // if (this.$route.query.id)
          this.flowForm.id = this.$route.query.id || this.bpm_businessKey;
        let data = {
          params: this.flowForm,
        };
        editFormList(data).then((res) => {
          if (res.code === 800) {
            resolt(res.msg);
          } else {
            reject(res.msg);
          }
        });
      });
    },
    submitForm(isRun, isSave = false) {
      // if (this.$route.query.id)
        this.flowForm.id = this.$route.query.id || this.bpm_businessKey;
      let data = {
        params: this.flowForm,
      };
      console.log(data);
      if (!this.flowForm.id) {
        //新增
        addFormList(data).then((res) => {
          if (res.code === 800) {
            this.startRunFlow(isRun, res.data.id);
          } else {
            this.$message.error(res.msg);
          }
        });
      } else {
        //编辑
        editFormList(data).then((res) => {
          if (res.code === 800) {
            if (isSave) {
              //如果编辑只是保存
              this.startRunFlow(isRun, res.data.id);
            }
            this.$message.success(res.msg);
            if (this.isAddPageIn) this.$router.go(-1);
            // this.$router.push({ name: 'startTask' });
          } else {
            this.$message.error(res.msg);
          }
        });
      }
    },
    //varables赋值
    bpmTaskService() {
      let params = {
        processDefinitionKey: 'TEST1.1', //流程引擎标识 ，在取分类标志+.1,例如 TEST1.1
        companyId: this.companyId, // --当前登录人的tenantId
        systemType: 'demo', // -- 默认是EAM
      };
      bpmTaskService(params).then((res) => {
        console.log(res);
        if (res.status === 'S') {
          if (res.data.variables.length) {
            //如果是动态必须动态赋值
            this.process_variables = res.data.variables.map((item) => {
              if (item.name == 'tenantId') {
                item.value = this.companyId;
              }
              if (item.name == 'name') {
                item.value = '流程启动测试';
              }
              if (item.name == 'name4') {
                item.value = '流程启动测试';
              }
              return item;
            });
          }
        } else {
          this.$message.error(res.msg);
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.tempForm {
  .flowSubmit {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 15px;
  }
}
</style>
