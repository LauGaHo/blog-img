<template>
  <el-button icon="el-icon-document" :disabled="isEmpty(goDetailParams.businessKey)" type="primary" v-bind="$attrs" @click="lookDetail">{{
    title
  }}</el-button>
</template>
<script>
export default {
  name: 'ListDetailButton',
  props: {
    title: {
      type: String,
      default: '流程详情'
    },
    goDetailParams: {
      type: Object,
      default: () => {
        //业务id
        ;(businessKey = ''),
          //流程标识 根据自己的业务标识自己写死传过来 例如例子中 TEST1.1
          (processDefinitionKey = '')
      }
    }
  },
  methods: {
    lookDetail() {
      this.$router.push({
        name: 'list_details',
        query: this.goDetailParams
      })
    },
    isEmpty(obj) {
      return typeof obj === 'undefined' || obj == null || obj === ''
    }
  }
}
</script>
