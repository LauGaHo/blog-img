<template>
  <div>
    <container
      ref="con"
      :type="`edit`"
      :bpm_businessKey="bpm_businessKey"
      :isSubmit="isSubmit"
      :editStatus="editStatus"
      :formPage="fromPage"
      :curTaskName="curTaskName"
      in-process
    />
  </div>
</template>

<script>
//注意这里对应表单业务文件地址
import container from '../test-menu/test-form/info';

export default {
  name: 'overhaulPlan',
  props: {
    isSubmit: {
      //是否显示页面本来操作按钮 例如 提交，保存草稿按钮
      type: Boolean,
      default: false,
    },
    editStatus: {
      //是否可编辑表格 0否 1 是
      type: String | Number,
      default: 0,
    },
    bpm_businessKey: {
      //表单对应ID 原本从query传 得支持两种方式
      type: Number | String,
      default: '',
    },
    fromPage: {
      type: String,
    },
    taskServiceParams: Array,
    curTaskName: String,
  },
  components: { container },
  methods: {
    get_process_variables() {
      return [];
    },
    ap_save() {
      return this.$refs.con.handleSave();
    },
  },
};
</script>

<style scoped></style>
