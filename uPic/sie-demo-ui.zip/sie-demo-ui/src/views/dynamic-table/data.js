export default () => ([
  {
    cdcName: '顺德CDN',
    models: 'TC2900',
    data: []
  },
  {
    cdcName: '广州CDN',
    models: 'TC2900',
    data: []
  },
])