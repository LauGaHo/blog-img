<template>
  <el-card class="dynamic-table">
    <el-form class="search-bar" :model="formData" size="small">
      <el-form-item label="日期范围">
        <el-date-picker
          v-model="formData.dateRange"
          type="daterange"
          value-format="yyyy/MM/dd"
          @change="generateTableColumns"
        />
      </el-form-item>
    </el-form>
    <el-table
      ref="tableRef"
      :data="tableData"
      border stripe
      size="small"
      :height="$store.getters.appMainHeight - 130"
    >
      <el-table-column header-align="center" label="CDC名称" prop="cdcName" fixed width="100px" />
      <el-table-column header-align="center" label="机型描述" prop="models" fixed width="100px" />
      <template v-for="column in dateColumns">
        <el-table-column header-align="center" :prop="column.prop" :label="column.label" min-width="120px" />
      </template>
    </el-table>
  </el-card>
</template>

<script>
import generateTableData from './data'

export default {
  name: 'DynamicTable',
  data() {
    return {
      formData: {
        dateRange: []
      },
      originData: generateTableData(),
      tableData: [],
      // [{ prop: '', label: '' }]
      dateColumns: []
    }
  },
  watch: {
    dateColumns: {
      handler() {
        this.$nextTick().then(() => {
          this.$refs?.tableRef.doLayout()
        })
      }
    }
  },
  created() {
    this.formData.dateRange = [
      this.$moment().subtract(6, 'day').format('YYYY/MM/DD'),
      this.$moment().format('YYYY/MM/DD')
    ]
    this.generateTableColumns()
  },
  methods: {
    // 根据日期范围计算出表格列
    generateTableColumns() {
      this.dateColumns.length = 0
      // 一天的秒数
      const DAY_UNIX = 24 * 60 * 60 * 1000
      let startDate = this.$moment(this.formData.dateRange[0]).valueOf()
      let endDate = this.$moment(this.formData.dateRange[1]).valueOf()
      // 添加开始日期
      this.dateColumns.push({ label: this.formData.dateRange[0], prop: this.formData.dateRange[0] })
      while (startDate < endDate) {
        startDate += DAY_UNIX
        this.dateColumns.push({
          label: this.$moment(startDate).format('YYYY/MM/DD'),
          prop: this.$moment(startDate).format('YYYY/MM/DD')
        })
      }

      // 随机数填充 table data
      this.originData.forEach(data => {
        data.data.length = this.dateColumns.length
        _.fill(data.data, _.random(9999))
      })

      this.formatterTableData()
    },
    // 根据tableData 的数据，转换成列数据
    formatterTableData() {
      this.originData.forEach((data, index) => {
        this.tableData[index] = { ...data }

        this.dateColumns.forEach((col, idx) => {
          this.tableData[index][col.prop] = data.data[idx]
        })
      })

      console.log('tableData ->', this.tableData)
    }
  }
}
</script>

<style scoped>

</style>