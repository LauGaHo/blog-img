<template>
  <div class="public-form-search">
    <el-card class="mb-20">
      <div class="btn">
        <el-button
          icon="el-icon-search"
          type="primary"
          @click="handleSearch"
        >{{$t('button.search')}}</el-button>
        <el-button icon="el-icon-refresh" type="primary" @click="handleReset">{{$t('button.reset')}}</el-button>
      </div>
      <el-row class="form-container lw-120">
        <el-form :inline="true" :model="formInline" ref="formInline" label-width="120px">
          <el-col :span="8">
            <el-form-item :label="$t('exportModel.functionName')" prop="functionName">
              <el-input :placeholder="$t('exportModel.functionName')" clearable v-model="formInline.functionName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item :label="$t('exportModel.exportDate')" prop="dateRange">
              <el-date-picker
                v-model="formInline.dateRange"
                type="daterange"
                align="right"
                unlink-panels
                :range-separator="$t('change.to')"
                :start-placeholder="$t('change.startDate')"
                :end-placeholder="$t('change.endDate')"
                value-format="yyyy-MM-dd HH:mm:ss"
                :picker-options="pickerOptions"
                @change="changeDateRange"
              ></el-date-picker>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </el-card>
    <el-card>
      <div class="table-container">
        <el-table stripe v-loading="showLoading" :data="tableData" highlight-current-row>
          <el-table-column sortable type="index" width="55"></el-table-column>
          <el-table-column
            sortable
            :label="$t('exportModel.functionName')"
            min-width="200"
            prop="functionName"
          >
            <template slot-scope="scope">
              <a
                target="_blank"
                :href="scope.row.fileUrl"
                style="color: #248cf7;"
                :download="scope.row.fileUrl"
              >{{ scope.row.functionName }}</a>
            </template>
          </el-table-column>
          <el-table-column
            sortable
            :label="$t('exportModel.exportTaskId')"
            min-width="200"
            prop="exportId"
          ></el-table-column>
          <el-table-column
            sortable
            :label="$t('exportModel.exportStatus')"
            min-width="200"
            prop="status"
          >
            <template slot-scope="scope">
              <span>{{scope.row.status==1?$t('exportModel.exporting'):$t('exportModel.completed')}}</span>
            </template>
          </el-table-column>
          <el-table-column
            sortable
            :label="$t('exportModel.completeDate')"
            min-width="200"
            prop="completeDate"
          ></el-table-column>
        </el-table>
        <el-pagination
          style="margin-top:20px; text-align: right;"
          v-if="tableData.length > 0"
          @size-change="changeListSize"
          @current-change="changeListCurrent"
          :current-page="listCurrentPage"
          :page-sizes="[10, 20, 30, 50]"
          :page-size="listPageSize"
          layout="prev,pager,next,total,sizes,jumper"
          :total="listTotal"
        ></el-pagination>
      </div>
    </el-card>
  </div>
</template>

<script>
import { getExportDataRecord } from '@/api/export';
import { formatParams } from '@/utils/tool';

export default {
  components: {},
  data() {
    return {
      formInline: {
        dateRange: '',
        functionName: '', //功能名称
        startDate: '2020-07-01 00:00:00', //导出日期从
        endDate: '2020-08-01 00:00:00', //导出日期至
      },
      showLoading: false,
      tableData: [],
      listTotal: 0,
      listCurrentPage: 1,
      listPageSize: 10,
      width: '80px',
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            },
          },
        ],
      },
    };
  },
  computed: {},
  mounted() {
    const { getDataList } = this;
    getDataList();

    const FormContainer = document.getElementsByClassName('form-container')[0];
    FormContainer.onkeydown = () => {
      const keyCode = window.event.keyCode;
      if (keyCode === 13) {
        this.handleSearch();
      }
    };
  },
  methods: {
    changeDateRange(val) {
      this.formInline.startDate = val ? val[0] : '';
      this.formInline.endDate = val ? val[1] : '';
    },
    getDataList() {
      const _this = this;
      let data = formatParams(_this.formInline);
      const params = {
        pageIndex: _this.listCurrentPage,
        pageRows: _this.listPageSize,
        params: { ...data, ecType: 1 },
      };
      _this.showLoading = true;
      getExportDataRecord(params).then((resp) => {
        _this.showLoading = false;
        if (resp.code === 800) {
          _this.tableData = resp.data.data || [];
          _this.listTotal = resp.data.count;
        }
      });
    },
    handleSearch() {
      this.getDataList();
    },
    handleReset() {
      this.$refs['formInline'].resetFields();
      this.formInline.startDate = '';
      this.formInline.endDate = '';
    },
    changeListSize(val) {
      this.listPageSize = val;
      this.getDataList();
    },
    changeListCurrent(val) {
      this.listCurrentPage = val;
      this.getDataList();
    },
  },
};
</script>
