<!--  -->
<template>
  <div id="box">
    <div id="container">
      <h3>
        《
        <span>{{ name }}</span> 》
      </h3>
      <div>
        <h3 style="color: green" v-if="onGoing">导出中...</h3>
        <h3 style="color: green" v-if="exportStatus && !onGoing">
          <i class="el-icon-circle-check"></i>导出完成
        </h3>
        <h3 style="color: red" v-else-if="errorStatus && !onGoing">
          <i class="el-icon-circle-close"></i>导出失败
        </h3>
        <div v-else style="width: 60%; margin: 0 auto">
          <p>报表数据正在生成请耐心等候!</p>
          <p style="text-align: center">
            <i class="el-icon-loading"></i>
          </p>
        </div>
      </div>
      <p>
        已用时间
        <span style="color: #ff0000">{{ timer }}秒</span>
      </p>
      <a href="javascript:self.close()" class="close">[关闭]</a>
    </div>
  </div>
</template>

<script>
import { dataExport, getExportResult } from '@/api/export';
import { getToken, getRefreshToken } from '@/utils/auth';
import download from './utils';
import fileSaver from 'file-saver';

export default {
  data() {
    return {
      name: '',
      progressNum: 20,
      timer: 0,
      exportData: {},
      exportStatus: false,
      errorStatus: false,
      intervalTimer: null,
      onGoing: false,
    };
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {
    this.dataExport();
  },
  methods: {
    //倒计时开始(其实没啥用)
    countDown() {
      this.cd = setInterval(() => {
        this.timer++;
      }, 1000 * 1);
    },
    exportError() {
      clearInterval(this.cd);
      this.onGoing = false;
      this.errorStatus = true;
    },
    //
    dataExport() {
      let token = getToken();
      let refreshToken = getRefreshToken();
      const data = JSON.parse(sessionStorage.getItem('exportInfo'));
      this.name = data.emailSubject;
      data.requestUrl = `${process.env.VUE_APP_BASEAPI}${data.requestUrl}`;
      let params = {
        ...data,
        token,
        refreshToken,
      };
      //处理没有缺少分页参数情况
      params = this.addPageParams(params);
      this.countDown();
      dataExport(params).then((resp) => {
        if (resp.code === 800) {
          this.intervalTimer = setInterval(() => {
            this.getExportResult(resp.data.exportId);
          }, 1000);
        } else {
          this.exportError();
        }
      });
    },
    addPageParams(params) {
      //接口不支持null对象
      const requestParam = JSON.parse(params.requestParam.replace(/null/, ''));
      if (
        !requestParam.hasOwnProperty('pageIndex') &&
        !requestParam.hasOwnProperty('pageRows')
      ) {
        const pageParams = {
          pageIndex: 1,
          pageRows: 10,
        };
        const mergeParams = Object.assign({}, pageParams, requestParam);
        params.requestParam = JSON.stringify(mergeParams);
      }
      return params;
    },
    getExportResult(id) {
      const params = {
        exportId: id,
      };
      getExportResult(params).then((resp) => {
        if (resp.data.status == 2 || resp.data.status == 3) {
          this.exportStatus = true;
          this.onGoing = false;
          clearInterval(this.cd);
          clearInterval(this.intervalTimer);
          if (resp.data.status == 2) {
            const { accessPath, fileName } = resp.data;
            // fileSaver.saveAs(accessPath, fileName)
            window.location.href = accessPath;
          }
        }
        if (resp.data.status === 1) {
          this.onGoing = true;
        }
      });
    },
  },
};
</script>
<style lang='scss' scoped>
a.close {
  color: #666;
  font-size: 14px;
  position: absolute;
  right: 20px;
  bottom: 20px;
  text-decoration: none;
}

#box {
  position: absolute;
  top: 40%;
  height: 186px;
  width: 100%;
}

#container {
  position: relative;
  text-align: center;
  border: 1px solid #ddd;
  box-shadow: #ccc 0 0 20px;
  padding: 20px;
  margin: -93px 15% 0 15%;
}
</style>
