<template>
  <section class="home-page"></section>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {
    }
  }
}
</script>

<style lang="scss" scoped>
.home-page {
}
</style>