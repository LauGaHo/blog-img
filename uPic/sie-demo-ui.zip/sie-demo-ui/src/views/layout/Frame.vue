<template>
  <div v-loading="microPageLoading" className="app-frame app-main" id="mainContainer"/>
</template>

<script>
import { defineComponent, computed, ref, watch, onMounted, onUnmounted } from '@vue/composition-api'
import { loadMicroApp } from 'qiankun'
import { apps } from '@/qiankun'
import { useStore } from '@/store'

export default defineComponent({
  name: 'Frame',
  setup(_, {root}) {
    const store = useStore()

    const microApps = ref(apps())
    const currentApp = ref(null)

    // 修改子应用CDN资源host
    const handleLoadMicroAppFetch = (url, ...args) => {
      if (url.includes('cdn')) {
        const reg = new RegExp('^((http://)|(https://))?([a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,6}(/)')
        return window.fetch(url.replace(reg, window.VUE_CDN_HOST), ...args)
      }
      return window.fetch(url, ...args)
    }

    watch(
        () => root.$route.path,
        (path, oldPath) => {
          // 找到路由前缀匹配的 app，并启动
          const loadApp = microApps.value.find(app => {
            // 前后跳转的路由需属于不同的 app
            return app.activeRule.some(rule => path.startsWith(rule) && !oldPath?.startsWith(rule))
          })
          if (loadApp) {
            currentApp.value = loadMicroApp(loadApp, {
              fetch: handleLoadMicroAppFetch
            })
          }
        },
        {immediate: true}
    )

    onMounted(() => {
      // 如果是门户首页，显示按钮
      if (root.$route.path.includes('portal')) {
        store.commit('SET_COLLECT_BUTTON_STATUS', true)
      }
    })

    onUnmounted(() => {
      store.commit('SET_COLLECT_BUTTON_STATUS', false)
      currentApp.value.unmount()
    })

    return {
      cachedViews: computed(() => store.state.cachedViews),
      key: computed(() => root.$route.fullPath),
      microPageLoading: computed(() => store.getters.microPageLoading)
    }
  }
})
</script>

<style scoped>
.app-frame {
  min-height: 100vh;
  position: relative;
  overflow: hidden;
  padding: 15px;
  background: #eef0f6;
}
</style>
