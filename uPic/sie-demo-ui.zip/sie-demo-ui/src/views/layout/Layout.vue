<template>
  <div class="app-wrapper" :class="classObj">
    <transition name="navbar-fade">
      <navbar v-show="!fullscreen" />
    </transition>
    <div class="main-container" :style="mainStyle">
      <transition name="side-fade">
        <sidebar v-show="!fullscreen" />
      </transition>
      <div class="right-container" :style="rightStyle">
        <transition>
          <tags-view ref="tagsViewRef" v-show="!fullscreen" />
        </transition>
        <app-main :class="{ 'app-main-fullscreen': fullscreen }" :style="appMainStyle" />
      </div>
    </div>

    <compact-tools v-if="layoutConfig === 'compact'" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { Navbar, Sidebar, AppMain, TagsView, CompactTools } from './components'
import ResizeMixin from './mixin/ResizeHandler'
import { getToken, getRefreshToken } from '@/utils/auth'
import { action } from "@/qiankun";

export default {
  name: 'Layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    TagsView,
    CompactTools
  },
  data() {
    return {
      token: getToken(),
      refreshToken: getRefreshToken()
    }
  },
  mixins: [ResizeMixin],
  provide() {
    return {
      fullscreenMan: this.fullscreenMan
    }
  },
  computed: {
    ...mapGetters(['layoutConfig', 'fullscreenGlobal']),
    fullscreen() {
      return this.$store.state.app.fullscreenGlobal
    },
    sidebar() {
      return this.$store.state.app.sidebar
    },
    classObj() {
      return { withoutAnimation: this.sidebar.withoutAnimation }
    },
    mainStyle() {
      return this.fullscreen
          ? {
            marginLeft: 0,
            height: this.fullscreenGlobal ? '100%' : null
          }
          : {}
    },
    rightStyle() {
      return this.fullscreen ? { top: 0, left: 0, width: '100%', height: '100%' } : {}
    },
    appMainStyle() {
      return this.fullscreen ? { height: '100%' } : {}
    }
  },
  watch: {
    $route: {
      deep: true,
      handler() {
        this.fullscreen && this.fullscreenToggle()
      }
    }
  },
  mounted() {
    // 进入系统页，显示右下按钮
    this.$store.commit('SET_COLLECT_BUTTON_STATUS', true)
    this.$bus.$emit('check-use-limit')

    // 监听微前端全局变量
    this.$microProps.onGlobalStateChange(({ fullscreen, staticRoute }) => {
      // 接收子应用全屏消息
      this.$store.dispatch('setFullscreenGlobal', fullscreen)
      // 接受子应用发送的路由信息
      if (staticRoute) {
        this.$refs?.tagsViewRef.setCurrentRouteInfo(staticRoute)
        action.setGlobalState({ staticRoute: null })
      }
    })
  },
  beforeDestroy() {
    this.$store.commit('SET_COLLECT_BUTTON_STATUS', false)
    this.$microProps.offGlobalStateChange()
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('CloseSideBar', { withoutAnimation: false })
    },
    // 全局切换全屏方法，隐藏侧边菜单和导航栏
    fullscreenToggle(flag) {
      if (flag != null) {
        this.fullscreen = !!flag;
      } else {
        this.fullscreen = !this.fullscreen;
      }
      return this.fullscreen
    }
  }
}
</script>

<style lang="scss" scoped>
.app-wrapper {
  min-width: 1024px;
  width: 100%;
  height: 100%;
  overflow: auto hidden;

  .main-container {
    display: flex;
    position: relative;
    width: 100%;
    height: calc(100vh - #{$navbar-height});

    .right-container {
      flex: 1 1 auto;
      padding: 0;
      overflow: hidden;
      transition: all 0.3s;
    }
  }
}
.side-fade-enter-active {
  transition: all 0.2s ease;
}
.side-fade-leave-active {
  transition: all 0.2s ease;
}
.side-fade-enter,
.side-fade-leave-to {
  transform: translateX(-100%);
}
.nabbar-fade-enter-active {
  transition: all 0.28s ease;
}
.navbar-fade-leave-active {
  transition: all 0.28s ease;
}
.navbar-fade-enter,
.navbar-fade-leave-to {
  transform: translateY(-100%);
}
</style>
<style lang="scss">
.app-main-fullscreen {
  .app-container {
    padding: 0 !important;
  }
  .comp-content {
    height: 100vh;
  }
}
</style>
