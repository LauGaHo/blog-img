<template>
  <section id="mainContainer">
    <transition name="fade-transform" mode="out-in">
      <keep-alive>
        <router-view v-if="keepAlive" :key="key" />
      </keep-alive>
    </transition>
    <transition name="fade-transform" mode="out-in">
      <router-view v-if="!keepAlive" :key="key" />
    </transition>
  </section>
</template>

<script>
export default {
  computed: {
    keepAlive() {
      return !this.$route.meta.noCache
    },
    key() {
      return this.$route.fullPath
    },
  }
}
</script>
