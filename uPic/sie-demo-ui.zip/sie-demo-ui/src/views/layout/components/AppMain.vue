<template>
  <section id="appMain" :class="['app-main', layoutConfig]">
    <div v-show="isBootstrap">
      <transition name="fade-transform" mode="out-in">
        <keep-alive>
          <router-view v-if="keepAlive" :key="key" />
        </keep-alive>
      </transition>
      <transition name="fade-transform" mode="out-in">
        <router-view v-if="!keepAlive" :key="key" />
      </transition>
    </div>
    <section
      v-for="app in microApps"
      :key="app.name"
      :id="`${app.container.slice(1)}`"
      class="main-container"
      v-show="!isBootstrap && isCurrentAppForRoutePath(app.activeRule)"
      v-loading="microPageLoading"
    />
  </section>
</template>

<script>
import { loadMicroApp, prefetchApps } from 'qiankun'
import { apps } from '@/qiankun'

export default {
  name: 'AppMain',
  data() {
    return {
      loadedApp: new Map(),
      microApps: apps().map(app => ({ ...app, container: `${app.container}-${app.name}` }))
    }
  },
  computed: {
    cachedViews() {
      return this.$store.state.tagsView.cachedViews
    },
    key() {
      return this.$route.fullPath
    },
    keepAlive() {
      return this.$route.meta.noCache
    },
    isBootstrap() {
      return this.$route.meta.isBootstrap
    },
    microPageLoading() {
      return this.$store.getters.microPageLoading
    },
    layoutConfig() {
      return this.$store.getters.layoutConfig
    }
  },
  watch: {
    $route: {
      handler({ path }) {
        // 找到路由前缀匹配的 app，并启动
        const loadApp = this.microApps.find(app => app.activeRule.some(rule => path.startsWith(rule)))
        if (loadApp) {
          if (!this.loadedApp.has(loadApp.name)) {
            this.loadedApp.set(loadApp.name, {
              app: loadMicroApp(loadApp, {
                excludeAssetFilter: this.excludeAssetFilter,
                fetch: this.handleLoadMicroAppFetch
              }),
              childrenRoute: new Set()
            })
          }
          // 记录子应用已激活到菜单
          this.loadedApp.get(loadApp.name).childrenRoute.add(path)
        }
      },
      immediate: true
    }
  },
  methods: {
    // 加载子应用第三方资源规则限制
    excludeAssetFilter(assetUrl) {
      const whiteWords = ['baidu', 'map']
      return whiteWords.some(w => assetUrl.includes(w))
    },
    // 修改子应用CDN资源host
    handleLoadMicroAppFetch(url, ...args) {
      if (url.includes('cdn')) {
        const reg = new RegExp('^((http://)|(https://))?([a-zA-Z0-9]([a-zA-Z0-9\\-]{0,61}[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,6}(/)')
        // 统一升级vue 版本到 2.7.10
        // const vueVersion = 'vue@2.6.14.min.js'
        // if (url.includes(vueVersion)) {
        //   const vueCdnUrl = url.replace(reg, window.VUE_CDN_HOST).replace(vueVersion, 'vue@2.7.10.min.js')
        //   return window.fetch(vueCdnUrl, ...args)
        // }

        return window.fetch(url.replace(reg, window.VUE_CDN_HOST), ...args)
      }
      return window.fetch(url, ...args)
    },
    // 修改浏览器窗口大小
    async handleChangeWindow() {
      await this.$nextTick()
      const height = document.getElementById('appMain').offsetHeight
      this.$store.commit('SET_APP_MAIN_HEIGHT', height)
      this.$microProps.setGlobalState({ appMainHeight: height })
    },
    // 预加载子应用
    handlePrefetchMicroApps() {
      const prefetchMicroApps = this.microApps.filter(app => app.prefetch)
      prefetchMicroApps?.length && prefetchApps(prefetchMicroApps)
    },
    isCurrentAppForRoutePath(activeRule) {
      const path = this.$route.path
      return activeRule.some(rule => path.startsWith(rule))
    },
    closeSelectedTag({ path, name }) {
      for (let key of this.loadedApp.keys()) {
        // 从包含已挂载的子应用中移除 tag path
        const childrenRoute = this.loadedApp.get(key).childrenRoute
        if (childrenRoute.has(path)) {
          childrenRoute.delete(path)
        }
        // 如果当前子应用的 tag 数量为 0 ，则卸载
        if (!childrenRoute.size) {
          this.loadedApp.get(key).app.unmount()
          this.loadedApp.delete(key)
        }
      }
      this.$microProps.setGlobalState({ closeTagName: name })
    },
    closeOtherTags({ path, name }) {
      for (let key of this.loadedApp.keys()) {
        // 判断已挂载的子应用是否包含当前 tag path
        const currentApp = this.loadedApp.get(key)
        if (currentApp.childrenRoute.has(path)) {
          // 包含当前的 tag ，清空其他 tag 信息
          currentApp.childrenRoute.clear()
          currentApp.childrenRoute.add(path)
        } else {
          // 不包含当前 tag 信息，卸载掉
          currentApp.app.unmount()
          this.loadedApp.delete(key)
        }
      }
      this.$microProps.setGlobalState({ closeOtherTagsToName: name })
    },
    closeAllTags() {
      // 卸载所有已挂载的子应用
      for (let key of this.loadedApp.keys()) {
        this.loadedApp.get(key).app.unmount()
      }
      this.loadedApp.clear()
    }
  },
  async mounted() {
    // 监听窗口高度变化，设置内容区域高度值
    await this.handleChangeWindow()
    window.onresize = () => this.handleChangeWindow

    this.handlePrefetchMicroApps()

    // 监听三种关闭 tag类型，做对应的处理
    this.$bus.$on('close-selected-tag', tag => {
      this.closeSelectedTag(tag)
    })
    this.$bus.$on('close-other-tags', tag => {
      this.closeOtherTags(tag)
    })
    this.$bus.$on('close-all-tags', () => {
      this.closeAllTags()
    })
  },
  beforeDestroy() {
    this.$bus.$off('close-selected-tag')
    this.$bus.$off('close-other-tags')
    this.$bus.$off('close-all-tags')
  }
}
</script>

<style lang="scss" scoped>
.app-main {
  padding: 10px;
  height: calc(100% - #{$tag-views-height});
  background-color: $app-main-bg-color;
  overflow-y: auto;

  &.compact {
    padding: 4px 30px 4px 10px;
    height: calc(100% - #{$tag-views-height});
  }

  .mainContainer {
    min-height: 100%;
    overflow-x: hidden;
  }
}
</style>
