<template>
  <section class="compact-tools">
<!--    <system-change icon-color="#333" placement="left" />-->
    <portal icon-color="#333" placement="left" />
    <message icon-color="#333" placement="left" />
    <theme icon-color="#333" placement="left" />
    <locale icon-color="#333" placement="left" />
    <help icon-color="#333" placement="left" />
  </section>
</template>

<script>
import Portal from "@/views/layout/components/Navbar/components/Portal"
import Message from '@/views/layout/components/Navbar/components/Message'
import Theme from '@/views/layout/components/Navbar/components/Theme'
import Locale from '@/views/layout/components/Navbar/components/Locale'
import Help from '@/views/layout/components/Navbar/components/Help'

export default {
  name: "CompactTools",
  components: {
    Portal,
    Message,
    Theme,
    Locale,
    Help
  }
}
</script>

<style lang="scss" scoped>
.compact-tools {
  position: fixed;
  top: $navbar-height;
  right: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 8px;
  background-color: #fff;
  box-shadow: -1px 1px 9px 0px rgba(168,172,180,0.27);
  border-radius: 0 0 0 4px;
  z-index: 999;

  & > div {
    text-align: center;
    cursor: pointer;

    &:not(:last-of-type) {
      margin-bottom: 8px;
    }
  }
}
</style>