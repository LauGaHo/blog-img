<template>
  <div class="panel-avuedata">
    <el-tooltip effect="dark" :content="$t('dashboard')" :placement="placement">
      <i class="iconfont1 icon-daping" :style="{ fontSize: '22px', color: iconColor }" @click="handleAVueData" />
    </el-tooltip>
  </div>
</template>

<script>
import sysConfig from "@/config";

export default {
  name: "AVue",
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  methods: {
    handleAVueData() {
      window.open(sysConfig.baseUrl.avueDataUrl, '_blank')
    },
  }
}
</script>

<style scoped>

</style>