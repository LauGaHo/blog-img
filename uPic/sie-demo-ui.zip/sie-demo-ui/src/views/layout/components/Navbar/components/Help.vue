<template>
  <div class="panel-help">
    <el-tooltip effect="dark" :content="$t('otherLang.helpCenter')" :placement="placement">
      <i class="iconfont1 icon-help" :style="{ fontSize: '24px', color: iconColor }" @click="handleHelp" />
    </el-tooltip>

    <gs-dialog
      ref="drawerMap"
      custom-class="dialog-mindmap"
      :title="$t('otherLang.helpCenter')"
      fullscreen
      :visible.sync="drawer"
      width="100%"
      :show-footer="false"
      @opened="handleOpened"
    >
      <div class="panel-mindmap" :style="{ width: mindMapWidth, height: mindMapHeight }">
        <svg id="mindmap" :style="{ width: mindMapWidth, height: mindMapHeight }" />
      </div>
    </gs-dialog>
  </div>
</template>

<script>
import _config from "@/config";
import { HcPageControllerFindPageinfo } from "@/api/letters";

require('@gushen/markmap/style/view.mindmap.css')
require('@gushen/markmap/lib/d3-flextree')
const MARK_MAP = require('@gushen/markmap/lib/view.mindmap')

export default {
  name: "Help",
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  data() {
    return {
      drawer: false,
      mindMapData: [],
      mindMapHeight: document.documentElement.offsetHeight - 55,
      mindMapWidth: document.documentElement.offsetWidth,
    }
  },
  methods: {
    async handleHelp() {
      const params = {
        params: {
          systemCode: _config.systemCode,
          pageCode: this.$route.path.replace('/', '')
        }
      }
      const res = await HcPageControllerFindPageinfo(params)
      if (this.reqIsSucceed(res)) 
        this.mindMapData = res.data
      
      this.drawer = true
    },
    handleOpened() {
      document.querySelector('#mindmap').innerHTML = ''
      MARK_MAP('svg#mindmap', this.mindMapData, {
        preset: 'colorful',
        linkShape: 'diagonal'
      })
    },
  }
}
</script>

<style lang=scss scoped>
</style>