<template>
  <div class="lang-change">
    <el-tooltip effect="dark" :content="$t('button.language')" :placement="placement">
      <el-popover
        v-model="isPopoverShow"
        :placement="placement"
        trigger="click"
        popper-class="locale-list-popover-container"
        width="60px"
      >
        <div class="locale-container">
          <div
            :class="['locale-item', $store.getters.lang === 'zh-cn' ? 'disabled' : '']"
            @click="switchLang('zh-cn')"
          >
            {{ $t('button.chinese') }}
          </div>
          <div
            :class="['locale-item', $store.getters.lang === 'en-us' ? 'disabled' : '']"
            @click="switchLang('en-us')"
          >
            {{ $t('button.english') }}
          </div>
        </div>

        <i slot="reference" class="iconfont1 icon-zhongyingwen" :style="{ fontSize: '24px', color: iconColor }" />
      </el-popover>
    </el-tooltip>
  </div>
</template>

<script>
import { action } from "@/qiankun";
import { getLanguage } from '@/utils/auth'

export default {
  name: "Locale",
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  data() {
    return {
      isPopoverShow: false
    }
  },
  methods: {
    async switchLang(val) {
      if (val === this.$store.getters.lang) return
      const lang = val || 'zh-cn'
      this.$i18n.locale = lang
      this.$store.commit('SET_LANG', lang)
      // 微前端设置的监听数据（国际化切换）
      action.setGlobalState({ local: lang })
      this.isPopoverShow = false
    },
  },
  created() {
    const lang = getLanguage() || 'zh-cn'
    this.switchLang(lang)
  }
}
</script>

<style lang="scss">
.locale-container {
  display: flex;
  flex-direction: column;

  .locale-item {
    padding: 8px;
    border-radius: 4px;
    cursor: pointer;
    user-select: none;
    transition: all .3s;

    &.disabled {
      color: #999;
      cursor: default;
    }

    &:not(.disabled):hover {
      color: var(--color-primary);
      background-color: var(--color-primary-light-9);
    }
  }
}
</style>