<template>
  <div class="bell" ref="bell">
    <el-popover ref="popoverRef" v-model="isShow" placement="bottom" width="480" popper-class="alarm-popper" trigger="click">
      <el-card class="border-card" shadow="never" v-loading="loading" :body-style="{ padding: '0', height: '300px', overflow: 'auto' }">
        <!-- 卡片头部 -->
        <div slot="header" class="header-title">
          <!-- 标题 -->
          <span style="margin-left: 100px">{{ messageTitle }}</span>
          <!-- popover关闭 -->
          <i class="el-icon-close header-close" @click="closeMseeage"></i>
          <!-- 查看更多 -->
          <div class="loadMore" @click="loadMoreLetters">
            {{ $t('message.more') }}
          </div>
        </div>
        <div v-if="msgData.length > 0" class="new_message">
          <div class="alarm-label" v-for="list in msgData" :key="list.msgInstanceId" @click="toDetail($event)">
            <!-- 消息内容 -->
            <div class="name">
              <div v-html="list.messageContent"></div>
            </div>
            <!-- 消息时间以及标为已读按钮 -->
            <div class="time-and-mark">
              <el-tag class="mark" size="small" @click.stop="marked(list.msgInstanceId)"><i class="el-icon-message"></i>标为已读</el-tag>
              <div class="time" style="text-align: center">
                {{ list.sendTime ? $moment(list.sendTime).format('YYYY-MM-DD HH:mm') : '' }}
              </div>
            </div>
          </div>
        </div>
        <div v-else class="no-data">
          <img src="https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/images/noData.png" />
        </div>
      </el-card>
      <el-badge slot="reference" :value="unread" :max="999" :hidden="unread === 0">
        <i class="iconfont1 icon-iconbell" :style="{ fontSize: '24px', color: iconColor }" />
      </el-badge>
    </el-popover>
  </div>
</template>

<script>
// vuex
import { mapGetters } from 'vuex'
// WebSocket
import WebSocketConnect from '@/utils/ws'
// api
import { getMessageList, messageRead } from '@/api/letters'

export default {
  name: 'Message',
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  computed: {
    ...mapGetters(['unread']),
    // 站内信息标题
    messageTitle() {
      const text = this.$t('message.systemMessage')
      return this.unread ? `${text}（${this.unread}）` : `${text}`
    }
  },
  data() {
    return {
      // 站内消息loading
      loading: false,
      isShow: false,
      msgData: []
    }
  },
  methods: {
    //查看消息列表
    toDetail(e) {
      // 让a标签走自己的逻辑
      const nodeName = e.target.nodeName
      if (nodeName !== 'A') {
        this.$router.push('/letters')
      }
    },

    // 标为已读
    marked(id) {
      let params = {
        systemCodes: [window._config.systemCode],
        msgInstanceIds: [id]
      }
      this.loading = true
      // 调用标记已读接口
      messageRead({ params })
        .then(res => {
          if (this.reqIsSucceed(res)) {
            this.loading = false
            // 通知铃铛和本页面更新数据
            this.$bus.$emit('update-station-message')
          }
        })
        .catch(() => {
          this.loading = false
        })
    },

    // 关闭消息弹出框
    closeMseeage() {
      this.isShow = false
    },

    //查看更多
    loadMoreLetters() {
      this.isShow = false
      this.$router.push('/letters')
    },

    // 请求站内信息
    async getMessageList() {
      try {
        this.loading = true

        const msgData = await getMessageList({
          pageIndex: 1,
          pageRows: 10,
          params: { systemCodes: [_config.systemCode], readStatus: 0 }
        })

        this.msgData = msgData?.data?.data ?? []
        // 请求未读消息数量
        this.$store.dispatch('GetUnreadTotal')

        this.loading = false
      } catch (error) {
        this.loading = false
      }
    },

    // websocket 连接
    websocketLink() {
      new WebSocketConnect({
        params: {
          binding: {
            subKey: 'systemNotify',
            userId: localStorage.getItem('userId'),
            systemCode: _config.systemCode
          }
        },
        operate: this.getMessageOperate
      })
    },

    getMessageOperate(event) {
      let data = JSON.parse(event.data)
      //其它系统退出，websocket推送消息过来告诉账号已退出
      if (data.code === 800 && data.messageType === 'action' && data.msg === 'logout') return false
      if (data.code === 800) this.getMessageList()
    }
  },

  created() {
    /**
     * bus监听是否需要更新站内消息
     * 点击marked函数触发或者由'letters'页面触发更新
     */
    this.$bus.$on('update-station-message', () => {
      // 节流
      if (!this.loading) {
        this.getMessageList()
      }
    })
  },

  mounted() {
    this.getMessageList()
    this.websocketLink()
  }
}
</script>

<style lang="scss">
.bell {
  margin-right: 10px;

  .item {
    cursor: pointer;
    line-height: 1;
  }

  .el-badge {
    line-height: 30px;
  }
}

.header-title {
  text-align: center;
}

.header-close {
  line-height: 1.4;
  float: right;
  cursor: pointer;
}

.el-popover.alarm-popper {
  &::-webkit-scrollbar {
    /*滚动条整体样式*/
    width: 10px;
    /*高宽分别对应横竖滚动条的尺寸*/
    height: 1px;
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 10px;
    background-color: rgb(193, 193, 193);
    box-shadow: inset 0 0 5px rgba(193, 193, 193, 0.2);
  }

  // height: 300px;
  // overflow: auto;
  padding: 0;

  .alarm-label {
    padding: 10px 2px;
    border-bottom: solid 1px #dcdcdc;
    display: flex;
    font-size: 12px;
    align-items: center;
    cursor: pointer;
    text-align: center;

    .mark {
      display: none;
    }

    .time {
      display: block;
    }

    &:hover > .time-and-mark .mark {
      display: inline-block;
    }

    &:hover > .time-and-mark .time {
      display: none;
    }

    &:last-child {
      border-bottom: solid 1px #dcdcdc;
    }

    div {
      text-align: center;

      &.level {
        flex: 2;
        margin-left: 15px;

        .el-tag {
          background: var(--color-primary);
        }

        span {
          color: #fff;

          i {
            margin-right: 2px;
          }
        }
      }

      &.time-and-mark {
        flex: 6;
        font-size: 12px;
        color: #545454;
        margin-right: 10px;
      }

      &.name {
        flex: 16;
        font-size: 14px;
        color: #545454;
        margin: 0 20px;
        text-align: left;

        .discription {
          font-size: 16px;
          color: #181818;
        }

        em {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          display: inline-block;
          vertical-align: middle;
          margin-right: 2px;
          margin-top: -2px;
        }
      }
    }
  }

  .alarm-label div {
    text-align: left;
  }

  .no-data {
    color: #8c8c8c;
    text-align: center;
    padding: 10px 0;
  }

  .el-tabs--border-card {
    border: none;
    box-shadow: none;
  }

  .el-tabs--border-card > .el-tabs__content {
    padding: 0;
  }

  .el-tabs__nav {
    border-bottom: solid 1px #dcdcdc;
    width: 100%;
  }

  .el-tabs__nav-wrap {
    padding: 0;
  }

  .el-tabs__nav-wrap.is-top {
    background: #fff;
  }

  .el-tabs--border-card > .el-tabs__header .el-tabs__item {
    color: #030000;
    font-size: 14px;
    width: 100%;
    height: 45px;
    border-right: none;
    font-weight: 400;
    line-height: 45px;
    opacity: 0.65;
  }

  .el-tabs--border-card > .el-tabs__header .el-tabs__item.is-active {
    color: #030000;
    font-size: 14px;
    font-weight: 400;
    background: #fff;
    text-align: center;
  }

  .el-tabs--border-card > .el-tabs__header .el-tabs__item:not(.is-disabled):hover {
    color: #030000;
    font-weight: 400;
  }

  .loadMore {
    float: right;
    color: var(--color-primary);
    cursor: pointer;
    margin-right: 30px;
  }

  .alarmBackground {
    background: #fff8f5;
  }

  .message {
    min-height: 396px;
    border-bottom: solid 1px #dcdcdc;
  }
}

::v-deep .el-badge__content {
  line-height: 16px;
}
</style>