<template>
  <section class="navbar-menu-container">
    <div
      v-show="!arrowHidden.left"
      class="scroll-btn left"
      @click="handleScrollMenu('left')"
    >
      <i class="el-icon-d-arrow-left" />
    </div>
    <el-scrollbar
      ref="scrollPane"
      class="top-menu"
      :vertical="false"
      wrap-class="menu-scroll-wrap"
      wrap-style="overflow-x: hidden;"
      @wheel.native.prevent="handleScroll"
    >
      <div
        v-for="menu in menuList"
        ref="menuItem"
        :class="['menu-item', isActiveMenu(menu)]"
        :key="menu.menu"
        @click="handleSelectedMenu(menu)"
      >
        <gs-icon :icon="menu.menuIconurl" class="svg-icon" />
        <span>{{ $i18n.locale === 'zh-cn' ? menu.menuName : menu.menuEnName }}</span>
      </div>
    </el-scrollbar>
    <div
      v-show="!arrowHidden.right"
      class="scroll-btn right"
      @click="handleScrollMenu('right')"
    >
      <i class="el-icon-d-arrow-right" />
    </div>
  </section>
</template>

<script>
import { handleScrollFromClick } from '@/views/layout/utils/scroll'

export default {
  name: "NavbarMenu",
  data() {
    return {
      menuList: JSON.parse(localStorage.getItem('menuList')) || [],
      // 菜单容器
      // 外部容器
      $scrollPane: null,
      // 滚动容器
      $scrollWrapper: null,
      // 菜单项
      $menuItems: null,
      // 左右箭头显示
      arrowHidden: { left: true, right: false }
    }
  },
  methods: {
    isActiveMenu(menu) {
      const path = this.$route.path
      return path.split('/')[1] === menu.menuUrl ? 'active' : ''
    },
    handleScroll(e) {
      const eventDelta = e.wheelDelta || -e.deltaY * 40
      this.$scrollWrapper.scrollLeft = this.$scrollWrapper.scrollLeft - eventDelta / 4
      // 滚动滑轮时，判断是否到两端
      this.arrowHidden.left = this.$scrollWrapper.scrollLeft === 0
      this.arrowHidden.right = this.$scrollWrapper.scrollWidth - this.$scrollWrapper.offsetWidth <= this.$scrollWrapper.scrollLeft
    },
    handleSelectedMenu(menu) {
      if (!menu.children || !menu.children.length) {
        this.$router.push(menu.originalAddr || `/${menu.menuUrl}`)
      }
      this.$store.commit('SET_ACTIVE_TOP_MENU_ID', menu.menuId)
    },
    // 点击滚动菜单
    async handleScrollMenu(direction) {
      this.arrowHidden = await handleScrollFromClick(this.$scrollWrapper, this.$scrollPane, this.$menuItems, direction)
    }
  },
  mounted() {
    this.$scrollPane = this.$refs.scrollPane.$el
    this.$scrollWrapper = this.$refs.scrollPane.$refs.wrap
    this.$menuItems = this.$refs.menuItem

    this.arrowHidden.right = this.$scrollWrapper.scrollWidth - this.$scrollWrapper.offsetWidth <= this.$scrollWrapper.scrollLeft
  }
}
</script>

<style lang="scss" scoped>
.navbar-menu-container {
  position: relative;
  margin-left: 40px;
  padding: 0 30px;
  color: #fff;

  .scroll-btn {
    position: absolute;
    top: 0;
    bottom: 0;
    width: 30px;
    font-size: 18px;
    cursor: pointer;
    transition: all .3s;

    &.left {
      left: 0;
      text-align: left;
    }

    &.right {
      right: 0;
      text-align: right;
    }
  }

  .top-menu {
    flex: 1 1 auto;
    height: $navbar-height;
    font-size: 14px;
    overflow: hidden;

    ::v-deep .el-scrollbar__view {
      display: flex;
      flex-wrap: nowrap;
      height: 100%;

      .menu-item {
        flex: 1 0 auto;
        padding: 0 12px;
        cursor: pointer;
        user-select: none;
        transition: all .3s;

        &.active {
          background-color: rgba(0, 0, 0, .3);
        }

        &:hover {
          background-color: rgba(0, 0, 0, .3);
        }

        .svg-icon {
          margin-right: 8px;
        }
      }
    }
  }
}
</style>