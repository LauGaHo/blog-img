<template>
  <div class="avatar-container">
    <el-dropdown trigger="click" @command="handleCommand">
      <div class="avatar-wrapper" style="color: #fff">
        <img v-if="avatar" :src="avatar" class="user-avatar" />
        <div v-else class="headerImg">{{ headerImg }}</div>
        <span style="white-space: nowrap">{{ userName }}</span>
        <i class="el-icon-caret-bottom"></i>
      </div>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="home">{{ $t('menu.home') }}</el-dropdown-item>
        <el-dropdown-item command="changePwd">{{ $t('otherLang.changePwd') }}</el-dropdown-item>
        <el-dropdown-item command="personal">{{ $t('otherLang.personalCenter') }}</el-dropdown-item>
        <el-dropdown-item command="defaultSystem">{{ $t('otherLang.defualtSystem') }}</el-dropdown-item>
        <el-dropdown-item command="logOut" v-if="isCanLogOut">{{ $t('otherLang.signOut') }}</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>

    <gs-dialog
      :visible.sync="pwdModal"
      width="30%"
      :title="$t('person.changePwd')"
      @save="updatePwd"
      @cancel="cancelHandle"
      @closed="afterClose"
    >
      <el-form
        ref="updatePwdModel"
        v-loading="loading"
        :model="updatePwdModel"
        :label-width="$i18n.locale === 'zh-cn' ? '80px' : '160px'"
        size="small"
        :rules="updatePwdFormRules"
      >
        <el-form-item :label="$t('person.originalPwd')" prop="oldMagic">
          <el-input v-model.trim="updatePwdModel.oldMagic" type="password" :placeholder="$t('person.originalPwdTip')" />
        </el-form-item>
        <el-form-item :label="$t('person.newPwd')" prop="magic">
          <el-input v-model.trim="updatePwdModel.magic" type="password" :placeholder="$t('person.newPwdTip')" />
        </el-form-item>
        <el-form-item :label="$t('person.confirmPwd')" prop="confirmMagic">
          <el-input v-model.trim="updatePwdModel.confirmMagic" type="password" :placeholder="$t('person.confirmPwdTip')" />
        </el-form-item>
      </el-form>
    </gs-dialog>
  </div>
</template>

<script>
import _config from '@/config'
import { setDefaultSystem } from '@/api/home'
import { updateUserPsw } from '@/api/app'
import { getUserInfo } from '@/utils/auth'
import { encode } from '@/utils/base64'

export default {
  name: 'Personal',
  data() {
    return {
      loading: false,
      pwdModal: false,
      updatePwdModel: {
        oldMagic: '',
        magic: '',
        confirmMagic: ''
      }
    }
  },
  computed: {
    userInfo() {
      return getUserInfo()
    },
    headerImg() {
      return this?.userInfo?.userFullName.charAt(this.userInfo.length - 1) ?? ''
    },
    userName() {
      return this.userInfo?.userFullName ?? ''
    },
    avatar() {
      return this.$store.state.user.userHeadImgUrl
    },
    updatePwdFormRules() {
      const validatePass = (rule, value, callback) => {
        if (value.length < 6) callback(new Error(this.$t('person.pwdLengthTip')))
        else callback()
      }
      return {
        oldMagic: [{ required: true, trigger: 'blur', message: this.$t('person.originalPwdTip') }],
        magic: [{ required: true, trigger: 'blur', validator: validatePass }],
        confirmMagic: [{ required: true, trigger: 'blur', message: this.$t('person.confirmPwdAgainTip') }]
      }
    },
    portalType() {
      return this.userInfo?.portalType
    },
    urlLogout() {
      return this.userInfo?.urlLogout
    },
    isCanLogOut() {
      /*
       * 判断是否可以退出登录
       * 判断用户信息中是否有urlLogout 如果有则显示退出按钮
       */
      if (this.portalType === 'sso') {
        return this.urlLogout
      } else {
        return true
      }
    }
  },
  methods: {
    async goPersonInfo() {
      await this.$router.push('/person-info')
    },
    setDefaultSystem() {
      this.$confirm(this.$t('person.defaultSystemTip'), this.$t('person.confirmMsg'), {
        distinguishCancelAndClose: true
      }).then(() => {
        setDefaultSystem(_config.systemCode).then(res => {
          if (this.reqIsSucceed(res)) this.$message.success(res.msg)
        })
      })
    },
    ssoLogout() {
      this.$store.dispatch('LogOut').then(() => {
        localStorage.removeItem('portalType')
        localStorage.removeItem('urlLogout')
        window.location.href = this.isCanLogOut
      })
    },
    logout() {
      if (this.portalType === 'sso' && this.isCanLogOut) {
        this.ssoLogout()
      } else {
        this.$store.dispatch('LogOut').then(() => {
          if (process.env.NODE_ENV !== 'development') window.location.href = `${window.VUE_AUTH_API ? window.VUE_AUTH_API : ''}/login`
          else window.location.href = '/login'
        })
      }
    },
    cancelHandle() {
      this.$refs['updatePwdModel'].resetFields()
      this.pwdModal = false
    },
    afterClose() {
      this.$bus.$emit('check-use-limit')
    },
    handleCommand(command) {
      switch (command) {
        case 'home':
          this.$router.push('/home')
          break
        case 'changePwd':
          this.pwdModal = true
          break
        case 'personal':
          this.$router.push('/person-info')
          break
        case 'defaultSystem':
          this.setDefaultSystem()
          break
        case 'logOut':
          this.logout()
          break
      }
    },
    // 修改密码
    updatePwd() {
      this.$refs.updatePwdModel.validate(async valid => {
        if (this.updatePwdModel.magic !== this.updatePwdModel.confirmMagic) {
          this.$message.error(this.$t('person.confirmPwdErrorTip'))
          return
        }
        if (valid) {
          this.loading = true
          try {
            const userPswForm = {
              params: {
                oldMagic: encode(this.updatePwdModel.oldMagic),
                magic: encode(this.updatePwdModel.magic),
                confirmMagic: encode(this.updatePwdModel.confirmMagic)
              }
            }
            const res = await updateUserPsw(userPswForm)
            if (this.reqIsSucceed(res)) {
              this.$message.success(res.msg)
              this.logout()
            }
          } finally {
            this.loading = false
          }
        }
      })
    }
  },
  created() {
    this.$bus.$on('change-pwd', () => {
      this.pwdModal = true
    })
  }
}
</script>

<style lang="scss" scoped>
.headerImg {
  width: 36px;
  height: 36px;
  font-size: 20px;
  font-weight: 800;
  color: #fff;
  border-radius: 50%;
  text-align: center;
  line-height: 36px;
  background: var(--color-primary-light-2);
  margin-right: 5px;
}

.avatar-container {
  .avatar-wrapper {
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;

    .user-avatar {
      width: 30px;
      height: 30px;
      border-radius: 50%;
    }

    .el-icon-caret-bottom {
      font-size: 12px;
    }
  }
}
</style>