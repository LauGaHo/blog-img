<template>
  <div class="panel-portal">
    <el-tooltip effect="dark" content="返回门户" :placement="placement">
      <i class="gsfont gs-icon-zhuye" :style="{ fontSize: '22px', color: iconColor }" @click="jumpTo" />
    </el-tooltip>
  </div>
</template>

<script>
export default {
  name: 'Portal',
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  methods: {
    jumpTo() {
      location.href = `${window.VUE_AUTH_API}/portal`
    }
  }
}
</script>