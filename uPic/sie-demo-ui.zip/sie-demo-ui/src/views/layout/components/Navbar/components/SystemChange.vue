<template>
  <div class="system-change">
    <el-tooltip effect="dark" :content="$t('button.system')" :placement="placement">
      <el-popover
        v-model="isPopoverShow"
        :placement="placement"
        trigger="click"
        popper-class="system-list-popover-container"
      >
        <div class="system-list-container">
          <div
            v-for="(system, index) in systems"
            :key="index"
            :class="['system-item', system.disabled ? 'disabled' : '']"
            @click=handleJumpSystem(system)
          >
            <div class="logo">
              <img :src="system.iconUrl" alt="">
            </div>
            <div class="name">
              {{ $i18n.locale === 'zh-cn' ? system.systemName : system.systemEnName }}
            </div>
          </div>
        </div>

        <i slot="reference" class="gsfont gs-icon-mokuai" :style="{ fontSize: '26px', color: iconColor }" />
      </el-popover>
    </el-tooltip>
  </div>
</template>

<script>
import { getSystemListByUser } from "@/api/system-manage/reverse-authorization";

export default {
  name: "SystemChange",
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  data() {
    return {
      systems: [],
      isPopoverShow: false
    }
  },
  methods: {
    async getUserSystems() {
      const res = await getSystemListByUser()
      if (this.reqIsSucceed(res)) {
        this.systems = res.data
          .filter(system => system.systemCode !== 'portal')
          .map(system => {
            system.disabled = system.systemCode === this.$store.state.app.systemCode
            return system
          })
        this.$store.commit('SET_SYSTEMS', this.systems)
      }
    },
    handleJumpSystem(system) {
      if (system.disabled) 
        return
      
      if (!system.requestUrl) {
        this.$message.warning('该系统还未开放')
        return
      }
      if (system.useState === 1) {
        this.$message.error('该系统禁止使用')
        return
      }
      this.isPopoverShow = false
      window.open(system.requestUrl)
    },
  },
  mounted() {
    this.getUserSystems()
  }
}
</script>

<style lang="scss">
.system-list-container {
  display: flex;
  flex-direction: column;
  max-height: 600px;
  overflow-y: auto;

  .system-item {
    display: flex;
    align-items: center;
    padding: 8px;
    border-radius: 4px;
    user-select: none;
    cursor: pointer;
    transition: all .3s;

    &.disabled {
      cursor: default;
      color: #999;
    }

    &:not(:last-of-type) {
      margin-bottom: 8px;
    }

    &:not(.disabled):hover {
      color: var(--color-primary);
      background-color: var(--color-primary-light-9);
    }

    .logo {
      margin-right: 8px;
      width: 24px;
      height: 24px;

      & > img {
        width: 24px;
        height: 24px;
      }
    }
  }
}
</style>