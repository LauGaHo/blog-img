<template>
  <div class="panel-menu">
    <el-tooltip effect="dark" :content="$t('otherLang.helpMenu')" :placement="placement">
      <i class="iconfont1 icon-caidan" :style="{ fontSize: '24px', color: iconColor }" @click="handleToggleMenu" />
    </el-tooltip>

    <el-drawer
      ref="drawerMenu"
      :title="$t('otherLang.helpMenu')"
      :visible.sync="dialogMenu"
      size="100%"
      custom-class="dialog-tablet-menu"
      direction="btt"
      :append-to-body="true"
      :with-header="false"
    >
      <div class="tablet-menu">
        <i class="icon el-icon-circle-close" @click="handleClose"></i>
        <el-row :gutter="30" class="first-menu">
          <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="4" v-for="(item, index) in routes" :key="index">
            <div class="menu-item" @click="handleShowChild(item)">
              <p>
                <gs-icon :icon="item.meta.icon" size="36px" color="#FFFFFF" />
              </p>
              <el-tooltip class="item" effect="dark" :content="lang(item)" placement="bottom">
                <p class="menu-title">{{ lang(item) }}</p>
              </el-tooltip>
            </div>
          </el-col>
        </el-row>

        <el-dialog :title="title" custom-class="dialog-child-menu" append-to-body :visible.sync="dialogMenuVisible">
          <el-row :gutter="30">
            <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="4" v-for="(item, index) in selectChildRouters" :key="index">
              <div class="menu-item" @click="jumpTo(item)">
                <div class="svg-item">
                  <svg-icon :icon-class="item.meta.icon" />
                </div>
                <el-tooltip class="item" effect="dark" :content="lang(item)" placement="bottom">
                  <p class="menu-title">{{ lang(item) }}</p>
                </el-tooltip>
              </div>
            </el-col>
          </el-row>
        </el-dialog>
      </div>
    </el-drawer>
  </div>
</template>

<script>
export default {
  name: "Tablet",
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  data() {
    return {
      dialogMenu: false,
      title: '',
      dialogMenuVisible: false,
      selectChildRouters: []
    }
  },
  computed: {
    routes() {
      return this.$store.getters.permission_routers
    },
  },
  methods: {
    handleToggleMenu() {
      this.dialogMenu = true
    },
    lang(val) {
      if (this.$i18n.locale === 'en-us') 
        return val.menuEnName || 'no-name'
      
      return val.menuName || 'no-name'
    },
    handleShowChild(item) {
      if (item.children) {
        this.title = this.$store.state.user.lang === 'en-us' ? item.menuEnName : item.menuName
        this.selectChildRouters = item.children
      }
      this.dialogMenuVisible = true
    },
    jumpTo(route) {
      let path = route.path
      if (route.params && typeof route.params === 'string') 
      {try {
        let paramJson = JSON.parse(route.params)
        // 如果是动态表单需要渲染固定组件
        if (paramJson && paramJson.menu_type === 'DYNAMIC_FORM') {
          path = path.replace(':formId', paramJson.diy_code)
          if (paramJson.layout_code) 
            path += `?layoutId=${paramJson.layout_code}`
            
        }
      } catch (err) {}}
      
      this.dialogMenuVisible = false
      this.dialogMenu = false
      this.$router.push(path)
    },
    handleClose() {
      this.dialogMenu = false
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep .dialog-tablet-menu {
  background: url('~@/assets/images/table-menu.jpeg') no-repeat;
  background-size: 100% 100%;

  ::v-deep .el-dialog__header {
    display: none;
  }

  ::v-deep .el-dialog__body {
    padding: 0;
  }

  .tablet-menu {
    position: relative;
    width: 100%;
    height: 100vh;
    overflow: hidden auto;
    padding: 5% 15%;
    justify-content: center;
    align-items: center;

    .icon {
      position: fixed;
      right: 15px;
      top: 15px;
      font-size: 40px;
      color: #fff;
      cursor: pointer;
    }

    .first-menu.el-row {
      width: 100%;

      .el-col {
        margin: 15px 0;

        .menu-item {
          padding: 40px 10px 10px;
          text-align: center;
          position: relative;
          cursor: pointer;

          p {
            margin: 0;
          }

          svg {
            color: #fff;
            font-size: 80px;
          }

          .menu-title {
            color: #fff;
            font-size: 20px;
            margin: 30px 0 10px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            word-break: break-all;
            width: 100%;
            border: none;
            outline: none;
          }
        }

        &:nth-child(1n) .menu-item {
          background-color: #3089f3;
        }

        &:nth-child(2n) .menu-item {
          background-color: #18c2cc;
        }

        &:nth-child(3n) .menu-item {
          background-color: #28c863;
        }

        &:nth-child(4n) .menu-item {
          background-color: #8860fe;
        }

        &:nth-child(5n) .menu-item {
          background-color: #f38243;
        }
      }
    }
  }
}
</style>