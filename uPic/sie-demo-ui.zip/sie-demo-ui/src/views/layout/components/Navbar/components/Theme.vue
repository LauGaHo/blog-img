<template>
  <div class="themeSkin">
    <el-tooltip effect="dark" :content="$t('button.theme')" :placement="placement">
      <div class="top-bar__item top-bar__item--show" @click="openSetting">
        <i class="iconfont1 icon-zhuti1" :style="{ fontSize: '26px', color: iconColor }" />
      </div>
    </el-tooltip>

    <gs-drawer
      :visible.sync="visible"
      :title="$t('theme.styleConfig')"
      size="400px"
      append-to-body
      :show-footer="false"
      :has-close-confirm="false"
      :wrapper-closable="true"
      :close-on-press-escape="true"
    >
      <section class="layout-setting">
        <p class="setting-title">{{ $t('theme.layoutStyle') }}</p>
        <div class="setting-items">
          <span
            v-for="(item, idx) in layoutStyles"
            :key="idx"
            class="setting-item"
            :class="[layoutConfigValue === item.key ? 'checked' : '']"
            @click="handleChangeLayoutConfig(item.key)"
          >
            <img class="icon" :src="item.icon" alt="" />
            <img class="check" :src="checkIcon" alt="" />
            <span>{{ $t(item.label) }}</span>
          </span>
        </div>

        <p class="setting-title">{{ $t('theme.overallStyleSetting') }}</p>
        <div class="setting-items">
          <span
            v-for="(item, idx) in layoutThemes"
            :key="idx"
            class="setting-item"
            :class="[theme === item.key ? 'checked' : '']"
            @click="handleChangeLayoutTheme(item.key)"
          >
            <img class="icon" :src="item.icon" alt="" />
            <img class="check" :src="checkIcon" alt="" />
            <span>{{ $t(item.label) }}</span>
          </span>
        </div>

        <template v-if="false">
          <p class="setting-title">{{ $t('theme.navbarStyleSetting') }}</p>
          <div class="setting-items">
          <span
            v-for="(item, idx) in navbarThemes"
            :key="idx"
            class="setting-item"
            :class="[navbarTheme.key === item.key ? 'checked' : '']"
            @click="handleChangeNavbarTheme(idx)"
          >
            <img class="icon" :src="item.icon" alt="" />
            <img class="check" :src="checkIcon" alt="" />
            <span>{{ $t(item.label) }}</span>
          </span>
          </div>
        </template>

        <p class="setting-title">{{ $t('theme.controlStyleSetting') }}</p>
        <div class="setting-items">
          <span
            v-for="(color, idx) in themeColors"
            :key="idx"
            class="color"
            :class="[themeColor === color ? 'checked' : '']"
            @click="handleChangeThemeColor(color)"
          >
            <span class="theme-color-item" :style="{ backgroundColor: color }">
              <i class="icon el-icon-check"></i>
            </span>
          </span>
        </div>
      </section>
    </gs-drawer>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import theme, { setCookieInDomain, getCookieInDomain } from '@/utils/theme'

// icon
import normalLayoutIcon from '@/assets/images/normal_layout.png'
import compactLayoutIcon from '@/assets/images/compact_layout.png'

export default {
  name: "Theme",
  props: {
    iconColor: {
      type: String,
      default: '#FFFFFF'
    },
    placement: {
      type: String,
      default: 'bottom'
    }
  },
  data() {
    return {
      visible: false,
      checkIcon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/gouxuan.svg',
      layoutThemes: [
        // 默认主题
        {
          label: 'theme.light',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/putong.svg',
          key: 'default'
        },
        // 暗夜主题
        {
          label: 'theme.dark',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/anye.svg',
          key: 'black'
        },
      ],
      navbarThemes: [
        {
          label: 'theme.sie',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/saiyihong.svg',
          key: 'red',
          colors: ['#AD0F3B', '#AE063D']
        },
        {
          label: 'theme.sapphireBlue',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/putong.svg',
          key: 'sapphireBlue',
          colors: ['#4EA5ED', '#3C7FFF']
        },
        {
          label: 'theme.skyBlue',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/xingkonglan.svg',
          key: 'blue',
          colors: ['#253790', '#1C2858']
        },
        {
          label: 'theme.tangerine',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/jicheng.svg',
          key: 'tangerine',
          colors: ['#F65C36', '#E43B00']
        },
        {
          label: 'theme.green',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/qinglv.svg',
          key: 'green',
          colors: ['#25C98F', '#11CFAC']
        },
        {
          label: 'theme.orange',
          icon: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/svg/theme/nuanqiu.svg',
          key: 'orange',
          colors: ['#F7A520', '#EC8511']
        }
      ],
      themeColors: ['#C71643', '#204BE3', '#1B97FF', '#F05516', '#F7A520', '#14CDA8', '#24D21C', '#0FBEEE', '#5057E9', '#792AEA', '#25347B'],
      // 布局风格
      layoutConfigValue: getCookieInDomain('layoutConfig') || 'default',
      layoutStyles: [
        {
          label: 'theme.defaultLayout',
          icon: normalLayoutIcon,
          key: 'default'
        },
        {
          label: 'theme.compactLayout',
          icon: compactLayoutIcon,
          key: 'compact'
        }
      ]
    }
  },
  computed: {
    ...mapGetters(['themeColor', 'theme', 'navbarTheme', 'layoutConfig'])
  },
  methods: {
    openSetting() {
      this.visible = true
    },
    // 修改整体主题风格
    handleChangeLayoutTheme(key) {
      let theme = key || this.theme
      if (theme === 'undefined' || theme === null) 
        theme = 'default'
      
      const className = `theme-${theme}`
      document.body.classList = []
      document.body.classList.add(className)
      setCookieInDomain('theme', theme)
      this.$store.commit('SET_THEME', theme)
    },
    // 修改导航栏主题
    handleChangeNavbarTheme(idx) {
      const navbarTheme = this.navbarThemes[idx]
      if (navbarTheme) {
        this.$store.commit('SET_NAVBAR_THEME', navbarTheme)
        setCookieInDomain('navbarTheme', navbarTheme)
      }
      // 设置导航栏主题css 变量
      document.documentElement.style.setProperty(
        '--color-navbar',
        `linear-gradient(to right, ${this.navbarTheme.colors[0]}, ${this.navbarTheme.colors[1]})`
      )
    },
    // 修改控件主题色
    async handleChangeThemeColor(color) {
      await theme(color)
      this.$store.commit('SET_THEME_COLOR', color)
    },
    // 修改布局风格
    handleChangeLayoutConfig(config) {
      this.layoutConfigValue = config
      setCookieInDomain('layoutConfig', config)
      this.$store.commit('SET_LAYOUT_CONFIG', config)
    }
  },
  created() {
    this.handleChangeLayoutTheme()
    this.handleChangeNavbarTheme()
  }
}
</script>

<style lang="scss" scoped>
.layout-setting {
  .setting-title {
    font-size: 16px;

    &.inline {
      display: inline-block;
    }
  }

  .setting-items {
    @include flex-row(flex-start, center);

    flex-wrap: wrap;

    &.inline {
      display: inline-flex;
      margin-left: 16px;
      vertical-align: super;
    }

    .setting-item {
      @include flex-row(center, center);

      flex-direction: column;
      position: relative;
      margin: 0 24px 24px 0;
      font-size: 14px;
      user-select: none;
      cursor: pointer;

      &.checked > .check {
        visibility: visible;
      }

      .icon {
        margin-bottom: 4px;
        box-shadow: 0 0 5px 3px rgba(0, 0, 0, 0.05);
        border-radius: 4px;
        overflow: hidden;
      }

      .check {
        position: absolute;
        left: 50%;
        top: 30%;
        transform: translate(-50%, -50%);
        visibility: hidden;
      }
    }

    .color {
      margin: 0 18px 24px 0;
      user-select: none;
      cursor: pointer;

      &.checked .theme-color-item > .icon {
        visibility: visible;
      }

      .theme-color-item {
        display: block;
        position: relative;
        width: 20px;
        height: 20px;
        border-radius: 5px;

        .icon {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          color: #fff;
          visibility: hidden;
        }
      }
    }
  }
}
</style>