<template>
  <div class="gs-navbar animated">
    <!-- logo -->
    <div class="logo-sidebar">
      <div class="logo-container">
        <router-link to="/home">
          <img class="sie-logo" :src="logoUri" alt="" />
        </router-link>
      </div>
    </div>

    <!-- 顶部菜单导航 -->
    <navbar-menu v-if="$store.getters.layoutConfig === 'compact'" />

    <!-- 顶部各类操作按钮 -->
    <div class="top-info">
      <template v-if="$store.getters.layoutConfig === 'default'">
        <!-- 系统切换 -->
<!--        <system-change />-->
        <!-- 返回门户页 -->
        <portal />
        <!-- 信息 -->
        <message />
        <!-- 主题皮肤 -->
        <theme />
        <!-- 语言切换 -->
        <locale />
        <!-- 帮助中心 -->
        <help />
      </template>
      <!-- 个人中心 -->
      <personal />
    </div>
  </div>
</template>

<script>
import Portal from './components/Portal'
import Message from './components/Message'
import Theme from './components/Theme'
import Locale from './components/Locale'
import Help from './components/Help'
import Personal from './components/Personal'
import NavbarMenu from "@/views/layout/components/Navbar/components/NavbarMenu";
import logo1 from '@/assets/images/logo1.png'

export default {
  data() {
    return {
      navbarFixed: false
    }
  },
  components: {
    // SystemChange,
    Portal,
    Message,
    Theme,
    Locale,
    Help,
    Personal,
    NavbarMenu
  },
  computed: {
    logoUri() {
      let setting = this.$store.state.app.systemSetting
      let uri = logo1
      if (setting) 
        uri = JSON.parse(setting).systemLogo
      
      return uri
    }
  },
  watch: {
    '$route': {
      handler(route) {
        // 通过当前 $route.path 找到路由表中对应的菜单信息
        const routeName = route.path.split('/')[1]
        const activeMenuInfo = this.$store.getters.permission_routers.find(routeMenu => routeMenu.name === routeName)

        if (activeMenuInfo) {
          this.$store.commit('SET_ACTIVE_TOP_MENU_ID', activeMenuInfo.meta.menuId)
        } else {
          this.$store.commit('SET_ACTIVE_TOP_MENU_ID', null)
        }
      },
      immediate: true
    }
  },
  methods: {
  },
  mounted() {
    this.$store.dispatch('SetSystemSetting')
  },
}
</script>

<style lang="scss" scoped>
.gs-navbar {
  position: relative;
  display: flex;
  justify-content: space-between;
  padding: 0 15px;
  height: $navbar-height;
  line-height: $navbar-height;
  //background: var(--color-navbar);
  background: var(--color-primary);

  &::after {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    width: 100%;
    height: 100%;
    background-image: url('~@/assets/images/nav_bar_bg.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    pointer-events: none;
  }

  .logo-sidebar {
    flex: 1;

    .logo-container {
      display: inline-block;
      text-align: center;

      .sie-logo {
        height: 48px;
        vertical-align: middle;
        border-style: none;
      }
    }
  }

  .top-info {
    display: flex;
    justify-content: flex-end;

    & > div {
      display: flex;
      // align-items: center;
      margin-left: 40px;
      cursor: pointer;
    }
  }

  &.animated {
    -webkit-animation-duration: 0.1s;
    animation-duration: 0.1s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }

  &.isFixed {
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1;
  }
}
</style>
