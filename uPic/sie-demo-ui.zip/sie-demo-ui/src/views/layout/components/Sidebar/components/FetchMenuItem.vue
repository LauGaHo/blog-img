<template>
  <a-menu-item
    :key="item.menuFetchId"
    @click="jumpTo"
    v-bind="$props"
    v-on="$listeners"
  >
    <div class="amenu-title top-menu-item">
      <span class="menu-title">{{ item.fetchItemName }}</span>
    </div>
  </a-menu-item>
</template>

<script>
import { defineComponent } from '@vue/composition-api'
import { Menu } from 'ant-design-vue'

export default defineComponent({
  name: 'FetchMenuItem',
  components: {
    'a-menu-item': Menu.Item
  },
  props: {
    ...Menu.Item.props,
    item: {
      type: Object,
      default: () =>({})
    },
    routePath: {
      type: String,
      default: ''
    }
  },
  methods: {
    jumpTo() {
      const fetchExpand = this.item.fetchExpand ? JSON.parse(this.item.fetchExpand) : {}
      this.$router.push(this.routePath, fetchExpand)
    }
  }
})
</script>

<style lang="scss" scoped>

</style>