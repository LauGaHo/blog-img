<template>
  <a-menu-item
    :key="route.path"
    @click="jumpTo"
    v-bind="$props"
    v-on="$listeners"
  >
    <div class="amenu-title top-menu-item">
      <gs-icon v-if="route.meta.icon" :icon="route.meta.icon" class-name="svg-icon"/>
      <span class="menu-title">{{ menuTitle }}</span>
    </div>
  </a-menu-item>
</template>

<script>
import { defineComponent } from '@vue/composition-api'
import { Menu } from 'ant-design-vue'
import { formatDynamicFormPath } from '@/views/layout/utils/dynamicFormHelper'

export default defineComponent({
  name: 'MenuItem',
  components: {
    'a-menu-item': Menu.Item
  },
  props: {
    ...Menu.Item.props,
    route: {
      type: Object,
      require: true
    }
  },
  computed: {
    menuTitle() {
      if (this.$i18n.locale === 'en-us') {
        //让菜单翻译从缓存中读取，同步到权限系统用户自定义的中英文菜单翻译
        return this.route.menuEnName || 'no-name'
      }
      return this.route.menuName || 'no-name'
    }
  },
  methods: {
    jumpTo() {
      let { meta } = this.route
      let path = formatDynamicFormPath(this.route)
      if (meta.url) {
        const regExp = /^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+/
        let bool = regExp.test(meta.url)
        if (!bool) return
        this.$router.push({
          path: '/third-view',
          query: {
            url: meta.url
          }
        })
        return
      }
      this.$router.push(path)
    }
  }
})
</script>

<style lang="scss" scoped>

</style>