<template>
  <el-autocomplete
    v-model="searchData"
    className="input-with-select"
    :fetch-suggestions="querySearch"
    trigger-on-focus
    size="small"
    placeholder="功能搜索"
    @select="handleSelect"
  >
    <i slot="prefix" class="el-input__icon el-icon-search" />
  </el-autocomplete>
</template>

<script>
import { defineComponent } from '@vue/composition-api'
import { getRoleMenuByKeyWordAndSysCode } from '@/api/home'

export default defineComponent({
  name: "MenuSearch",
  data() {
    return {
      searchData: ''
    }
  },
  methods: {
    handleSelect(item) {
      if (item.useState === 1) {
        // 禁用状态
        this.$message.warning('该系统禁止使用')
        return
      }
      this.$router.push({ path: `/${item.menuUrl}` })
    },
    // 搜索菜单
    async getRoleMenuByKeyWord(queryString) {
      let restaurants = []
      let res = await getRoleMenuByKeyWordAndSysCode(queryString)
      if (this.reqIsSucceed(res)) {
        // 根据当前语言环境，切换菜单名的中英文显示。
        restaurants = res.data.map(item => ({
          ...item,
          value: this.$i18n.locale === 'en-us' ? item.menuEnName : item.menuName
        }))
      }
      return restaurants
    },
    async querySearch(queryString, cb) {
      let restaurants = await this.getRoleMenuByKeyWord(queryString)
      cb(restaurants)
    }
  }
})
</script>

<style lang="scss" scoped>

</style>