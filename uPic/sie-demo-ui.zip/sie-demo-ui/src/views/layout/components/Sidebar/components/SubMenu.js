import { Menu } from 'ant-design-vue'
import MenuItem from './MenuItem'
import FetchMenuItem from './FetchMenuItem'

import { getFetchMenu } from '@/api/menu'

export default {
  template: `
    <a-sub-menu
      :key="route.path"
      :class="[matchClassName]"
      :popupClassName="childLenClass + '' + hasChildrenClass"
      @titleClick="handleJumpMenu"
      v-bind="$props"
      v-on="$listeners"
    >
      <span slot="title">
        <gs-icon v-if="route.meta.icon" :icon="route.meta.icon" class-name="svg-icon"/>
        <span class="menu-title">{{ menuTitle }}</span>
      </span>
      <template v-for="item in route.children">
        <sub-menu
          v-if="(!item.noChild && item.children) || item.meta.isFetch"
          :route="item"
          :key="item.meta.menuId"
        />
        <template v-else>
          <template v-if="isFetchMenu">
            <fetch-menu-item :key="item.menuFetchId" :item="item" :route-path="route.meta.fetchPath"/>
          </template>
          <template v-else>
            <menu-item :key="item.meta.menuId" :route="item"/>
          </template>
        </template>
      </template>
    </a-sub-menu>
  `,
  name: 'SubMenu',
  inheritAttrs: false,
  isSubMenu: true,
  components: {
    'a-sub-menu': Menu.SubMenu,
    MenuItem,
    FetchMenuItem,
  },
  props: {
    ...Menu.SubMenu.props,
    route: {
      type: Object,
      require: true
    }
  },
  data() {
    return {
      fetchMenuItems: []
    }
  },
  computed: {
    matchClassName() {
      const parentPath = this.$route.path.match(/\/[^/]+/)[0]
      return parentPath === this.route.path ? 'ant-menu-item-selected' : ''
    },
    childLenClass() {
      return this.route.children && this.route.children.length > 6 ? 'len-gt-6' : ''
    },
    // 是否含有子菜单时的 class name
    hasChildrenClass() {
      return this.route.children && this.route.children.some(child => child.children && child.children.length >= 1) ? 'has-children' : ''
    },
    // 菜单标题
    menuTitle() {
      if (this.$i18n.locale === 'en-us') {
        //让菜单翻译从缓存中读取，同步到权限系统用户自定义的中英文菜单翻译
        return this.route.menuEnName || 'no-name'
      }
      return this.route.menuName || 'no-name'
    },
    // 是否快捷入口菜单
    isFetchMenu() {
      return !!this.route.meta.isFetch
    }
  },
  created() {
    this.isFetchMenu && this.handleFetchMenuItems()

    // 监听设为快捷入口事件
    // TODO：如果是微前端子应用，需要添加 action 监听
    this.$bus.$on('setFetchMenu', this.refreshFetchMenu)
  },
  beforeDestroy() {
    this.$bus.$off('setFetchMenu')
  },
  methods: {
    // 点击子菜单标题跳转
    async handleJumpMenu() {
      if (!this.isFetchMenu) return
      this.$emit('currentOpenKey', this.route.meta.menuId)
      await this.$router.push(this.route.path)
    },
    // 获取快捷入口列表
    async handleFetchMenuItems() {
      try {
        const data = {
          params: {
            menuId: this.route.meta.menuId
          }
        }
        const res = await getFetchMenu(data)
        this.fetchMenuItems = res.data
      } catch {}
    },
    // 刷新快捷入口列表
    refreshFetchMenu(menuId) {
      if (menuId !== this.route.meta.menuId) return
      this.handleFetchMenuItems()
    }
  }
}