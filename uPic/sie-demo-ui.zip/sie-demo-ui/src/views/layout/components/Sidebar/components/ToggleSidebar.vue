<template>
  <div class="menu-toggle" @click="toggleSideBar">
    <i :class="[sidebar.opened ? 'el-icon-d-arrow-left' : 'el-icon-d-arrow-right']" />
  </div>
</template>

<script>
import { defineComponent } from '@vue/composition-api'

export default defineComponent({
  name: "ToggleSidebar",
  computed: {
    sidebar() {
      return this.$store.getters.sidebar
    }
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('ToggleSideBar')
    }
  }
})
</script>

<style lang="scss" scoped>
.menu-toggle {
  position: absolute;
  top: 70px;
  right: -16px;
  width: 16px;
  height: 40px;
  line-height: 40px;
  font-size: 16px;
  text-align: center;
  cursor: pointer;
  background-color: #fff;
  border-radius: 0 4px 4px 0;
  z-index: 10;
}
</style>