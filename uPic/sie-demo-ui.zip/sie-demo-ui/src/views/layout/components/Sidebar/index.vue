<template>
  <section
     :class="[
      'sidebar-container-wrap',
      { 'shrink-sidebar': !sidebar.opened },
      { 'close-sidebar': !routes.length }
    ]"
  >
    <el-scrollbar
      :class="[
        'sidebar-container',
        { 'shrink-sidebar': !sidebar.opened },
        { 'close-sidebar': !routes.length }
      ]"
      wrapClass="scrollbar-wrapper"
    >
      <!--    搜索框-->
      <div v-if="routes.length" :class="['menu-search', { 'no-padding' : !sidebar.opened}]">
        <menu-search v-if="sidebar.opened" />
        <el-popover v-else placement="right" trigger="click">
          <menu-search />
          <el-button slot="reference" icon="el-icon-search" size="mini" circle />
        </el-popover>
      </div>
      <!--    菜单-->
      <a-menu
        :selected-keys="[$route.path]"
        :open-keys.sync="openKeys"
        :mode="menuMode"
        v-bind:[menuInlineCollapsed]="!sidebar.opened && menuMode === 'inline'"
      >
        <template v-for="route in routes">
          <template v-if="!route.hidden && route.meta">
            <sub-menu
              v-if="(!route.noChild && route.children) || route.meta.isFetch"
              :route="route"
              :key="route.path"
            />
            <menu-item
              v-else
              :route="route"
              :key="route.path"
            />
          </template>
        </template>
      </a-menu>
    </el-scrollbar>

    <!--    折叠按钮-->
    <toggle-sidebar v-if="routes.length" class="toggle-sidebar-btn"/>
  </section>
</template>

<script>
import SubMenu from './components/SubMenu.js'
import MenuItem from './components/MenuItem'
import MenuSearch from './components/MenuSearch'
import ToggleSidebar from './components/ToggleSidebar'

import { Menu } from 'ant-design-vue'
import 'ant-design-vue/lib/menu/style'

export default {
  name: 'SideBar',
  components: {
    'a-menu': Menu,
    SubMenu,
    MenuItem,
    MenuSearch,
    ToggleSidebar
  },
  data() {
    return {
      openKeys: []
    }
  },
  computed: {
    sidebar() {
      return this.$store.getters.sidebar
    },
    routes() {
      const routes = this.$store.state.permission.routers
      if (this.$store.getters.layoutConfig === 'compact') {
        const activeMenu = routes.find(route => route.meta.menuId === this.$store.getters.activeTopMenuId)
        return activeMenu?.children ?? []
      }
      return routes
    },
    // 检查是否含有目录类型的菜单
    hasFolderMenuItem() {
      return this.routes.some(route => route.meta.isFetch)
    },
    // 根据菜单类型转换菜单栏模式
    menuMode() {
      return this.hasFolderMenuItem ? 'inline' : 'vertical'
    },
    // 菜单只有在 inline 模式下才需要绑定该属性
    menuInlineCollapsed() {
      return !this.sidebar.opened && this.menuMode === 'inline' ? 'inline-collapsed' : ''
    }
  },
  methods: {
    setOpenKeys(key) {
      this.openKeys = Array.from(new Set([...this.openKeys, key]))
    }
  }
}
</script>

<style lang="scss" scoped>
$sidebar-width: 200px;
$sidebar-hide-width: 50px;

.sidebar-container-wrap {
  position: relative;
  flex: 0 0 $sidebar-width;
  height: 100%;
  font-size: 0;
  box-shadow: 0 4px 10px 0 rgba(62, 72, 128, 0.22);
  transition: all 0.28s;

  &.close-sidebar {
    flex: 0 0 0;
  }

  &.shrink-sidebar {
    flex: 0 0 $sidebar-hide-width;
  }

  &:hover {
    .toggle-sidebar-btn {
      transform: scaleX(1);
    }
  }

  .toggle-sidebar-btn {
    transform-origin: left;
    transform: scaleX(0);
    transition: all .3s;
  }
}

.sidebar-container {
  width: $sidebar-width;
  height: 100%;

  &.close-sidebar {
    width: 0;
  }

  &.shrink-sidebar {
    width: $sidebar-hide-width;

    ::v-deep .ant-menu-vertical,
    ::v-deep .ant-menu-inline-collapsed {
      .amenu-title {
        margin: 0 !important;

        .menu-title {
          padding-left: 20px;
        }
      }

      & > .ant-menu-item {
        span.menu-title {
          display: none;
        }
      }

      .ant-menu-submenu {
        .ant-menu-submenu-title {
          padding: 0;
          border-radius: 0;
          margin: 4px 0;
          text-align: center;
          .svg-icon {
            font-size: 18px;
            margin-right: 0;
          }
          .ant-menu-submenu-arrow {
            display: none;
          }
          span.menu-title {
            display: none;
          }
        }
      }
    }
  }

  //reset element-ui css
  .horizontal-collapse-transition {
    transition: 0s width ease-in-out, 0s padding-left ease-in-out, 0s padding-right ease-in-out;
  }

  ::v-deep .scrollbar-wrapper {
    overflow-x: hidden !important;

    .el-scrollbar__view {
      height: 100%;
      box-sizing: border-box;

      &::before {
        content: '';
        display: table;
        height: 0;
        visibility: hidden;
      }
    }

    ::v-deep .el-scrollbar__bar.is-vertical {
      right: 0;
    }

    .ant-menu-vertical {
      border-right: none;
      overflow-x: hidden;

      .ant-menu-item {
        .amenu-title {
          margin: 0 5px;
        }
      }

      .ant-menu-submenu {
        .ant-menu-submenu-title {
          margin-left: 5px;
          margin-right: 5px;
          //border-radius: 20px;
        }
      }
    }

    .ant-menu-inline-collapsed {
      .ant-menu-submenu {
        .ant-menu-submenu-title {
          margin-left: 0;
          margin-right: 0;
        }
      }
    }

    .is-horizontal {
      display: none;
    }

    a {
      display: inline-block;
      width: 100%;
      overflow: hidden;
    }

    .svg-icon {
      margin-right: 10px;
      font-size: 16px;
    }
    .iconfont {
      margin-right: 16px;
      font-size: 16px;
    }

    .is-active > .el-submenu__title {
      color: #f4f4f5 !important;
    }
  }
}

.menu-search {
  display: flex;
  justify-content: center;
  margin: 8px 0;
  padding: 0 16px;

  &.no-padding {
    padding: 0;
  }
}

.item-title {
  margin-left: 10px;
}

::v-deep .el-popper {
  opacity: 0;
}

::v-deep .ant-menu-vertical .ant-menu-item,
.ant-menu-vertical-left .ant-menu-item,
.ant-menu-vertical-right .ant-menu-item,
.ant-menu-inline .ant-menu-item,
.ant-menu-vertical .ant-menu-submenu-title,
.ant-menu-vertical-left .ant-menu-submenu-title,
.ant-menu-vertical-right .ant-menu-submenu-title,
.ant-menu-inline .ant-menu-submenu-title {
  text-overflow: clip;
  overflow: visible;
}
</style>

<style lang="scss">
.ant-menu-vertical.ant-menu-sub.ant-menu-submenu-content {
  background-color: #30373d;
}

ul.ant-menu-vertical {
  overflow-y: auto;
}

.has-children > ul.ant-menu-sub.ant-menu-submenu-content {
  max-width: 200px !important;
}

.ant-menu-submenu-popup {
  z-index: 9999 !important;
  .ant-menu-vertical.ant-menu-sub.ant-menu-submenu-content {
    .ant-menu-item {
      //border-radius: 20px;
    }
  }
  &.len-gt-6 {
    .ant-menu-vertical.ant-menu-sub.ant-menu-submenu-content {
      max-width: 550px;
      .ant-menu-item {
        float: left;
        width: 180px;
        //border-radius: 20px;
      }
    }
  }
}

// inline mode
.ant-menu-inline-collapsed {
  width: 50px;

  .ant-menu-item {
    padding: 0 16px !important;
  }

  .ant-menu-submenu {
    .ant-menu-submenu-title {
      padding: 0 16px !important;
    }
  }
}

.withoutAnimation {
  .main-container,
  .sidebar-container {
    transition: none;
  }
}

ul.ant-menu-vertical::-webkit-scrollbar {
  width: 6px;
  /* 对垂直流动条有效 */
  height: 10px;
  /* 对水平流动条有效 */
}
ul.ant-menu-vertical::-webkit-scrollbar-thumb {
  border-radius: 7px;
}
/*定义滚动条的轨道颜色、内阴影及圆角*/
ul.ant-menu-vertical::-webkit-scrollbar-track {
  background-color: #fff;
}
/*定义滑块颜色、内阴影及圆角*/
ul.ant-menu-vertical::-webkit-scrollbar-thumb {
  background-color: #eef0f6;
}
</style>
