<template>
  <div :class="['tags-view-container', { compact: isCompactLayout }]">
    <div v-show="isCompactLayout" class="scroll-arrow left" :class="{ disabled: arrowHidden.left }" @click="handleScrollTagViews('left')">
      <i class="el-icon-d-arrow-left" />
    </div>
    <el-scrollbar ref="scrollPane" class="tags-view-wrapper scroll-container" :vertical="false" @wheel.native.prevent="handleScroll">
      <router-link
          v-for="tag in visitedViews"
          ref="tag"
          class="tags-view-item"
          :to="generatorPath(tag)"
          :key="tag.path"
          tag="span"
          custom
          @click.middle.native="closeSelectedTag(tag)"
          @contextmenu.prevent.native="handleOpenContextmenu($event, tag)"
      >
        <span class="tags-view-item-content" :class="{ active: isActive(tag) }">
          {{ langTitle(tag) }}
          <i v-if="isCompactLayout" class="el-icon-more" @click.prevent.stop="handleOpenContextmenu($event, tag)" />
          <i v-else class="el-icon-close" @click.prevent.stop="closeSelectedTag(tag)" />
        </span>
      </router-link>
    </el-scrollbar>
    <div
        v-show="isCompactLayout"
        class="scroll-arrow right"
        :class="{ disabled: arrowHidden.right }"
        @click="handleScrollTagViews('right')"
    >
      <i class="el-icon-d-arrow-right" />
    </div>

    <v-contextmenu ref="contextmenu">
      <v-contextmenu-item @click="closeSelectedTag(selectedTag)">{{ $t('otherLang.close') }}</v-contextmenu-item>
      <v-contextmenu-item @click="closeOthersTags">{{ $t('otherLang.closeOther') }}</v-contextmenu-item>
      <v-contextmenu-item @click="closeAllTags">{{ $t('otherLang.closeAll') }}</v-contextmenu-item>
      <v-contextmenu-item v-if="canSetDefault" @click="setDefaultPage('set')">{{ $t('otherLang.defaultSet') }}</v-contextmenu-item>
      <v-contextmenu-item v-else @click="setDefaultPage('cancel')">{{ $t('otherLang.cancelDefaultSet') }}</v-contextmenu-item>
    </v-contextmenu>
  </div>
</template>

<script>
import _config from '@/config'
import { defaultMenuSave } from '@/api/app'
import { handleScrollFromClick } from '@/views/layout/utils/scroll'
import { formatDynamicFormPath } from '@/views/layout/utils/dynamicFormHelper'
import { findActiveRoute } from '@/utils/routeHelper'

// tagAndTagSpacing
const tagAndTagSpacing = 4
// 主页路由信息
const HOME_PAGE_ROUTE = {
  title: '主页',
  enTitle: 'home',
  path: '/home',
  fullPath: '/home',
  query: {},
  meta: {
    title: '主页',
    enTitle: 'Home',
    icon: 'menu',
    noCache: true,
    isMainRouteMenu: true,
    isBootstrap: true
  }
}

export default {
  data() {
    return {
      top: 0,
      left: 0,
      selectedTag: {},
      // 页签容器
      // 外部容器
      $scrollPane: null,
      // 滚动容器
      $scrollWrapper: null,
      // 页签项
      $tagItems: null,
      // 左右箭头显示
      arrowHidden: { left: true, right: true }
    }
  },
  computed: {
    visitedViews() {
      return this.$store.state.tagsView.visitedViews
    },
    canSetDefault() {
      const defaultMenu = JSON.parse(window.sessionStorage.getItem('defaultMenu'))
      return defaultMenu?.menuId === '' || defaultMenu?.menuId !== this.selectedTag?.meta?.menuId
    },
    isCompactLayout() {
      return this.$store.getters.layoutConfig === 'compact'
    }
  },
  watch: {
    $route: {
      handler(route) {
        this.handleAddTagFromRouteChange(route)
      },
      immediate: true
    }
  },
  created() {
    this.$bus.$on('close-tag', (view, toLatest) => {
      this.closeSelectedTag(view, toLatest)
    })
  },
  mounted() {
    this.$scrollPane = this.$refs.scrollPane.$el
    this.$scrollWrapper = this.$refs.scrollPane.$refs.wrap
    this.initTags()

    this.$bus.$on('close-tag-from-micro', this.closeSelectedTag)
  },
  beforeDestroy() {
    this.$bus.$off('close-tag-from-micro')
  },
  methods: {
    handleScroll(e) {
      const eventDelta = e.wheelDelta || -e.deltaY * 40
      this.$scrollWrapper.scrollLeft = this.$scrollWrapper.scrollLeft - eventDelta / 4
      this.calcScrollArrowHidden()
    },
    moveToTarget(currentTag) {
      const $containerWidth = this.$scrollPane.offsetWidth
      const tagList = this.$refs.tag

      let firstTag = null
      let lastTag = null

      // find first tag and last tag
      if (tagList.length && tagList.length > 0) {
        firstTag = tagList[0]
        lastTag = tagList[tagList.length - 1]
      }

      if (firstTag === currentTag) {
        this.$scrollWrapper.scrollLeft = 0
      } else if (lastTag === currentTag) {
        this.$scrollWrapper.scrollLeft = this.$scrollWrapper.scrollWidth - $containerWidth
      } else {
        // find preTag and nextTag
        const currentIndex = tagList.findIndex(item => item === currentTag)
        const prevTag = tagList[currentIndex - 1]
        const nextTag = tagList[currentIndex + 1]
        // the tag's offsetLeft after of nextTag
        const afterNextTagOffsetLeft = nextTag.$el.offsetLeft + nextTag.$el.offsetWidth + tagAndTagSpacing

        // the tag's offsetLeft before of prevTag
        const beforePrevTagOffsetLeft = prevTag.$el.offsetLeft - tagAndTagSpacing

        if (afterNextTagOffsetLeft > this.$scrollWrapper.scrollLeft + $containerWidth) {
          this.$scrollWrapper.scrollLeft = afterNextTagOffsetLeft - $containerWidth
        } else if (beforePrevTagOffsetLeft < this.$scrollWrapper.scrollLeft) {
          this.$scrollWrapper.scrollLeft = beforePrevTagOffsetLeft
        }
      }
      this.calcScrollArrowHidden()
    },
    // 页签变化是，判断是否需要禁用左右两端的箭头（紧凑式布局）
    calcScrollArrowHidden() {
      // 滚动滑轮时，判断是否到两端
      this.arrowHidden.left = this.$scrollWrapper.scrollLeft === 0
      this.arrowHidden.right = this.$scrollWrapper.scrollWidth - this.$scrollWrapper.offsetWidth <= this.$scrollWrapper.scrollLeft
    },
    // 本地保存标签记录, 防止刷新后消失
    localSave() {
      const len = this.visitedViews.length || 0
      // 当前激活的标签
      const active = this.visitedViews.find(item => item.path === this.$route.path)
      // 需要保留的第二个标签
      if (!active) return
      const secondActive = active?.path === this.visitedViews[len - 1].path ? this.visitedViews[len - 2] : this.visitedViews[len - 1]
      const activeList = active ? [active, secondActive] : [secondActive]
      // 只保存最近两个标签页
      let latest = (len > 2 ? activeList : this.visitedViews).map(({ title, path, query, fullPath, enTitle, meta }) => ({
        title,
        path,
        query,
        fullPath,
        enTitle,
        meta
      }))
      sessionStorage.setItem('visited-views', JSON.stringify(latest))
    },
    isActive(route) {
      return formatDynamicFormPath(route) === this.$route.path
    },
    initTags() {
      let localViews = sessionStorage.getItem('visited-views')
      // 默认添加主页标签
      if (!localViews) {
        localViews = [_.cloneDeep(HOME_PAGE_ROUTE)]
        this.$store.commit('SET_TAGS_VIEWS', localViews)
      } else {
        // 有缓存的tag信息，检查有没有包含主页
        const localViewsObj = JSON.parse(localViews)
        if (!localViewsObj.some(view => view.path === '/home')) {
          localViewsObj.unshift(_.cloneDeep(HOME_PAGE_ROUTE))
        }
        this.$store.commit('SET_TAGS_VIEWS', localViewsObj)
      }
    },
    // 监听动态路由变化，添加动态路由的页签
    handleAddTagFromRouteChange(currentRoute) {
      let activeMenu = findActiveRoute(currentRoute)
      // 找到了路由信息，执行添加页签操作和缓存操作
      activeMenu && this.setCurrentRouteInfo({ ...currentRoute, ...activeMenu })
    },
    setCurrentRouteInfo(route) {
      this.$store.dispatch('addView', route)
      this.moveToCurrentTag(route)
      this.localSave()
    },
    // 紧凑布局下，点击三个点打开菜单
    handleOpenContextmenu(e, tag) {
      if (this.isCompactLayout && e.type === 'contextmenu') return
      this.selectedTag = tag
      this.$refs?.contextmenu.show({ top: e.clientY, left: e.clientX })
    },
    async moveToCurrentTag(route) {
      await this.$nextTick()
      const tags = this.$refs.tag
      const tag = tags.find(item => item.to.path === route.path)
      this.moveToTarget(tag)
    },
    // 动态表单手动替换 :formId 为真实 id
    generatorPath(to) {
      return { path: formatDynamicFormPath(to), query: to.query, fullPath: to.fullPath }
    },
    // 处理点击箭头滚动事件
    async handleScrollTagViews(direction) {
      if (this.arrowHidden[direction]) return
      const tagItems = this.$refs.tag.map(item => item.$el)
      this.arrowHidden = await handleScrollFromClick(this.$scrollWrapper, this.$scrollPane, tagItems, direction)
    },
    closeSelectedTag(view, toLatest) {
      if (view.path === '/home' && this.visitedViews.length === 1) return
      this.$store.dispatch('delView', view).then(({ visitedViews }) => {
        if (this.isActive(view)) {
          if (!toLatest) {
            const latestView = visitedViews.slice(-1)[0]
            if (latestView) {
              this.$router.push(formatDynamicFormPath(latestView))
            } else {
              this.$router.push('/home')
            }
          }
        }
      })
      this.$bus.$emit('close-selected-tag', view)
    },
    async closeOthersTags() {
      if (this.selectedTag.meta.menuId !== this.$store.state.app.menuId) {
        await this.$router.push(this.selectedTag)
      }
      await this.$store.dispatch('delOthersViews', this.selectedTag)
      await this.moveToCurrentTag(this.selectedTag)
      this.$bus.$emit('close-other-tags', this.selectedTag)
    },
    closeAllTags() {
      this.$store.dispatch('delAllViews')
      this.$router.push('/home')
      this.$bus.$emit('close-all-tags')
    },
    // 设为默认页面
    // type: set: 设置、cancel: 取消
    async setDefaultPage(type) {
      const menuId = type === 'set' ? this.selectedTag?.meta?.menuId ?? '' : ''
      let params = {
        params: {
          menuId,
          systemCode: _config.systemCode,
          routePath: this.selectedTag.path
        }
      }
      try {
        const res = await defaultMenuSave(params)
        if (this.reqIsSucceed(res)) {
          if (res.msg) {
            window.sessionStorage.setItem('defaultMenu', JSON.stringify(params.params))
            this.$message.success(res.msg)
          }
        }
      } catch (error) {}
    }
  }
}
</script>

<style lang="scss" scoped>
.scroll-container {
  white-space: nowrap;
  position: relative;
  width: 100%;
  overflow: hidden;

  ::v-deep .el-scrollbar__bar {
    bottom: 0;

    .el-scrollbar__wrap {
      //height: 53px;
    }
  }
}
.tags-view-container {
  display: flex;
  align-items: center;
  width: 100%;
  height: $tag-views-height;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.12), 0 0 3px 0 rgba(0, 0, 0, 0.04);

  &.compact {
    padding-right: 42px;
    height: $tag-views-height;
    background-color: #ffffff;
    box-shadow: 4px 0 10px 0 rgba(62, 72, 128, 0.22);

    .tags-view-wrapper {
      .tags-view-item {
        border-right: 1px solid #eef0f5;

        &:first-of-type {
          margin-left: 0;
        }

        &:last-of-type {
          margin-right: 0;
        }

        .tags-view-item-content {
          margin: 0;
          padding: 0 12px;
          line-height: 32px;
          border-top: none;
          border-radius: 0;

          .el-icon-more {
            padding: 4px;
            transform: rotate(90deg);
            border-radius: 50%;

            &:hover {
              background-color: #b4bccc;
            }
          }
        }
      }
    }
  }

  .scroll-arrow {
    flex: 0 0 30px;
    height: $tag-views-height;
    line-height: $tag-views-height;
    text-align: center;
    cursor: pointer;

    &.left {
      border-right: 1px solid #eef0f5;
    }

    &.right {
      border-left: 1px solid #eef0f5;
    }

    &.disabled {
      cursor: default;
    }

    &:not(.disabled):hover {
      color: var(--color-primary);
    }
  }

  .tags-view-wrapper {
    flex: 1;
    background-color: #FFF;

    .tags-view-item {
      display: inline-block;

      &:not(:first-of-type) {
        border-left: 1px solid $app-main-bg-color;
      }

      .tags-view-item-content {
        display: inline-block;
        height: 32px;
        line-height: 32px;
        padding: 0 8px;
        color: $tag-views-text-color;
        background: #fff;
        font-size: 12px;
        cursor: pointer;

        .el-icon-close:hover {
          background-color: var(--color-primary);
        }

        &.active {
          color: var(--color-primary);
          background-color: var(--color-primary-light-9);
        }

        .el-icon-close {
          width: 14px;
          height: 14px;
          vertical-align: 0;
          border-radius: 50%;
          text-align: center;
          transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
          transform-origin: 100% 50%;
          margin-left: 5px;
          font-size: 14px;
          background-color: $tag-views-close-icon-bg-color;
          color: #fff;

          &::before {
            transform: scale(0.8);
            display: inline-block;
            vertical-align: 0;
          }
        }
      }
    }
  }
}
</style>

<style lang="scss">
.v-contextmenu {
  margin: 0;
  background: #fff;
  z-index: 9999;
  position: absolute;
  list-style-type: none;
  padding: 5px 0;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);

  .v-contextmenu-item {
    margin: 0;
    padding: 7px 16px;

    &.v-contextmenu-item--hover {
      background: var(--color-primary);
    }
  }
}
</style>
