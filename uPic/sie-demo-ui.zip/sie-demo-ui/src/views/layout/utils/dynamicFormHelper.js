export const formatDynamicFormPath = route => {
  let { meta, path } = route
  let formatPath = path
  if (meta?.params && typeof meta?.params === 'string') {
    try {
      const reg = new RegExp('&quot;', 'g')
      let jsonStr = meta.params.replace(reg, '"')
      let paramJson = JSON.parse(jsonStr)
      // 如果是动态表单需要渲染固定组件
      if (paramJson && paramJson.menu_type === 'DYNAMIC_FORM') {
        formatPath = path.replace(':formId', paramJson.diy_code)
        if (paramJson.layout_code) {
          formatPath += `?layoutId=${paramJson.layout_code}`
        }
      }
      return formatPath
    } catch (e) {
      console.log(e)
    }
  }
  return formatPath
}
