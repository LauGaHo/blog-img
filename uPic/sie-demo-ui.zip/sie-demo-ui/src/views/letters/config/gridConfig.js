export default {
  translate: 'letters',
  slotArr: ['messageContent', 'readStatus', 'action'],
  queryUrl: '/iot-message/iotBaseMessageLogController/message-find',
  showIndex: false, // 是否显示序号
  selectable: true, // 表格是否带有复选框
  needSearch: true,
  rowKey: 'msgInstanceId',
  columns: [
    {
      label: '消息内容',
      prop: 'messageContent',
      isShow: true,
      width: 500
    },
    {
      label: '发送时间',
      prop: 'sendTime',
      isShow: true,
      width: 300,
      component: 'el-date-picker',
      componentAttr: {
        type: 'daterange',
        'valueFormat': 'yyyy-MM-dd',
        'range-separator': '',
        'start-placeholder': '开始日期',
        'end-placeholder': '结束日期',
        placeholder: '请选择',
        style: 'width: 100%',
      },
    },
    {
      label: '阅读状态',
      prop: 'readStatus',
      isShow: true,
      hideSearh: false,
      width: 100,
      component: 'el-select',
      list: [
        {
          label: '未读',
          value: 0
        },
        {
          label: '已读',
          value: 1
        },
      ]
    },
    {
      label: '操作',
      prop: 'action',
      isShow: true,
      width: 100,
      fixed: 'right',
      align: 'center'
    },
  ]
}
