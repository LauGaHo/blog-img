<template>
  <el-card>
    <el-container>
      <el-header class="header-warp" style="height: auto">
        <h3 class="inbox">收件箱</h3>
        <span>
          ({{ unread }}条未读, <span class="messageTip" @click="messageChange">{{ messageTip }}</span
          >)
        </span>
      </el-header>
      <el-main class="main-warp">
        <customize-table
          class="table-warp"
          ref="table"
          :tableHeight="tableHeight"
          :grid-config="gridConfig"
          :query-params="queryParams"
          :fixed-params="fixedParams"
          @selection-change="selectionChange"
        >
          <!-- 表格头部按钮 -->
          <template v-slot:btn>
            <el-button icon="el-icon-delete" type="danger" size="small" :disabled="selection.length === 0" @click="msgDel()"
              >删除</el-button
            >
            <el-button type="primary" size="small" :disabled="unreadSelected.length === 0" @click="markAsRead('select')"
              >标为已读
            </el-button>
            <el-button type="primary" size="small" @click="markAsRead('all')">全部标为已读</el-button>
          </template>
          <!-- 消息内容 -->
          <template v-slot:messageContent="{ scope }">
            <div v-html="scope.row.messageContent"></div>
          </template>
          <!-- 阅读状态 -->
          <template v-slot:readStatus="{ scope }">
            <span :style="{ color: scope.row.readStatus ? 'green' : 'red' }">
              {{ scope.row.readStatus ? $t('letters.read') : $t('letters.unRead') }}
            </span>
          </template>
          <!-- 操作 -->
          <template v-slot:action="{ scope }">
            <el-link class="handle-btn" type="danger" :underline="false" @click="msgDel(scope.row.msgInstanceId)">{{
              $t('letters.delete')
            }}</el-link>
          </template>
        </customize-table>
      </el-main>
    </el-container>
  </el-card>
</template>

<script>
// vuex
import { mapGetters } from 'vuex'
// 表格配置
import gridConfig from './config/gridConfig'
// api
import { messageDelete, messageRead } from '@/api/letters'

export default {
  name: 'letters',
  computed: {
    ...mapGetters(['unread', 'appMainHeight']),
    tableHeight() {
      return this.appMainHeight - 68
    },
    // 消息提示
    messageTip() {
      return this.messageType === 0 ? '查看全部消息' : '仅查看未读消息'
    },
    /**
     * @description: 多选数据中未读状态的数据（标为已读按钮是否展示）
     * @return {Array<T>} 表格过滤后字段
     */
    unreadSelected() {
      return this.selection.filter(e => !e.readStatus)
    }
  },
  data() {
    return {
      // 表格配置
      gridConfig,
      /**
       * 消息类型
       * undefined 查询全部消息
       * 0 查询未读消息
       * 1 查询已读消息
       */
      messageType: undefined,
      // 表格请求参数
      queryParams: {
        params: {
          params: {
            systemCodes: [window._config.systemCode]
          },
          queryUrl: '/iot-message/iotBaseMessageLogController/message-find'
        }
      },
      // 表格固定参数
      fixedParams: {
        systemCodes: [window._config.systemCode]
      },
      // 表格复选数据
      selection: []
    }
  },
  methods: {
    /**
     * @description: 标为已读/全部标为已读
     * @param {String} type 按钮类型分为all/select
     */
    markAsRead(type) {
      let params = {
        systemCodes: [window._config.systemCode]
      }

      if (type === 'select') {
        params = {
          ...params,
          msgInstanceIds: this.selection.map(e => e.msgInstanceId)
        }
      }

      this.$confirm(`确认把所${type === 'all' ? '有' : '选'}消息标记为已读吗？`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        /**
         * @description: 关闭前的回调
         * @param {String} action 点击按钮类型
         * @param {Object} instance MessageBox实例
         * @param {Function} done 关闭函数
         */
        beforeClose: (action, instance, done) => {
          if (action === 'confirm') {
            instance.confirmButtonLoading = true
            // 调用标记已读接口
            messageRead({ params })
              .then(res => {
                instance.confirmButtonLoading = false
                if (this.reqIsSucceed(res)) {
                  this.$message.success(res.msg)
                  done()
                  // 通知铃铛和本页面更新数据
                  this.$bus.$emit('update-station-message')
                }
              })
              .catch(() => {
                instance.confirmButtonLoading = false
              })
          } else {
            done()
          }
        }
      })
    },
    /**
     * @description: 获取复选数据
     * @param {Array<Object>} selection
     */
    selectionChange(selection) {
      this.selection = selection
    },

    /**
     * @description: 站内消息删除
     * @param {String} id 需要删除的行id 如果没有判断为批量删除
     */
    msgDel(id) {
      // 批量删除没有选中数据时直接跳出
      if (!id && !this.selection.length) return

      const params = {
        msgInstanceIds: id ? [id] : this.selection.map(e => e.msgInstanceId)
      }

      this.$confirm('确认删除消息记录？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        /**
         * @description: 关闭前的回调
         * @param {String} action 点击按钮类型
         * @param {Object} instance MessageBox实例
         * @param {Function} done 关闭函数
         */
        beforeClose: (action, instance, done) => {
          if (action === 'confirm') {
            instance.confirmButtonLoading = true
            // 调用删除接口
            messageDelete({ params })
              .then(res => {
                instance.confirmButtonLoading = false
                if (this.reqIsSucceed(res)) {
                  this.$message.success(res.msg)
                  done()
                  // 通知铃铛和本页面更新数据
                  this.$bus.$emit('update-station-message')
                }
              })
              .catch(() => {
                instance.confirmButtonLoading = false
              })
          } else {
            done()
          }
        }
      })
    },
    // 切换消息表格类型
    messageChange() {
      const {
        messageType,
        $refs: {
          table: { loading, init }
        }
      } = this

      // 表格数据请求完成后才能继续请求
      if (!loading) {
        this.messageType = messageType === undefined ? 0 : undefined

        this.gridConfig.columns = this.gridConfig.columns.map(e => {
          const readStatus = e.prop === 'readStatus' && this.messageType === 0
          return {
            ...e,
            isShow: !readStatus
          }
        })

        // 在切换消息类型时需要控制fixedParams中的readStatus
        if (messageType === undefined) {
          this.fixedParams = {
            systemCodes: [window._config.systemCode],
            readStatus: 0
          }
        } else {
          this.fixedParams = { systemCodes: [window._config.systemCode] }
        }

        this.$refs.table.needSearch = false

        init(false)

        this.getMessageData(false)
      }
    },
    /**
     * @description: 请求消息列表
     * @param {Boolean} noNeedTotal 是否需要请求未读消息数量
     */
    getMessageData(noNeedTotal = true) {
      // 重置数据
      const {
        $refs: { table },
        tableData
      } = this.$refs.table

      this.queryParams = {
        params: {
          params: {
            readStatus: this.messageType,
            systemCodes: [window._config.systemCode]
          }
        },
        queryUrl: '/iot-message/iotBaseMessageLogController/message-find'
      }

      this.$nextTick(() => {
        this.$refs.table.outSearch()

        // 是否需要请求未读消息数量
        if (noNeedTotal) {
          this.$store.dispatch('GetUnreadTotal')
        }

        if (tableData.length > 0) {
          table.clearSelection()
        }
      })
    }
  },

  created() {
    /**
     * bus监听是否需要更新站内消息
     * 点击marked函数触发或者由'letters'页面触发更新
     */
    this.$bus.$on('update-station-message', () => {
      // 节流
      const { loading } = this.$refs.table
      if (!loading) {
        this.getMessageData()
      }
    })
  },

  mounted() {
    this.$refs.table.init(false)
    this.getMessageData()
  }
}
</script>
<style lang="scss" scoped>
.inbox {
  display: inline-block;
  font-weight: 500;
}

.messageTip {
  color: var(--color-primary);
  cursor: pointer;
}
.main-warp {
  padding-top: 0;
}
</style>
