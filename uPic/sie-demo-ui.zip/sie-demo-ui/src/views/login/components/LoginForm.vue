<template>
  <div class="loginWrap">
    <div v-if="!isReset">
      <div class="login-txt-block">
        <div class="login-txt">{{ loginTitle || $t('login.login') }}</div>
      </div>
      <div class="el-input-block">
        <el-form
          label-position="top"
          label-width="80px"
          ref="loginForm"
          @submit.native.prevent
          :model="form"
          :rules="rules"
          @keydown.enter.native="handleSubmit"
          autocomplete="off"
        >
          <el-form-item label class="login-form-item" prop="userName">
            <el-input
              v-model.trim="form.userName"
              clearable
              @blur="blurCheckCaptcha"
              @focus="handleInputFocus"
              :placeholder="$t('login.enterNum')"
            >
              <i slot="prefix" class="iconfont1 icon-zhanghao"></i>
            </el-input>
          </el-form-item>
          <el-form-item label class="login-form-item" prop="password">
            <el-input
              type="password"
              v-model.trim="form.password"
              @blur="handleInputBlur"
              @focus="handleInputFocus"
              :placeholder="$t('login.enterPwd')"
            >
              <i slot="prefix" class="iconfont1 icon-mima"></i>
            </el-input>
          </el-form-item>
          <el-form-item label v-if="checkCaptcha" class="login-form-item" prop="captcha">
            <el-input v-model.trim="form.captcha" :placeholder="$t('login.verificationCode')">
              <i slot="prefix" class="iconfont1 icon-yanzhengma"></i>
            </el-input>
            <div class="form-item-icode">
              <img :src="identifyCode" alt style="height: 35px; width: 100px" @click="getCaptcha(form.userName)" />
            </div>
          </el-form-item>
        </el-form>
      </div>
      <div class="btn-block">
        <el-button class="btn-login" @click="handleSubmit" :loading="loading">{{ $t('login.login') }}</el-button>
      </div>
      <div class="forgot-pwd-block">
        <el-switch
          class="lang-switch"
          v-model="lang"
          inactive-text="中文"
          @change="switchLang"
          active-text="English"
          inactive-color="#626785"
        >
        </el-switch>
        <div class="form-item-codeimg">
          <a target="_self" class="codeimg-txt" @click="toCodeImgUrl()">{{ $t('login.codeImgLogin') }}</a>
        </div>
        <div class="form-item-forgot" @click="isReset = true">
          <span class="forgot-pwd-txt">{{ $t('login.forgetPwd') }}?</span>
        </div>
      </div>
    </div>
    <reset-password v-else @getIsReset="getIsReset" />
  </div>
</template>
<script>
import axios from 'axios'
import { getToken, getUserInfo, getLanguage } from '@/utils/auth'
import httpUtil from '@/utils/request'
import ResetPassword from '@/views/login/components/ResetPassword'

export default {
  name: 'LoginForm',
  components: { ResetPassword },
  props: {
    userNameRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '账号不能为空', trigger: 'blur' }]
      }
    },
    loading: {
      type: Boolean,
      default: false
    },
    passwordRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '密码不能为空', trigger: 'blur' }]
      }
    },
    loginTitle: {
      type: String,
      default: ' 欢迎登录登录赛意谷神平台!  '
    },
    systemLogo: {
      type: String,
      default: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/images/logo3.png'
    }
  },
  data() {
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter your password'))
      } else {
        if (this.registForm.passwdCheck !== '') {
          // 对第二个密码框单独验证
          this.$refs.registForm.validateField('passwdCheck')
        }
        callback()
      }
    }
    const validatePassCheck = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.registForm.loginPassword) {
        callback(new Error('两次密码输入不一致!'))
      } else {
        callback()
      }
    }
    return {
      isReset: false,
      lang: getLanguage() === 'en-us',
      form: {
        userName: '',
        password: '',
        userType: '86',
        captcha: ''
      },
      verificationCode: null,
      identifyCode: false,
      registForm: {
        loginAccount: '',
        loginPassword: '',
        loginPasswordCheck: '',
        mobile: '',
        userName: '',
        namePingyin: '',
        nameSimplePinyin: '',
        orderNo: ''
      },
      registFormRules: {
        loginPassword: [{ validator: validatePass, trigger: 'blur' }],
        loginPasswordCheck: [{ validator: validatePassCheck, trigger: 'blur' }]
      },
      checkCaptcha: false
    }
  },
  computed: {
    rules() {
      return {
        userName: this.userNameRules,
        password: this.passwordRules,
        captcha: [{ required: true, message: '验证码不能为空', trigger: 'blur' }]
      }
    },
    logoUrl() {
      return this.systemLogo || 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/images/logo.png'
    },
    title() {
      return this.loginTitle || this.$t('login.welcome')
    }
  },
  methods: {
    handleInputBlur() {
      // input失去焦点时，恢复显示备案号
      this.$emit('handleInputBlur')
    },
    handleInputFocus() {
      // input获得焦点时，隐藏显示备案号，解决输入时虚拟键盘顶起备案号问题
      this.$emit('handleInputFocus')
    },
    switchLang(isEn) {
      if (isEn) this.$i18n.locale = 'en-us'
      else this.$i18n.locale = 'zh-cn'

      this.$store.commit('SET_LANG', this.$i18n.locale)
    },
    getIsReset(e) {
      this.isReset = e
    },
    doRegist() {
      // http://47.107.171.33:9021/base-user/register?loginAccount=lt&loginPassword=123&mobile=17620861029&userName=李涛&namePingyin=litao&nameSimplePinyin=lt&orderNo=1
      this.$refs['registForm'].validate(valid => {
        if (valid) {
          httpUtil.post('api/base/base-user/register', this.registForm).then(res => {
            if (res.code !== 800) this.$message.error(res.msg)
            else this.$message.success(res.msg)
          })
        }
      })
    },
    async handleSubmit() {
      this.$refs.loginForm.validate(valid => {
        if (valid) this.preCaptcha()
      })
    },
    async preCaptcha() {
      if (this.checkCaptcha) {
        this.$emit('on-success-valid', {
          userName: this.form.userName,
          password: this.form.password,
          captcha: this.form.captcha
        })
        return false
      }
      const res = await httpUtil.get(`/api/base/base-user/pre-captcha?phone=${this.form.userName}`)
      if (res.data) {
        this.checkCaptcha = true
        this.getCaptcha(this.form.userName)
      } else {
        this.$emit('on-success-valid', {
          userName: this.form.userName,
          password: this.form.password,
          captcha: this.form.captcha
        })
      }
    },
    async blurCheckCaptcha() {
      this.handleInputBlur()
      const res = await httpUtil.get(`/api/base/base-user/pre-captcha?phone=${this.form.userName}`)
      this.checkCaptcha = res.data
      if (res.data) this.getCaptcha(this.form.userName)
    },
    getCaptcha(phone) {
      this.identifyCode = `${window.VUE_APP_SERVERAPI}api/base/base-pa/imageCaptcha?phone=${phone}&${Math.random()}`
    },
    toCodeImgUrl() {
      let tenantId = '-999'
      httpUtil.get(`/api/base/auth-wx-login/wxcp-info?tenantId=${tenantId}`).then(res => {
        let appid = res.data.clientId || ''
        let agentid = res.data.agentId || ''
        let redirect_uri = res.data.redirectUri || ''
        window.location.href = `https://open.work.weixin.qq.com/wwopen/sso/qrConnect?appid=${appid}&agentid=${agentid}&redirect_uri=${redirect_uri}&state=${appid}`
      })
    }
  },
  mounted() {
    let userInfo = getUserInfo()
    if (userInfo) {
      this.form.userName = userInfo.loginAccount
      this.form.password = userInfo.password
    }
  }
}
</script>
<style lang="scss" scoped>
.loginWrap {
  .login-txt-block {
    margin: 0px 0px 8px;
    .login-txt {
      text-align: center;
      font-size: 26px;
      color: rgb(38, 49, 66);
    }
  }
  .el-input-block {
    margin-top: 30px;
    .el-form {
      ::v-deep .el-form-item {
        .el-form-item__content {
          line-height: 42px;
          .el-input {
            .el-input__inner {
              height: 42px;
              line-height: 42px;
            }
            .el-input__prefix {
              .iconfont1 {
                font-size: 20px;
              }
            }
          }
          .form-item-forgot {
            position: absolute;
            right: 4px;
            top: 12px;
            font-size: 12px;
            color: rgb(95, 122, 184);
            line-height: 18px;
            cursor: pointer;
          }
          .form-item-icode {
            position: absolute;
            right: 0;
            top: -2px;
          }
        }
      }
      .el-form-item.is-required:not(.is-no-asterisk) > .el-form-item__label:before,
      .el-form-item.is-required:not(.is-no-asterisk) .el-form-item__label-wrap > .el-form-item__label:before {
        content: '';
        color: #fff;
        margin-right: 0px;
      }
    }
  }
  .btn-block {
    margin: 20px 0 10px;
    .btn-login {
      width: 100%;
      font-size: 16px;
      color: rgb(255, 255, 255);
      height: 42px;
      text-align: center;
      background-image: linear-gradient(90deg, var(--color-primary-light-1) 1%, var(--color-primary-light-3));
      border-radius: 6px;
      box-shadow: rgba(79, 139, 243, 0.3) 0px 4px 10px 0px;
      cursor: pointer;
      border-width: initial;
      border-style: none;
      border-color: initial;
      border-image: initial;
      outline: none;
      text-decoration: none;
      margin: 0;
      &:hover {
        background-color: #3c71ef;
      }
    }
  }
  .forgot-pwd-block {
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
    ::v-deep .el-switch {
      .el-switch__label {
        width: inherit !important;
      }
      .el-switch__core {
        margin: 0 5px;
      }
    }
    .forgot-pwd-txt {
      font-size: 12px;
      color: #576370;
      line-height: 18px;
      cursor: pointer;
      &:hover {
        color: #085ebb;
      }
    }
    .codeimg-txt {
      font-size: 12px;
      color: #576370;
      line-height: 18px;
      cursor: pointer;
      &:hover {
        color: #085ebb;
      }
    }
  }
}
</style>
