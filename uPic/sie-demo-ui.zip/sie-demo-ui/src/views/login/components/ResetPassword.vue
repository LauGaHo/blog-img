<template>
  <div class="reset-container">
    <div class="el-input-block">
      <el-form label-position="top" label-width="80px" :model="resetData" :rules="resetRules" ref="resetForm">
        <el-form-item label class="login-form-item" prop="toPhone">
          <el-input v-model.trim="resetData.toPhone" :placeholder="$t('login.enterNum')">
            <i slot="prefix" class="iconfont1 icon-zhanghao"></i>
          </el-input>
        </el-form-item>
        <el-form-item label class="login-form-item" prop="smsVerifyCode">
          <el-input v-model.trim="resetData.smsVerifyCode" :placeholder="$t('login.verificationCode')">
            <i slot="prefix" class="iconfont1 icon-yanzhengma"></i>
          </el-input>
          <div class="form-item-forgot" @click="showCaptcha" :disabled="!allowSendMsg">
            <span class="forgot-pwd-txt">{{ !allowSendMsg ? counter + '秒后可再次发送' : $t('login.sendCode') }}</span>
          </div>
        </el-form-item>
        <el-form-item label class="login-form-item" prop="newMagic">
          <el-input type="password" v-model.trim="resetData.newMagic" clearable :placeholder="$t('login.newPwd')">
            <i slot="prefix" class="iconfont1 icon-mima"></i>
          </el-input>
        </el-form-item>
        <el-form-item label class="login-form-item" prop="confirmMagic">
          <el-input type="password" v-model.trim="resetData.confirmMagic" :placeholder="$t('login.confirmPassword')" clearable>
            <i slot="prefix" class="iconfont1 icon-mima"></i>
          </el-input>
        </el-form-item>
      </el-form>
    </div>
    <div class="btn-block">
      <el-button class="btn-login" @click="handleReset" :loading="loading">{{ $t('button.submit') }}</el-button>
    </div>
    <div class="forgot-pwd-block">
      <div></div>
      <span class="forgot-pwd-txt" @click="$emit('getIsReset', false)">{{ $t('login.directLogin') }}</span>
    </div>

    <!-- 验证码 -->
    <el-dialog :visible.sync="dialogFormVisible" title="请填写验证码" class="captcha-form" width="30%">
      <div class="img-container">
        <img :src="identifyCode" style="height: 40px; width: 100px" alt />
        <span class="fresh-btn" @click="refreshCode">看不清，换一张</span>
      </div>
      <el-form :model="resetData" label-position="left" :rules="rules" ref="captchaForm">
        <el-form-item prop="captcha" label="验证码：">
          <el-input type="text" v-model="resetData.captcha"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="medium" plain @click.native.prevent="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" size="medium" plain @click.native.prevent="sendMsg">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { encode } from '@/utils/base64'
import { validatePhone } from '@/utils/validate'
import { resetPassword, sendCode } from '@/api/reset-password'

export default {
  name: 'ResetPassword',
  data() {
    const validateIsPhone = (rule, value, callback) => {
      if (!value) 
        callback(new Error('手机号不能为空'))
      else if (!validatePhone(value)) 
        callback(new Error('请输入正确的手机号'))
      else 
        callback()
      
    }
    const validatePwd = (rule, value, callback) => {
      let reg = /^(\w){6,12}$/i
      if (!reg.test(value)) 
        callback(new Error('密码必须由6-12位数字或者字母组成，区分大小写'))
      else 
        callback()
      
    }
    const validatePwdEqual = (rule, value, callback) => {
      if (value && value !== this.resetData.newMagic) 
        callback(new Error('两次密码不一致'))
      else 
        callback()
      
    }
    const validateVerifyCode = (rule, value, callback) => {
      if (!this.isVerified) 
        callback(new Error('验证码输入不正确'))
      else if (!value) 
        callback(new Error('验证码不能为空'))
      else 
        callback()
      
    }
    const validateCaptcha = (rule, value, callback) => {
      if (!value) 
        callback(new Error('验证码不能为空'))
      else if (value && !this.captchaMatch) 
        callback(new Error('验证码输入不正确'))
      else 
        callback()
      
    }
    return {
      isVerified: true,
      resetRules: {
        toPhone: [{ required: true, trigger: 'blur', validator: validateIsPhone }],
        newMagic: [{ required: true, trigger: 'blur', validator: validatePwd }],
        confirmMagic: [{ required: true, trigger: 'blur', validator: validatePwdEqual }],
        smsVerifyCode: [{ required: true, trigger: 'blur', validator: validateVerifyCode }]
      },
      rules: {
        captcha: [{ required: true, trigger: 'blur', validator: validateCaptcha }]
      },
      resetData: {
        toPhone: '',
        smsVerifyCode: '',
        newMagic: '',
        confirmMagic: '',
        captcha: ''
      },
      msgData: {
        toPhone: '',
        eventType: null,
        captcha: ''
      },
      loading: false,
      sending: false,
      allowSendMsg: true,
      counter: 60,
      pwdType: 'password',
      pwdType2: 'password',
      captchaMatch: true,
      dialogFormVisible: false,
      identifyCode: ''
    }
  },
  methods: {
    showPwd() {
      if (this.pwdType === 'password') 
        this.pwdType = ''
      else 
        this.pwdType = 'password'
      
    },
    showPwd2() {
      if (this.pwdType2 === 'password') 
        this.pwdType2 = ''
      else 
        this.pwdType2 = 'password'
      
    },
    sendMsg() {
      if (!this.resetData.captcha) {
        this.$message({
          message: '请先填写验证码',
          type: 'warning'
        })
        return
      }
      let data = {
        phone: this.resetData.toPhone,
        type: 2, // 发送类型 1:注册；2：通过手机号码找回密码
        imageCaptcha: this.resetData.captcha
      }
      this.sending = true
      sendCode(data).then(res => {
        this.sending = false
        if (this.reqIsSucceed(res)) {
          this.$message.success(res.msg)
          this.allowSendMsg = false
          this.dialogFormVisible = false
          let setCounter = setInterval(() => {
            this.counter--
            if (this.counter === 0) {
              clearInterval(setCounter)
              this.allowSendMsg = true
              this.counter = 60
              return
            }
          }, 1000)
        }
      })
    },
    handleReset() {
      let tempData = Object.assign({}, this.resetData)
      // delete tempData.password2
      delete tempData.captcha
      let data = {
        phone: tempData.toPhone,
        numberCaptcha: tempData.smsVerifyCode,
        newMagic: encode(tempData.newMagic),
        confirmMagic: encode(tempData.confirmMagic)
      }
      this.$refs.resetForm.validate(valid => {
        if (valid) {
          this.loading = true
          resetPassword(data)
            .then(res => {
              this.loading = false
              //console.log(res);
              if (this.reqIsSucceed(res)) {
                this.$notify({
                  title: '成功',
                  message: '密码更新成功,即将跳转到登录页',
                  type: 'success',
                  duration: '3000'
                })
                setTimeout(() => {
                  this.loading = false
                  location.reload()
                  //this.$router.push({ path: '/login' });
                }, 1000)
              }
            })
            .catch(() => {
              this.loading = false
            })
        }
      })
    },
    getCaptcha() {
      // createCaptcha(this.resetData.toPhone).then(res => {
      //     this.identifyCode = "data:image/png;base64," + res.data
      // })
      this.identifyCode = `${window.VUE_APP_SERVERAPI}api/base/base-pa/imageCaptcha?phone=${this.resetData.toPhone}&${Math.random()}`
    },
    refreshCode() {
      this.identifyCode = ''
      this.getCaptcha()
    },
    showCaptcha() {
      if (!validatePhone(this.resetData.toPhone)) {
        this.$message({
          message: '请先填写正确手机号',
          type: 'warning'
        })
        return
      }
      if (!this.allowSendMsg) 
        return
      
      this.resetData.captcha = ''
      this.dialogFormVisible = true
      this.getCaptcha(this.resetData.toPhone)
    }
  }
}
</script>
<style lang="scss" scoped>
.el-input-block {
  margin-top: 30px;
  .el-form {
    ::v-deep .el-form-item {
      .el-form-item__content {
        line-height: 42px;
        .el-input {
          .el-input__inner {
            height: 42px;
            line-height: 42px;
          }
          .el-input__prefix {
            .iconfont1 {
              font-size: 20px;
            }
          }
        }
        .form-item-forgot {
          position: absolute;
          right: 4px;
          top: 12px;
          font-size: 12px;
          color: rgb(95, 122, 184);
          line-height: 18px;
          cursor: pointer;
        }
      }
    }
  }
}

.btn-block {
  margin: 20px 0 10px;
  .btn-login {
    width: 100%;
    font-size: 16px;
    color: rgb(255, 255, 255);
    height: 42px;
    text-align: center;
    background-image: linear-gradient(90deg, #3c7fff 1%, #16b6ff 98%);
    border-radius: 6px;
    box-shadow: rgba(79, 139, 243, 0.3) 0px 4px 10px 0px;
    cursor: pointer;
    border-width: initial;
    border-style: none;
    border-color: initial;
    border-image: initial;
    outline: none;
    text-decoration: none;
    margin: 0;
    &:hover {
      background-color: #3c71ef;
    }
  }
}
.forgot-pwd-block {
  display: flex;
  -webkit-box-pack: justify;
  justify-content: space-between;
  .forgot-pwd-txt {
    font-size: 12px;
    color: #576370;
    line-height: 18px;
    cursor: pointer;
    &:hover {
      color: #085ebb;
    }
  }
}

.captcha-form {
  .fresh-btn {
    font-size: 12px;
    color: #5f7ab8;
    cursor: pointer;
  }
}
</style>
