<template>
  <div class="bg">
    <el-card class="card">
      <div class="flex">
        <div class="flex-14">
          <div class="welcome"></div>
        </div>
        <div :span="1">
          <div class="form-line">
            <div></div>
          </div>
        </div>
        <el-col class="flex-10">
          <div class="right">
            <div class="content">
              <div class="logo">
                <span class="line"></span>
                <img
                  :src="logoUri"
                  alt="gushen-demo logo"
                />
                <span class="line"></span>
              </div>
              <div class="form-container">
                <el-form
                  class="login-form"
                  autocomplete="on"
                  :model="loginForm"
                  :rules="loginRules"
                  ref="loginForm"
                  label-position="left"
                >
                  <el-form-item prop="account">
                    <el-input
                      name="account"
                      type="text"
                      v-model="loginForm.account"
                      autocomplete="on"
                      placeholder="请输入手机号码"
                      @keyup.enter="handleLogin"
                    >
                      <i
                        slot="suffix"
                        class="el-icon-mobile-phone"
                      ></i>
                    </el-input>
                  </el-form-item>
                  <el-form-item prop="password">
                    <el-input
                      name="password"
                      type="password"
                      v-model="loginForm.password"
                      autocomplete="on"
                      @keyup.enter.native="handleLogin"
                      placeholder="请输入密码"
                    >
                      <i
                        slot="suffix"
                        class="el-icon-lock"
                      ></i>
                    </el-input>
                  </el-form-item>
                </el-form>
                <div class="submit">
                  <el-button
                    type="primary"
                    :plain="false"
                    :loading="loading"
                    @click.native.prevent="handleLogin"
                  >登 录</el-button>
                </div>
              </div>
            </div>
          </div>
        </el-col>
      </div>
    </el-card>
  </div>
</template>

<script>
import { validatePhone, validateEmail } from '@/utils/validate'
import { getToken } from '@/utils/auth'
import { Base64 } from 'js-base64'
import logo from '@/assets/png/logo.png'
import { getsystemwatermark } from '@/api/system-manage/menu'
import Watermark from '@/utils/watermark'

export default {
  name: 'login',
  data() {
    const validateAccount = (rule, value, callback) => {
      let isNumber = /^[0-9]*$/
      if (isNumber.test(value)) {
        if (!validatePhone(value)) {
          callback(new Error('请输入正确的用户名'))
        } else {
          callback()
        }
      } else {
        if (!validateEmail(value)) {
          callback(new Error('请输入正确的邮箱'))
        } else {
          callback()
        }
      }
    }
    const validatePass = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error('密码不能小于6位'))
      } else {
        callback()
      }
    }
    return {
      loginForm: {
        account: '',
        password: '',
        systemCode: _config.systemCode
      },
      loginRules: {
        account: [{ required: true, message: '账号不能为空', trigger: 'blur' }],
        password: [{ required: true, trigger: 'blur', validator: validatePass }]
      },
      loading: false,
      novalid: false
    }
  },
  computed: {
    logoUri() {
      let setting = this.$store.state.app.systemSetting
      let uri = logo
      if (setting) {
        uri = JSON.parse(setting).systemLogo
      }
      return uri
    }
  },
  created() {},
  mounted() {
    //this.$store.dispatch('SetSystemSetting');
  },
  methods: {
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          let c = this.loginForm.password
          this.$store
            .dispatch('Login', this.loginForm)
            .then(res => {
              if (res.code === 800) {
                if (res.data.userHeadImgUrl === 'defaultImgUrl') {
                  this.$store.commit('setUserHeadImgUrl', '')
                } else {
                  this.$store.commit('setUserHeadImgUrl', res.data.userHeadImgUrl)
                }
                // 设置水印
                // this.getsystemwatermark(res.data.tenantId)
                const token = getToken()
                this.$store
                  .dispatch('AutoLogin', {
                    token,
                    systemCode: _config.systemCode,
                    ps: Base64.encode(c)
                  })
                  .then(() => {
                    sessionStorage.removeItem('visited-views')
                    this.$router.push({ path: '/home' })
                    // 有时后端返回登录成功结果后页面也不会自动跳转
                    window.setTimeout(() => {
                      // 如果还在登录页
                      if (/\/login/.test(window.location.pathname)) {
                        window.location.pathname = '/home'
                      }
                    }, 2000)
                  })
              } else {
                this.loading = false
                this.$message.error(res.msg)
              }
            })
            .catch(() => {
              this.loading = false
              this.$message.error('登录失败!')
            })
        } else {
          this.$message.warning('用户信息未正确填写')
          console.log('登录出错!')
          return false
        }
      })
    },
    //获取系统水印
    getsystemwatermark(tenantId) {
      getsystemwatermark(_config.systemCode, '', tenantId).then(res => {
        if (this.reqIsSucceed(res)) {
          if (res.data) {
            window.localStorage.setItem('watermarkBean', JSON.stringify(res.data))
            Watermark.set()
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.bg {
  width: 100%;
  height: 100%;
  background: url('../../assets/images/bg.jpg') no-repeat center;
  background-size: cover;
  display: flex;
  justify-content: center;
  align-items: center;
  .card {
    width: 850px;
    height: 380px;
    border-radius: 20px;
    .flex {
      display: flex;
      height: 100%;
      .flex-14 {
        flex: 14;
      }
      .flex-10 {
        flex: 10;
      }
    }
  }
  .welcome {
    width: 100%;
    height: 340px;
    background: url('../../assets/images/login-form.jpg') no-repeat center;
    background-size: cover;
  }
  .form-line {
    width: 43px;
    height: 340px;
    display: flex;
    justify-content: center;
    align-items: center;
    > div {
      height: 170px;
      border-right: 3px solid #268ef8;
    }
  }
  .right {
    display: flex;
    align-items: center;
    height: 340px;
  }
  .logo {
    padding: 0 0 40px;
    text-align: center;
    .line {
      width: 50px;
      height: 1px;
      display: inline-block;
      border-bottom: 1px solid #eef0f6;
      transform: translateY(-1px);
    }
    img {
      width: 150px;
      height: 24px;
      margin: 0 10px;
    }
  }
  .form-container {
    text-align: center;
    ::v-deep .login-form {
      .el-form-item__content {
        width: 100%;
        input {
          background-color: white;
          border-top: none;
          border-left: none;
          border-right: none;
          border-radius: 0;
        }
      }
    }
    .submit {
      width: 320px;
      .el-button {
        width: 240px;
        height: 40px;
        background: linear-gradient(270deg, rgba(24, 135, 249, 1), rgba(86, 164, 245, 1));
        border-radius: 40px;
      }
    }
  }
}
</style>
