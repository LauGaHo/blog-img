<template>
  <div class="wrapper">
    <el-form :label-width="$i18n.locale === 'zh-cn' ? '100px' : '140px'" ref="formData" :model="info">
      <el-form-item :label="$t('person.staffNo')">
        <el-input v-model="info.employeeNumber" disabled />
      </el-form-item>
      <el-form-item :label="$t('person.name')">
        <el-input v-model="info.tenantName" disabled />
      </el-form-item>
      <el-form-item :label="$t('person.mobile')">
        <el-input v-model="info.mobile" maxlength="11" disabled />
      </el-form-item>
      <el-form-item :label="$t('person.email')">
        <el-input v-model="info.mail" disabled />
      </el-form-item>
      <el-form-item :label="$t('person.depName')">
        <el-input v-model="info.depName" disabled />
      </el-form-item>
      <el-form-item :label="$t('person.avatar')">
        <UploadImg ref="uploadForm" :upload-limit="1" :data-list="uploadList" />
      </el-form-item>
      <el-form-item style="text-align: center">
        <el-button type="primary" size="small" icon="el-icon-circle-check" @click="updateAvatar">
          {{ $t('button.submit') }}
        </el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
import { updateAvatar } from '@/api/personalInformation'

export default {
  props: {
    info: {
      type: Object
    }
  },
  data() {
    return {
      uploadList: [{ url: localStorage.getItem('userHeadImgUrl') }]
    }
  },
  mounted() {
    console.log(123123, this.uploadList)
  },
  methods: {
    updateAvatar() {
      if (this.uploadList.length > 0) {
        const url = this.uploadList[0].url
        const fileId = this.uploadList[0].fileId
        if (!fileId) {
          this.$message.warning(this.$t('person.noUpdate'))
          return
        }
        updateAvatar(url, fileId).then(res => {
          if (this.reqIsSucceed(res)) {
            this.$message.success(this.$t('toast.updateSuccess'))
            this.$store.commit('setUserHeadImgUrl', url)
            // location.reload();
          }
        })
      } else {
        this.$message.info(this.$t('person.noUpdate'))
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.wrapper {
  width: 50%;
  ::v-deep .el-upload {
    width: inherit;
    height: inherit;
    display: inline-block;
    text-align: center;
    cursor: pointer;
    outline: none;
    border: none;
  }
  ::v-deep .demo-upload-list {
    box-shadow: none;
  }
}
</style>
