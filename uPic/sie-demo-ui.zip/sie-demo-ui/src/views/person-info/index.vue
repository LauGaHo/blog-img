<template>
  <el-card>
    <el-tabs v-model="activeName">
      <el-tab-pane :label="$t('person.personInfo')" name="first">
        <information ref="info" :info="userInfo"></information>
      </el-tab-pane>
    </el-tabs>
  </el-card>
</template>
<script>
import information from './components/information';
import { getUserInfo } from '@/utils/auth';

export default {
  name: 'PersonInfo',
  components: { information },
  data() {
    return {
      activeName: 'first',
    };
  },
  computed: {
    userInfo() {
      return getUserInfo();
    },
  }
};
</script>