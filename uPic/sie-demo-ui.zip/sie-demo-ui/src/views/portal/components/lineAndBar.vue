<template>
  <div :style="{ height: height, width: width }"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'
import vue from 'vue'
import { deepClone } from '@/utils'
export default {
  props: {
    assetData: {
      type: Array,
      defautl: () => []
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '250px'
    }
  },
  watch: {
    assetData() {
      this.handelData()
    }
  },
  data() {
    return {
      chart: null,
      lineAndBarData: []
    }
  },
  methods: {
    handelData() {
      this.lineAndBarData = this.assetData.filter(v => v.type !== 'category')
      // console.log(this.lineAndBarData);
      let legendData = []
      // vue.prototype.$echart = () => {
      //   return { option: this.chart.getOption(), chart: this.chart };
      // };
      this.lineAndBarData.length > 0 &&
        this.lineAndBarData.forEach((item, index) => {
          legendData.push(this.$t(`portal.${item.name}`))
          item.data = item.values
          delete item.values
          if (item.type == 'bar' && index == 0) {
            item.itemStyle = {
              color: '#5582e9',
              // 柱子的样式
              barBorderRadius: [100, 100, 0, 0]
            }
            item.barWidth = 12 //柱子宽度
          }
          if (item.type == 'bar' && index == 1) {
            item.itemStyle = {
              color: '#20e0b1',
              // 柱子的样式
              barBorderRadius: [100, 100, 0, 0]
            }
            item.barWidth = 12 //柱子宽度
          }
          if (item.type == 'line') {
            item.yAxisIndex = 1
            item.smooth = false
            item.areaStyle = {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: 'rgba(129,237,242,0.5)'
                },
                {
                  offset: 1,
                  color: 'rgba(76,182,245,0.4)'
                }
              ])
            }
          }
        })
      this.initChart(legendData)
    },
    initChart(legendData = []) {
      legendData.forEach((item, i) => {
        this.lineAndBarData[i].name = item
      })
      const obj = deepClone(this.lineAndBarData)
      this.chart = echarts.init(this.$el, 'macarons')
      let option = {
        tooltip: {
          // trigger: 'axis',
          // axisPointer: {
          //   type: 'cross',
          //   crossStyle: {
          //     color: '#999'
          //   }
          // }
        },
        legend: {
          data: legendData,
          // textStyle:{
          //   color: localStorage.getItem('currentSkin') == 'theme-black' ? '#fff' : '#000'//字体颜色
          // },
          padding: [10, 0, 0, 5],
          left: 'left',
          icon: 'circle',
          itemWidth: 6,
          itemHeight: 6,
          textStyle: {
            color: '#8ea3b8'
          }
        },
        grid: {
          x: 50,
          y: 50,
          x2: 50,
          y2: 20
        },
        xAxis: [
          {
            type: 'category',
            data: this.assetData.length > 0 && this.assetData.filter(v => v.type == 'category')[0].values,
            axisPointer: {
              type: 'shadow'
            },
            splitLine: {
              show: false
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '',
            axisLabel: {
              formatter: '{value}'
            },
            splitLine: {
              show: false
            }
          },
          {
            type: 'value',
            name: '',
            min: 0,
            max: 100,
            interval: 10,
            axisLabel: {
              formatter: '{value} %'
            },
            splitLine: {
              show: false
            }
          }
        ],
        series: obj
      }
      this.chart.setOption(option)
    }
  },
  mounted() {
    vue.prototype.$echart = this.handelData
    this.initChart()
    this.__resizeHanlder = debounce(() => {
      if (this.chart) {
        this.chart.resize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHanlder)
    this.chart.dispose()
    this.chart = null
  }
}
</script>
<style lang="scss" scoped></style>
