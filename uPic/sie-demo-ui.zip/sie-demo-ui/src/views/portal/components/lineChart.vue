<template>
  <div :style="{ height: height, width: width }"></div>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'

export default {
  props: {
    assetData: {
      type: Array
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '250px'
    }
  },
  watch: {
    assetData() {
      this.handleData()
    }
  },
  data() {
    return {
      chart: null,
      lineAndBarData: []
    }
  },
  methods: {
    handleData() {
      this.chartData = this.assetData.filter(v => v.type !== 'category')
      this.assetData[0].name = this.$t(`portal.${this.assetData[0].name}`)
      this.assetData[1].name = this.$t(`portal.${this.assetData[1].name}`)
      this.chartData.length > 0 &&
        this.chartData.forEach(item => {
          item.data = item.values
          if (item.type == 'line') {
            item.yAxisIndex = 1
            item.smooth = false
            item.areaStyle = {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: 'rgba(129,237,242,0.5)'
                },
                {
                  offset: 1,
                  color: 'rgba(76,182,245,0.4)'
                }
              ])
            }
          }
        })
      this.initChart()
    },
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      let option = {
        tooltip: {
          // trigger: 'axis',
          // axisPointer: {
          //   type: 'cross',
          //   crossStyle: {
          //     color: '#999'
          //   }
          // }
        },
        legend: {
          data: this.assetData.length > 0 ? [this.assetData.filter(v => v.type == 'line')[0].name] : '',
          padding: [10, 0, 0, 5],
          left: 'left',
          icon: 'circle',
          itemWidth: 6,
          itemHeight: 6,
          textStyle: {
            color: '#8ea3b8'
          }
        },
        grid: {
          x: 50,
          y: 50,
          x2: 50,
          y2: 20
        },
        xAxis: [
          {
            type: 'category',
            data: this.assetData.length > 0 ? this.assetData.filter(v => v.type == 'category')[0].values : [],
            axisPointer: {
              type: 'shadow'
            },
            splitLine: {
              show: false
            }
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '',
            axisLabel: {
              formatter: '{value}'
            },
            splitLine: {
              show: false
            }
          },
          {
            type: 'value',
            name: '',
            min: 0,
            max: 100,
            interval: 10,
            axisLabel: {
              formatter: '{value} %'
            },
            splitLine: {
              show: false
            }
          }
        ],
        series: this.chartData
      }
      this.chart.setOption(option)
    }
  },
  mounted() {
    this.initChart()
    this.__resizeHanlder = debounce(() => {
      if (this.chart) {
        this.chart.resize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHanlder)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHanlder)
    this.chart.dispose()
    this.chart = null
  }
}
</script>
<style lang="scss" scoped></style>
