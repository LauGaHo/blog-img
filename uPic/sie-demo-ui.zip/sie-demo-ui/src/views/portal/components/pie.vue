<template>
  <div :style="{width: propData.width, height: propData.height}"></div>
</template>
<script>
import echarts from 'echarts';
require('echarts/theme/macarons'); // echarts theme
import { debounce } from '@/utils';
import vue from 'vue';
export default {
  props: {
    propData: {
      type: Object,
      default: () => ({
        width: {
          type: String,
          default: '100%'
        },
        height: {
          type: String,
          default: '100%'
        },
        title: String,
        color: {
          type: String,
          default: '#598CFF'
        },
        chartData: {
          type: Array,
          default: []
        }
      })
    }
  },
  data() {
    return {
      chart: null
    };
  },
  watch: {
    propData() {
      this.initChart();
    }
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons');
      // console.log(this.propData);
      // console.log(this.$t(`portal.${this.propData.title}`));
      let option = {
        title: {
          text: this.$t(`portal.${this.propData.title}`) || '',
          left: 'center',
          bottom: 0,
          textStyle: {
            color: localStorage.getItem('currentSkin') == 'theme-black' ? '#fff' : '#000',//字体颜色,
            fontSize: 12
          }
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}'
        },
        color: [this.propData.color, '#fff'], // 饼图颜色
        series: [
          {
            name: '',
            type: 'pie',
            radius: ['0', '50%'],
            center: ['50%', '40%'],

            label: {
              position: 'center',
              textStyle: {
                color: '#fff'
              }
            },
            labelLine: {
              show: false
            },
            data: this.propData.chartData
          },
          {
            name: '',
            type: 'pie',
            radius: ['60%', '70%'],
            center: ['50%', '40%'],

            label: {
              show: false
            },
            labelLine: {
              show: false
            },
            data: [...this.propData.chartData, { value: 50, name: '' }]
          }
        ]
      };
      this.chart.setOption(option);
    }
  },
  mounted() {
    vue.prototype.$pie = this.initChart;
    this.initChart();
    this.__resizeHanlder = debounce(() => {
      if (this.chart) {
        this.chart.resize();
      }
    }, 100);
    window.addEventListener('resize', this.__resizeHanlder);
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    window.removeEventListener('resize', this.__resizeHanlder);
    this.chart.dispose();
    this.chart = null;
  }
};
</script>
<style lang="scss" scoped>
</style>