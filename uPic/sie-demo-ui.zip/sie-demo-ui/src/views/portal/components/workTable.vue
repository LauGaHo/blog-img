<template>
  <div class="center" style="height: 100%">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span class="black-font-color" style="line-height: 36px">{{ $t('portal.toDo') }}</span>
        <el-button type="text" style="float: right" @click="$router.push('/worktable/agenda')">{{ $t('common.more') }}</el-button>
      </div>
      <div class="todo-table">
        <el-table :data="todoList" stripe>
          <el-table-column
            width="200px"
            :label="$t(`portal.${item.label}`)"
            sortable
            v-for="item in columns"
            :key="item.label"
            v-bind="item"
          >
            <template slot-scope="{ row }">
              <component :is="comps[item.prop] || 'common'" :content="row[item.prop]" :listData="JSON.stringify(row)" />
            </template>
          </el-table-column>
          <el-table-column width="100px" :label="$t('common.operation')" fixed="right">
            <template slot-scope="scope">
              <r-link :content="$t('common.check')" :listData="JSON.stringify(scope.row)"></r-link>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script>
import { findTodoTasks } from '@/api/worktable/agenda'

const common = {
  props: {
    content: String | Number,
    listData: String
  },
  render() {
    return <span>{this.content || '无'}</span>
  }
}

const rLink = {
  name: 'rLink',
  props: {
    content: String | Number,
    listData: String
  },
  render() {
    return (
      <router-link to={`/worktable/myProcess/myWorktable/todo_details?routerFromName=agenda&listData=${this.listData}`} class="link">
        {this.content}
      </router-link>
    )
  }
}

export default {
  name: 'todoList',
  components: { rLink, common },
  data() {
    return {
      todoList: [],
      total: 0,
      taskIds: [],
      listCurrentPage: 1,
      listPageSize: 10,
      comps: {
        taskName: 'rLink',
        operating: 'rLink'
      },
      columns: [
        { label: '流程标题', prop: 'bpm_title' },
        { label: '流程分类', prop: 'bpm_categoryName' },
        { label: '流程发起人', prop: 'bpm_userFullName' },
        { label: '申请时间', prop: 'bpm_startTime' },
        { label: '开始时间', prop: 'bpm_creationDate' },
        { label: '处理时长', prop: 'durationDHM' },
        { label: '待办状态', prop: 'status' },
        { label: '审批节点', prop: 'taskName' }
      ]
    }
  },
  computed: {
    tenantId() {
      return this.$store.state.user.tenantId
    }
  },
  created() {
    this.getFormList()
  },
  methods: {
    changeListSize(val) {
      this.listPageSize = val
      this.getFormList(this.listCurrentPage, this.listPageSize)
    },
    changeListCurrent(val) {
      this.listCurrentPage = val
      this.getFormList(this.listCurrentPage, this.listPageSize)
    },
    //选择了的数组
    handleSelectionChange(val) {
      this.taskIds = val.map(item => item.taskId)
      console.log(val)
    },
    async getFormList(pageIndex = 1, pageRows = 10) {
      const params = {
        systemType: 'EMS',
        companyId: this.tenantId
      }
      const {
        data: { data, count }
      } = await findTodoTasks({ params, pageIndex, pageRows })
      this.todoList = data
      this.total = count
    }
  }
}
</script>
<style lang="scss" scoped>
.center {
  ::v-deep .todo-table {
    .link {
      color: #2d8cf0;
    }
  }
}
</style>
