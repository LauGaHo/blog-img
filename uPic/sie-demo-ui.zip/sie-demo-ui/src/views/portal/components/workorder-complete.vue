<template>
  <div class="center">
    <el-card class="box-card black-font-color" >
      <div slot="header" class="clearfix">
        <span class="black-font-color" style="line-height: 36px;">{{
          $t('portal.statisticsOnWorkOrderPerformance')
        }}</span>
        <el-button
          type="primary"
          style="float: right"
          icon="el-icon-refresh"
          size="small"
          @click="$emit('refreshWorkOrder')"
          >{{ $t('button.refresh') }}</el-button
        >
      </div>
      <div class="flex">
        <div class="flex1">
          <line-and-bar
            :assetData="lineAndBarData"
            :width="`${width}px`"
          ></line-and-bar>
        </div>
        <div class="flex2">
          <div class="pie" v-for="(item, index) in circleData" :key="index">
            <pie
              :propData="{
                width: '100%',
                height: '100%',
                color: chartColor[index],
                title: item.name,
                chartData: [{ value: 100, name: item.values[0] }],
              }"
            ></pie>
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>
<script>
import pie from './pie';
import lineAndBar from './lineAndBar';
export default {
  components: { pie, lineAndBar },
  props: {
    workOrderData: {
      type: Object,
      default: () => {},
    },
  },
  watch: {
    workOrderData() {
      this.handleData();
    },
  },
  computed: {
    width() {
      const w = document.body.offsetWidth - 180 - 80;
      return w * 0.65;
    },
  },
  data() {
    return {
      circleData: [],
      lineAndBarData: [],
      chartColor: ['#598CFF', '#20e0b1', '#FFC63C', '#18BFB9'],
    };
  },
  methods: {
    handleData() {
      this.circleData = this.workOrderData.totalDataList;
      this.lineAndBarData = this.workOrderData.unitDataList;
    },
  },
};
</script>
<style lang="scss" scoped>
.flex {
  display: flex;
  align-items: center;
}
.flex1 {
  width: 65%;
}
.flex2 {
  width: 35%;
}
.pie {
  display: inline-block;
  width: 50%;
  height: auto;
}

.center {
  margin: 0 0 10px 0;
  .box-card {
    margin-bottom: 0;
  }
  ::v-deep .el-card__header {
    padding: 8px 20px;
  }
}
</style>