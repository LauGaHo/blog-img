<template>
  <div class="app-container">
    <el-carousel :interval="5000" arrow="always" height="345px" :autoplay="false" v-if="false">
      <el-carousel-item v-if="pageContentData.indexOf('p3') > -1">
        <work-order-complate
          :workOrderData="workOrderData"
          @refreshWorkOrder="findWorkorderComplete"
          v-if="pageContentData.indexOf('p3') > -1"
        ></work-order-complate>
      </el-carousel-item>
      <el-carousel-item v-if="pageContentData.indexOf('p1') > -1 || pageContentData.indexOf('p2') > -1">
        <div class="center flex">
          <div class="flex1" v-if="pageContentData.indexOf('p1') > -1">
            <el-card class="box-card">
              <div slot="header" class="clearfix">
                <span class="black-font-color" style="line-height: 36px">{{ $t('portal.deviceFailureRateStatisticsIcon') }}</span>
                <el-button
                  type="primary"
                  size="small"
                  style="float: right"
                  icon="el-icon-refresh"
                  @click="findFaultTotal()"
                  :loading="faultLoading"
                  >{{ $t('button.refresh') }}</el-button
                >
              </div>

              <line-and-bar :assetData="faultData" :width="`${width}px`"></line-and-bar>
            </el-card>
          </div>
          <div
            class="flex1 black-font-color"
            :class="{ 'margin-left-15': pageContentData.indexOf('p1') > -1 }"
            v-if="pageContentData.indexOf('p2') > -1"
          >
            <el-card class="box-card">
              <div slot="header" class="clearfix">
                <span class="black-font-color" style="line-height: 36px">{{ $t('portal.deviceIntegrityStatisticsIcon') }}</span>
                <el-button type="primary" style="float: right" icon="el-icon-refresh" @click="findIntactTotal()" size="small">{{
                  $t('button.refresh')
                }}</el-button>
              </div>
              <line-chart :assetData="intactData" :width="`${width}px`"></line-chart>
            </el-card>
          </div>
        </div>
      </el-carousel-item>
    </el-carousel>

    <workTable />
  </div>
</template>
<script>
import {
  findWorkorderComplete,
  findIntactTotal,
  findFaultTotal,
  findListByLoginUser
} from '@/api/portal'
import lineAndBar from './components/lineAndBar'
import lineChart from './components/lineChart'
import workOrderComplate from './components/workorder-complete'
import workTable from './components/workTable'
import { autoLogin } from '@/api/login'
import vue from 'vue'
export default {
  components: { lineAndBar, lineChart, workOrderComplate, workTable },
  data() {
    return {
      lineAndBarData: [],
      faultData: [],
      intactData: [],
      workOrderData: null,
      pageContentData: [],
      faultLoading: false,
      intactLoading: false
    }
  },
  computed: {
    userName() {
      return this.$store.state.user.userFullName
    },
    width() {
      const hasP12 = this.pageContentData.indexOf('p1') > -1 && this.pageContentData.indexOf('p2') > -1
      const w = document.body.offsetWidth - 180 - (hasP12 ? 160 : 100)
      const ratio = hasP12 ? 0.5 : 1
      return w * ratio
    }
  },
  async created() {
    vue.prototype.$updateDatas = {
      findListByLoginUser: this.findListByLoginUser,
      findWorkorderComplete: this.findWorkorderComplete
    }
  },
  methods: {
    //获取分配的门户内容
    async findListByLoginUser() {
      const res = await findListByLoginUser()
      if (res.code === 800) {
        this.pageContentData = res.data.map(item => item.contentNo)
        if (this.pageContentData.indexOf('p1') > -1) {
          this.findFaultTotal()
        }
        if (this.pageContentData.indexOf('p2') > -1) {
          this.findIntactTotal()
        }
        if (this.pageContentData.indexOf('p3') > -1) {
          this.findWorkorderComplete()
        }
      }
    },
    // 设备故障率分月统计图表
    async findFaultTotal() {
      let requestParams = {
        params: {
          tenantId: this.tenantId,
          unit: 'month', //month 月   quarter 季度
          year: '',
          departmentId: null
        }
      }
      this.faultLoading = true
      const res = await findFaultTotal(requestParams)
      this.faultLoading = false
      if (res.code === 800) {
        this.faultData = res.data.unitDataList
      }
    },
    // 设备完好率分月统计图表
    async findIntactTotal() {
      let requestParams = {
        params: {
          tenantId: this.tenantId,
          unit: 'month', //month 月   quarter 季度
          year: '',
          departmentId: null
        }
      }
      this.intactLoading = true
      const res = await findIntactTotal(requestParams)
      this.intactLoading = false
      if (res.code === 800) {
        this.intactData = res.data.unitDataList
      }
    },
    // 工单执行情况统计图表
    async findWorkorderComplete() {
      let requestParams = {
        params: {
          tenantId: this.tenantId,
          unit: 'month', //month 月   quarter 季度
          year: '',
          departmentId: null
        }
      }
      const res = await findWorkorderComplete(requestParams)
      if (res.code === 800) {
        this.workOrderData = res.data
      }
    }
  },
  mounted() {
    // 发送请求获取头像
    // if (localStorage.getItem('userHeadImgUrl') == null) {
    autoLogin(_config.systemCode).then(res => {
      if (res.data.userHeadImgUrl !== 'defaultImgUrl') {
        this.$store.commit('setUserHeadImgUrl', res.data.userHeadImgUrl)
      }
    })
    // }
  }
}
</script>
<style lang="scss" scoped>
.app-container {
  height: 100%;
  // background: #eef0f6;
  .flex {
    display: flex;
  }
  .flex1 {
    flex: 1;
  }
  .flex1-5 {
    flex: 1.5;
  }
  .flex2 {
    flex: 2;
  }
  .flex2-5 {
    flex: 2.5;
  }
  .bg-white {
    background: #fff;
  }
  .margin-left-10 {
    margin-left: 10px;
  }
  .margin-left-15 {
    margin-left: 15px;
  }
  .center {
    margin: 0 0 10px 0;
    .box-card {
      margin-bottom: 0;
    }
    ::v-deep .el-card__header {
      padding: 8px 20px;
    }
  }
  ::v-deep .el-carousel__button {
    background-color: rgb(48, 55, 61);
  }
}
</style>
