<template>
  <div></div>
</template>

<script>
import { getBaseUserLoginSso, getTokenByPortalCode } from '@/api/app'
import { autoLogin } from '@/api/login'
import { setToken, setMenuList } from '@/utils/auth'

export default {
  data() {
    //这里存放数据
    return {
      loading: null
    }
  },
  //方法集合
  methods: {
    // 获取用户信息
    async getLoginUser() {
      this.loading = this.$loading({
        lock: true,
        text: 'Loading',
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      const res = await getBaseUserLoginSso()
      this.loading.close()
      if (res.code === 800) {
        const { systems } = res.data
        let { urlLogout, urlLogin, portalType } = res.data
        let redirect = location.origin
        let hasAuth = false
        if (res.data.portalType === 'sso') {
          localStorage.setItem('urlLogout', urlLogout)
          localStorage.setItem('urlLogin', urlLogin)
          localStorage.setItem('portalType', portalType)
        }
        localStorage.userInfo = JSON.stringify(res.data)
        // 判断是否有系统权限
        if (Array.isArray(systems)) {
          const authSystems = systems.map(item => item.systemCode)
          if (!authSystems.includes(_config.systemCode)) {
            // 有谷神权限重定向到门户，否则强制退出
            if (_config.systemCode !== 'iotAutho') this.$message.error('您的账号暂无系统登录权限！')
            this.$router.push({
              path: '/'
            })
            return
          } else hasAuth = true
        }
        this.autoLogin(hasAuth, redirect, res.data)
      }
    },
    async autoLogin(hasAuth, redirectUrl, data) {
      // let redirect = hasAuth ? '/' : redirectUrl
      let res = await autoLogin(_config.systemCode)
      if (res.code === 800) {
        setMenuList(res.data.menus)
        if (data.defaultUrl && process.env.NODE_ENV === 'production') {
          location.href = data.defaultUrl
        } else {
          this.$router.push({
            path: '/'
          })
        }
      }
    },
    // 根据portalCode获取token信息
    async getTokenByPortalCode() {
      const url = window.location.href
      const code = localStorage.getItem('portalCode') || 'code'
      let params = ''
      const pram = url.split('?')[1]
      const keyValue = pram.split('&')
      for (let i = 0; i < keyValue.length; i++) {
        let key = keyValue[i].split('=')[0]
        if (code == key) {
          params = keyValue[i]
        }
      }
      const res = await getTokenByPortalCode(params)
      if (res.code === 800) {
        setToken(res.data.authorization, res.data['refresh-authorization'])
        await this.getLoginUser()
      }
    }
  },
  created() {
    this.getTokenByPortalCode()
  },
}
</script>
