<template>
  <el-card>
    <cus-table
      ref="cusTable"
      class="cusTable"
      :table-data="tableData"
      :gridConfig="gridConfig"
      @current-change="handleCurrentChange"
      @size-change="handleSizeChange"
      @select="handleSelect"
      @refresh="refresh"
      :tableHeight="remainingHeight"
    ></cus-table>
  </el-card>
</template>

<script>
import { getDataList } from '@/api/testMenu/demo1';
export default {
  name: 'demo1',
  data() {
    return {
      remainingHeight: 0,
      gridConfig: {
        translate: 'demo1_index',
        localstorageName: 'demo1_table',
        slotArr: [],
        columns: [
          {
            prop: 'psnName',
            isShow: true,
          },
          {
            prop: 'tenantName',
            isShow: true,
          },
          {
            prop: 'loginTime',
            isShow: true,
          },
          {
            prop: 'logoutTime',
            isShow: true,
          },
          {
            prop: 'loginFrom',
            isShow: true,
          },
          { prop: 'loginIp', isShow: true },
          {
            prop: 'loginMac',
            isShow: true,
          },
          {
            prop: 'loginSystem',
            isShow: true,
          },
        ],
      },
      tableData: {
        tableList: [],
        count: 0,
        curIndex: 1,
        pageSize: 10,
      },
    };
  },
  methods: {
    findTableList({ pageIndex = 1, pageRows = 10, params = {} }) {
      const data = {
        pageIndex,
        pageRows,
        params: {
          ...params,
        },
      };
      getDataList(data).then((res) => {
        if (res.code === 800) {
          this.tableData = {
            tableList: res.data.data,
            count: res.data.count,
            curIndex: res.data.curIndex,
            pageSize: res.data.pageSize,
          };
        }
      });
    },
    handleCurrentChange(pageIndex) {
      const data = {
        pageIndex,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    handleSizeChange(size) {
      this.tableData.pageSize = size;
      const data = {
        pageIndex: 1,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    handleSelect() {},
    refresh() {
      const data = {
        pageIndex: 1,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    getStepHeight() {
      const appMainHeight = document.getElementsByClassName('app-main')[0]
        .offsetHeight;
      this.remainingHeight = appMainHeight;
    },
  },
  mounted() {
    this.findTableList({ pageIndex: 1, pageRows: 10, params: {} });
    window.onresize = () => {
      this.getStepHeight();
    };
    this.$nextTick(() => {
      this.getStepHeight();
    });
  },
  destroyed() {
    window.removeEventListener('resize', this.getStepHeight);
  },
};
</script>
