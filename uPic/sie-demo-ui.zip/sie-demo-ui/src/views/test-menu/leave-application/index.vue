<template>
  <el-card>
    <cus-table
      ref="cusTable"
      class="cusTable"
      :table-data="tableData"
      :gridConfig="gridConfig"
      @current-change="handleCurrentChange"
      @size-change="handleSizeChange"
      @select="handleSelect"
      @refresh="refresh"
    >
      <template v-slot:btn>
        <el-button type="primary" @click="() => addLeave()">新增</el-button>
      </template>

      <template v-slot:action="{ scope }">
        <el-button
          type="text"
          class="edit-btn"
          icon="el-icon-edit"
          size="mini"
          @click="updateLeave(scope.row)"
        >编辑</el-button>
      </template>
    </cus-table>
  </el-card>
</template>

<script>
import {
  getDataList,
  save,
  update,
  getObj,
  de,
} from '@/api/testMenu/leaveApplication';
export default {
  name: 'leaveApplication',
  data() {
    return {
      gridConfig: {
        translate: 'leaveApplication',
        localstorageName: 'leaveApplication',
        slotArr: ['action'],
        columns: [
          {
            prop: 'tlName',
            isShow: true,
          },
          {
            prop: 'startDate',
            isShow: true,
          },
          {
            prop: 'tlDay',
            isShow: true,
          },
          {
            prop: 'tlExplain',
            isShow: true,
          },
          {
            prop: 'tlStatus',
            isShow: true,
          },
          {
            prop: 'action',
            width: 50,
            isShow: true,
            fixed: 'right',
          },
        ],
      },
      tableData: {
        tableList: [],
        count: 0,
        curIndex: 1,
        pageSize: 10,
      },
    };
  },
  methods: {
    findTableList({ pageIndex = 1, pageRows = 10, params = {} }) {
      const data = {
        pageIndex,
        pageRows,
        params: {
          ...params,
        },
      };
      getDataList(data).then((res) => {
        if (res.code === 800) {
          this.tableData = {
            tableList: res.data.data,
            count: res.data.count,
            curIndex: res.data.curIndex,
            pageSize: res.data.pageSize,
          };
        }
      });
    },
    handleCurrentChange(pageIndex) {
      const data = {
        pageIndex,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    handleSizeChange(size) {
      this.tableData.pageSize = size;
      const data = {
        pageIndex: 1,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    handleSelect() {},
    refresh() {
      const data = {
        pageIndex: 1,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    addLeave() {
      this.$router.push({
        path: '/leave/info',
        query: {
          type: 'add',
        },
      });
    },
    async updateLeave(row) {
      this.$router.push({
        path: '/leave/info',
        query: {
          type: 'edit',
          tlId: row.tlId,
        },
      });
    },
  },
  mounted() {
    this.findTableList({ pageIndex: 1, pageRows: 10, params: {} });
  },
  destroyed() {},
};
</script>
