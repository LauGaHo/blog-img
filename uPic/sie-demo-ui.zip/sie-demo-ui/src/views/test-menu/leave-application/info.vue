<template>
  <div class="public-form-search overhaul-add">
    <el-card class="mb-20">
      <div class="btn">
        <el-button
          icon="el-icon-edit-outline"
          type="primary"
          @click="handleBack"
          v-if="!visibleBtn"
          >{{ $t('button.cancel') }}</el-button
        >
        <el-button
          icon="el-icon-edit-outline"
          type="primary"
          @click="handleSave(false)"
          v-if="!visibleBtn"
          >{{ $t('button.save') }}</el-button
        >
        <el-button
          icon="el-icon-circle-check"
          type="primary"
          @click="handleSubmit()"
          v-if="!visibleBtn"
          >{{ $t('button.submit') }}</el-button
        >
      </div>
      <el-row :class="{ 'form-container': true }">
        <el-form :model="form" :rules="rule" ref="form">
          <el-col :span="8">
            <el-form-item label="请假人" prop="tlName" label-width="120px">
              <el-input
                v-model="form.tlName"
                autocomplete="off"
                :disabled="disabledInput"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="请假日期" prop="startDate" label-width="120px">
              <el-date-picker
                style="width: 100%"
                v-model="form.startDate"
                type="datetime"
                placeholder="选择日期时间"
                value-format="yyyy-MM-DD HH:mm:ss"
                :disabled="disabledInput"
              ></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="请假天数" prop="tlDay" label-width="120px">
              <el-input
                type="number"
                v-model="form.tlDay"
                autocomplete="off"
                :disabled="disabledInput && disabledTlDay"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="请假事项" prop="tlExplain" label-width="120px">
              <el-input
                type="textarea"
                v-model="form.tlExplain"
                autocomplete="off"
                :disabled="disabledInput"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
    </el-card>
  </div>
</template>

<script>
import {
  getDataList,
  save,
  update,
  getObj,
  de,
} from '@/api/testMenu/leaveApplication';
export default {
  components: {},
  props: {
    //是否是流程
    inProcess: {
      type: Boolean,
      default: false,
    },
    //
    editStatus: {
      //是否可编辑表格 0否 1 是
      type: String | Number,
      default: 1,
    },
    //业务表单key id，用于查询表单详情
    bpm_businessKey: Number | String,
    //来源页面
    formPage: {
      type: String,
    },
    //需要动态设置的表单赋值
    taskServiceParams: Array,
    //流程当前节点
    curTaskName: String,
  },
  data() {
    //这里存放数据
    return {
      form: {
        startDate: '',
        tlDay: '',
        tlExplain: '',
        tlName: '',
      },
      rule: {
        startDate: [
          { required: true, message: '请选择请假日期', trigger: 'blur' },
        ],
        tlDay: [{ required: true, message: '请填写请假日期', trigger: 'blur' }],
        tlExplain: [
          { required: true, message: '请填写请假日期', trigger: 'blur' },
        ],
        tlName: [
          { required: true, message: '请填写请假日期', trigger: 'blur' },
        ],
      },
    };
  },
  //监听属性 类似于data概念
  computed: {
    visibleBtn() {
      return this.inProcess;
    },
    disabledInput() {
      return this.inProcess;
    },
    disabledTlDay() {
      return this.curTaskName !== '项目组长';
    },
  },
  //监控data中的数据变化
  watch: {},
  mounted() {
    const { type, tlId } = this.$route.query;
    if (type === 'edit' || !!this.bpm_businessKey) {
      this.getObj(tlId || this.bpm_businessKey);
    }
  },
  //方法集合
  methods: {
    async getObj(tlId) {
      const res = await getObj(tlId);
      if (res.code === 800) {
        this.form = res.data;
      }
    },
    async handleSave(isSubmit) {
      this.$refs.form.validate(async (valid) => {
        if (valid) {
          const { type, tlId } = this.$route.query;
          const request = this.inProcess || type === 'edit' ? update : save;
          const params = {
            params: {
              ...this.form,
              tlStatus: isSubmit ? '提交' : '拟定',
            },
          };
          const res = await request(params);
          if (res.code === 800) {
            this.$message.success(res.msg);
            this.dialogFormVisible = false;
            if (this.inProcess) {
              return Promise.resolve(res);
            } else {
              this.$router.push({
                path: '/test-menu/leave-application',
              });
            }
          }
        }
      });
    },
    async handleSubmit() {
      this.handleSave(true);
    },
    handleBack() {
      this.$router.push({
        path: '/test-menu/leave-application',
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.public-form-search.overhaul-add {
  ::v-deep .el-input__inner {
    max-width: none;
  }

  .el-col {
    height: auto;
  }
}
</style>