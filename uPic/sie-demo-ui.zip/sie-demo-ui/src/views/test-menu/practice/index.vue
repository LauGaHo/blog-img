<template>
  <el-card>
    <el-row>
      <el-form
        class="form-container"
        :model="searchForm"
        label-width="80px"
        ref="form"
        style="margin-top: 20px"
      >
        <el-col :span="8">
          <el-form-item label="部门编码">
            <el-input v-model="searchForm.deptCode"></el-input> </el-form-item
        ></el-col>
        <el-col :span="8">
          <el-form-item label="部门名称">
            <el-input v-model="searchForm.deptName"></el-input> </el-form-item
        ></el-col>
        <el-col :span="8">
          <el-button
            size="small"
            type="primary"
            icon="el-icon-search"
            @click="handleSearch()"
          >
            {{ '搜索' }}</el-button
          >
        </el-col>
      </el-form>
    </el-row>
    <el-row>
      <el-button
        size="small"
        style="margin-right: 10px"
        type="primary"
        icon="el-icon-plus"
        @click="handleAdd()"
      >
        {{ '新增' }}</el-button
      >
      <importDataPlus @emitImportEvent="refresh" :importQuery="'practice_1'">
      </importDataPlus>
      <exportDataPlus
        style="margin-left: 10px"
        :exportQuery="'/api/other/dept-shenzhou/find-pagination'"
      ></exportDataPlus>
    </el-row>
    <el-table
      :data="tableData"
      stripe=""
      border
      style="width: 100%; margin-top: 1%"
    >
      <el-table-column
        label="序号"
        align="center"
        fixed="left"
        type="index"
        width="80"
      >
      </el-table-column>
      <el-table-column label="部门名称" prop="deptName"> </el-table-column>
      <el-table-column label="部门类型" prop="deptType"> </el-table-column>
      <el-table-column label="部门负责人" prop="deptPersonName">
      </el-table-column>
      <el-table-column label="部门描述" prop="deptInfo"> </el-table-column>
      <el-table-column label="操作" align="center" fixed="right" width="180">
        <template slot-scope="scope">
          <el-link
            class="op-link"
            type="primary"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
          >
            {{ '编辑' }}</el-link
          >
          <el-link
            class="op-link"
            style="margin-left: 10px"
            type="danger"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
          >
            {{ '删除' }}</el-link
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="t-pagination"
      @size-change="changePageSize"
      @current-change="changePageCurrent"
      :current-page="pageIndex"
      :page-sizes="[10, 20, 30, 50]"
      :page-size="pageRows"
      layout="prev,pager,next,total,sizes,jumper"
      :total="total"
    ></el-pagination>
    <el-drawer
      :title="action == 'add' ? '新增' : '编辑'"
      :visible.sync="drawer"
      size="35%"
    >
      <div class="drawer-content">
        <el-form
          class="form-container"
          :model="modelInfo"
          label-width="80px"
          ref="form"
          style="margin-top: 20px"
        >
          <el-form-item label="部门名称">
            <el-input v-model="modelInfo.deptName"></el-input>
          </el-form-item>
          <el-form-item label="部门编码">
            <el-input v-model="modelInfo.deptCode"></el-input>
          </el-form-item>
          <el-form-item label="部门类型">
            <el-select v-model="modelInfo.deptType">
              <el-option
                v-for="item of deptTypeList"
                :key="item.diId"
                :label="item.dicName"
                :value="item.dicCode"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="部门负责人">
            <el-input v-model="modelInfo.deptPersonName"></el-input>
          </el-form-item>
          <el-form-item label="部门描述">
            <el-input
              type="textarea"
              :rows="2"
              v-model="modelInfo.deptInfo"
            ></el-input>
          </el-form-item>
        </el-form>
      </div>
      <footer class="drawer-footer">
        <el-button
          type="primary"
          class="save-btn"
          @click="drawer = false"
          size="small"
          >{{ $t('button.cancel') }}</el-button
        >
        <el-button
          type="primary"
          class="save-btn"
          @click="handleSave"
          size="small"
          >{{ $t('button.save') }}</el-button
        >
      </footer>
    </el-drawer>
  </el-card>
</template>

<script>
import { deleteInfo, saveInfo, updateInfo, findInfoList } from '@/api/practice';
import ImportDataMixin from '@/utils/importDataMixin';
import { findDictionaryType } from '@/api/app';
export default {
  mixins: [ImportDataMixin],
  components: { importDataPlus, exportDataPlus },
  data() {
    return {
      tableData: [],
      modelInfo: {},
      deptTypeList: [],
      drawer: false,
      queryUrl: '/api/other/dept-shenzhou/find-pagination',
      action: 'add',
      searchForm: {},
      pageIndex: 1,
      pageRows: 10,
      total: 0,
    };
  },
  mounted() {
    this.getTableData();
    this.findDictionaryType();
  },
  methods: {
    exportDataHandle() {
      const params = JSON.stringify({
        pageIndex: 1,
        pageRows: 9999,
        params: {
          ...this.searchForm,
        },
      });
      const exportInfo = {
        labelName: `['部门名称','部门编码','部门类型','部门负责人','部门描述']`,
        attributeNames: `['deptName','deptCode','deptType','deptPersonName','deptInfo']`,
        requestUrl: this.queryUrl,
        requestParam: params,
        post: true,
        emailSubject: '部门信息表',
      };
      exportTool(exportInfo);
    },
    findDictionaryType() {
      findDictionaryType('SECP_ORGANIZATION_TYPE').then((res) => {
        this.deptTypeList = res.data;
      });
    },
    changePageSize(val) {
      this.pageRows = val;
      this.pageIndex = 1;
      this.getTableData();
    },
    changePageCurrent(val) {
      this.pageIndex = val;
      this.getTableData();
    },
    handleAdd() {
      this.action = 'add';
      this.modelInfo = {};
      this.drawer = true;
    },
    handleSave() {
      let data = {
        params: { ...this.modelInfo },
      };
      if (this.action == 'add') {
        saveInfo(data).then((res) => {
          if ((res.code = 800)) {
            this.$message.success(res.msg);
            this.drawer = false;
            this.getTableData();
          }
        });
      }
      if (this.action == 'edit') {
        updateInfo(data).then((res) => {
          if ((res.code = 800)) {
            this.$message.success(res.msg);
            this.drawer = false;
            this.getTableData();
          }
        });
      }
    },
    refresh() {
      this.getTableData();
    },
    handleUpdate(row) {
      this.action = 'edit';
      this.modelInfo = row;
      this.drawer = true;
    },
    handleDelete(row) {
      this.$confirm('此操作将永久该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        deleteInfo(row.deptId).then((res) => {
          if (res.code === 800) {
            this.$message.success(res.msg);
            this.getTableData();
          }
        });
      });
    },
    getTableData() {
      let data = {
        pageIndex: this.pageIndex,
        pageRows: this.pageRows,
        params: {
          ...this.searchForm,
        },
      };
      findInfoList(data).then((res) => {
        if ((res.code = 800)) {
          this.tableData = res.data.data;
          this.total = res.data.count;
        }
      });
    },
    handleSearch() {
      this.getTableData();
    },
  },
};
</script>


<style lang="scss" scoped>
.drawer-content {
  padding: 10px 30px;
  margin-bottom: 50px;
}
::v-deep .el-drawer__body {
  height: 100%;
  overflow: auto;
}
.drawer-footer {
  position: absolute;
  text-align: right;
  padding: 0 15px;
  background: #fff;
  height: 60px;
  line-height: 60px;
  border-top: 1px solid #f0f0f0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 99;
}
.t-pagination {
  margin-top: 10px;
  display: flex;
  justify-content: flex-end;
}
</style>