<template>
  <el-card>
    <cus-table
      ref="cusTable"
      class="cusTable"
      :table-data="tableData"
      :gridConfig="gridConfig"
      @current-change="handleCurrentChange"
      @size-change="handleSizeChange"
      @select="handleSelect"
      @refresh="refresh"
    >
      <template v-slot:btn>
        <el-button type="primary" @click="() => addLeave()">{{
          $t('test_demo.add')
        }}</el-button>
        <el-button
          type="primary"
          size="small"
          icon="el-icon-download"
          @click="handleImport"
          v-if="isHaveBtnAuth('导入数据')"
          >{{ $t('test_demo.import') }}</el-button
        >
        <el-button
          type="primary"
          size="small"
          icon="el-icon-upload2"
          @click="handleExport"
          v-if="isHaveBtnAuth('导出模板')"
          >{{ $t('test_demo.export') }}</el-button
        >
      </template>
      <template v-slot:action="{ scope }">
        <el-button
          type="text"
          class="edit-btn"
          icon="el-icon-edit"
          size="mini"
          @click="updateLeave(scope.row)"
          >{{ $t('test_demo.edit') }}</el-button
        >
        <el-button
          type="text"
          class="delete-btn"
          icon="el-icon-delete"
          size="mini"
          @click="deleteObj(scope.row)"
          >{{ $t('test_demo.delete') }}</el-button
        >
      </template>
    </cus-table>
    <el-drawer
      :title="$t('test_demo.title')"
      :visible.sync="drawerApi"
      direction="rtl"
      size="25%"
      custom-class="drawer-api"
    >
      <div class="drawer-content">
        <el-form
          class="form-container"
          :model="modelInfo"
          :rules="rulesInfo"
          label-width="130px"
          ref="form"
          style="margin-top: 20px"
        >
          <el-row class="f-item" :gutter="20">
            <el-col :span="24">
              <el-form-item
                :label="$t('table.test_demo.testCode')"
                prop="testCode"
              >
                <el-input
                  size="medium"
                  v-model="modelInfo.testCode"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                :label="$t('table.test_demo.testContent')"
                prop="testContent"
              >
                <el-input
                  size="medium"
                  v-model="modelInfo.testContent"
                  clearable
                ></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item
                :label="$t('table.test_demo.testDate')"
                prop="testDate"
              >
                <el-date-picker
                  v-model="modelInfo.testDate"
                  type="datetime"
                  value-format="yyyy-MM-DD HH:mm:ss"
                  clearable
                ></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <footer class="drawer-footer">
        <el-button
          type="primary"
          class="save-btn"
          @click="drawerApi = false"
          size="small"
          >{{ $t('button.cancel') }}</el-button
        >
        <el-button
          type="primary"
          class="save-btn"
          @click="handleSure"
          size="small"
          :loading="loading"
          >{{ $t('button.save') }}</el-button
        >
      </footer>
    </el-drawer>
    <import-data
      ref="importData"
      :importInfo="importInfo"
      @refreshData="refresh"
    />
  </el-card>
</template>

<script>
import {
  getDataList,
  save,
  update,
  getObj,
  deleteDemoa,
} from '@/api/testMenu/testDemo';
import { getImportMenuCode } from '@/api/menu';
import ImportData from '@/components/ImportData';
export default {
  name: 'leaveApplication',
  components: {
    ImportData,
  },
  data() {
    return {
      gridConfig: {
        translate: 'test_demo',
        localstorageName: 'test_demo',
        slotArr: ['action'],
        columns: [
          {
            prop: 'testCode',
            isShow: true,
          },
          {
            prop: 'testContent',
            isShow: true,
          },
          {
            prop: 'testDate',
            isShow: true,
          },
          {
            prop: 'action',
            isShow: true,
          },
        ],
      },
      tableData: {
        tableList: [],
        count: 0,
        curIndex: 1,
        pageSize: 10,
      },
      drawerApi: false,
      isEdit: false,
      loading: false,
      modelInfo: {
        testCode: '',
        testContent: '',
        testDate: '',
      },
      rulesInfo: {
        testCode: [{ required: true, message: '请填写', trigger: 'blur' }],
        testContent: [{ required: true, message: '请填写', trigger: 'blur' }],
        testDate: [{ required: true, message: '请填写', trigger: 'blur' }],
      },
      importInfo: null,
    };
  },
  mounted() {
    this.findTableList({ pageIndex: 1, pageRows: 10, params: {} });
  },
  methods: {
    findTableList({ pageIndex = 1, pageRows = 10, params = {} }) {
      const data = {
        pageIndex,
        pageRows,
        params: {
          ...params,
        },
      };
      getDataList(data).then((res) => {
        if (res.code === 800) {
          this.tableData = {
            tableList: res.data.data,
            count: res.data.count,
            curIndex: res.data.curIndex,
            pageSize: res.data.pageSize,
          };
        }
      });
    },
    handleCurrentChange(pageIndex) {
      const data = {
        pageIndex,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    handleSizeChange(size) {
      this.tableData.pageSize = size;
      const data = {
        pageIndex: 1,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    handleSelect() {},
    refresh() {
      const data = {
        pageIndex: 1,
        pageRows: this.tableData.pageSize,
        params: {},
      };
      this.findTableList(data);
    },
    addLeave() {
      this.drawerApi = true;
      this.isEdit = false;
      this.modelInfo = {
        testCode: '',
        testContent: '',
        testDate: '',
      };
    },
    async updateLeave(row) {
      this.drawerApi = true;
      this.isEdit = true;
      this.modelInfo = Object.assign({}, row);
    },
    async deleteObj(row) {
      this.$confirm('此操作将永久该数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        deleteDemoa(row.testId).then((res) => {
          if (res.code === 800) {
            this.$message.success(res.msg);
            this.findTableList({ pageIndex: 1, pageRows: 10, params: {} });
          }
        });
      });
    },
    async handleSure() {
      this.$refs.form.validate(async (valid) => {
        if (valid) {
          const params = {
            params: this.modelInfo,
          };
          const request = this.isEdit ? update : save;
          this.loading = true;
          const res = await request(params);
          this.loading = false;
          if (res.code === 800) {
            this.$message.success(res.msg);
            this.drawerApi = false;
            this.findTableList({ pageIndex: 1, pageRows: 10, params: {} });
          }
        }
      });
    },
    async handleImport() {
      const { meta } = this.$route;
      const resAuth = await getImportMenuCode(meta.menuCode, 1);
      if (resAuth.data && resAuth.data.importH) {
        this.importInfo = resAuth.data;
        const { importH } = resAuth.data;
        if (importH && importH.importId) {
          this.$refs.importData.dialogVisible = true;
        } else {
          this.$message.warning('请先设置导入模板数据！');
        }
      }
    },
    async handleExport() {
      const { meta } = this.$route;
      const resAuth = await getImportMenuCode(meta.menuCode, 1);
      if (resAuth.data && resAuth.data.file) {
        const { file } = resAuth.data;
        if (file && file.filePath) {
          window.open(file.filePath);
        } else {
          this.$message.warning('请先设置导入模板数据！');
        }
      }
    },
  },
};
</script>

<style lang="scss" scoped>
.drawer-content {
  padding: 10px 30px;
  margin-bottom: 50px;
}
::v-deep .el-drawer__body {
  height: 100%;
  overflow: auto;
}
.drawer-footer {
  position: absolute;
  text-align: right;
  padding: 0 15px;
  background: #fff;
  height: 60px;
  line-height: 60px;
  border-top: 1px solid #f0f0f0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 99;
}
::v-deep :focus {
  outline: 0;
}
</style>