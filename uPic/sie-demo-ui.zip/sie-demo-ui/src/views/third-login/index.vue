<template>
  <div class="loading-box" v-show="showLoading">
    <img :src="loadingImg" />
  </div>
</template>
<script>
import { mapMutations } from 'vuex'
import { autoLogin } from '@/api/login'
import { setToken, setUserInfo, setMenuList } from '@/utils/auth'
import HttpRequest from '@/utils/request'

export default {
  name: 'thirdPartyLogin',
  data() {
    return {
      showLoading: true,
      loadingImg: 'https://sieiot-resources.oss-cn-beijing.aliyuncs.com/web/gushen/images/workflow/loading.gif'
    }
  },
  created() {
    let code = this.$route.query.code
    let state = this.$route.query.state
    // 大飞本地host：10.10.4.181:9020
    // .get(`/api/base/auth-wx-login/callback?code=${code}&state=${state}`)
    HttpRequest({
      url: `/api/base/auth-wx-login/callback?code=${code}&state=${state}`,
      method: 'get',
      timeout: 50000
    }).then(res => {
      if (this.reqIsSucceed(res)) this.afterLoginSuccess(res)
      else this.$message.warning(res.msg)
      // this.$router.push('/login');
    })
  },
  methods: {
    ...mapMutations(['SET_TENANTID', 'SET_USERLIMIT']),
    afterLoginSuccess(res) {
      setToken(res.token, res.data['refresh-authorization'])
      setUserInfo(res.data, this)
      this.SET_USERLIMIT(res.data.useLimitCode)
      this.SET_TENANTID(res.data.tenantId)
      if (res.data.userHeadImgUrl !== 'defaultImgUrl' && res.data.userHeadImgUrl !== '')
        this.$store.commit('setUserHeadImgUrl', res.data.userHeadImgUrl)
      // 如果返回defaultImgUrl，要清除缓存，使用默认头像
      else this.$store.commit('setUserHeadImgUrl', '')
      this.autoLogin(res.data)
    },
    async autoLogin(data) {
      let res = await autoLogin(window._config.systemCode)
      this.loading = false
      if (this.reqIsSucceed(res)) {
        setMenuList(res.data.menus)
        if (data.defaultUrl && process.env.NODE_ENV !== 'development') location.href = data.defaultUrl
        else this.$router.push('/home')
      }
    }
  }
}
</script>

<style scoped lang="scss">
.loading-box {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100vw;
  height: 100vh;
  background: #999;
}
.loading-box img {
  width: 5%;
}
</style>
