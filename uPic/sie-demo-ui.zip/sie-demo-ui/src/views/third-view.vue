<template>
  <!-- 第三方网站展示组件 -->
  <iframe class="frame" :src="url"></iframe>
</template>
<script>
export default {
  data() {
    return {
      url: ''
    }
  },
  created() {
    this.url = this.$route.meta.url
  }
}
</script>
<style lang="scss" scoped>
.frame {
  //border: medium none;
  border: 1px solid rgb(228, 231, 235);
  height: 100%;
  width: 100%;
}
</style>
