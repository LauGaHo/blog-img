const { name } = require('./package')
const path = require('path')
const svgPath = path.resolve('src/icons');
const CompressionPlugin = require('compression-webpack-plugin')
const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer')

// 是否为生成环境
const IS_PROD = process.env.NODE_ENV !== 'development'

module.exports = {
  runtimeCompiler: true,
  configureWebpack: config => {
    let output = {
      // 把应用打包成 umd 库格式
      library: `${name}`,
      libraryTarget: "umd",
      jsonpFunction: `webpackJsonp_${name}`
    }

    if (IS_PROD) {
      // 为生产环境修改配置...
      config.mode = 'production'

      return {
        output,
        plugins: [
          new CompressionPlugin({
            test: /\.js$|\.html$|\.css/, //匹配文件名
            threshold: 10240, //对超过10k的数据进行压缩
            deleteOriginalAssets: false //是否删除原文件
          }),
          // 使用UglifyJsPlugin去掉console 可以略微降低文件大小
          new UglifyJsPlugin({
            uglifyOptions: {
              compress: {
                drop_debugger: true,
                drop_console: true,  //生产环境自动删除console, debugger
              },
              warnings: false,
            },
            sourceMap: false,
            parallel: true //使用多进程并行运行来提高构建速度。默认并发运行数：os.cpus().length - 1。
          }),
          // 模块分析插件
          // new BundleAnalyzerPlugin()
        ]
      }
    }
  },
  chainWebpack: config => {
    if (IS_PROD) {
      config.optimization.splitChunks({
        name: true,
        cacheGroups: {
          vendors: {
            name: `chunk-vendors`,
            test: /[\\/]node_modules[\\/]/,
            priority: -10,
            chunks: 'initial'
          },
          common: {
            name: `chunk-common`,
            minChunks: 2,
            priority: -20,
            chunks: 'all',
            reuseExistingChunk: true
          }
        }
      });
    } else {
      config.optimization.minimizer('terser').tap((args) => {
        args[0].terserOptions.compress.parallel = false
        return args
      })
    }
    // cdn 引入
    config.externals({
      vue: 'Vue',
      'element-ui': 'ELEMENT',
      echarts: 'echarts',
      'lodash': '_'
    });

    config.module
      .rule('svg')
      .exclude.add(svgPath)
      .end();

    config.module
      .rule('icons')
      .test(/\.svg$/)
      .include.add(svgPath)
      .end()
      .use('svg-sprite-loader')
      .loader('svg-sprite-loader')
      .options({
        symbolId: 'icon-[name]'
      });
  },
  devServer: {
    open: false,
    host: '0.0.0.0',
    port: 8088,
    https: false,
    hotOnly: false,
    headers: {
      'Access-Control-Allow-Origin': '*',
    }
  },
  // 设为false打包时不生成.map文件
  productionSourceMap: false,
  // 第三方插件配置
  pluginOptions: {
    CompressionWebpackPlugin: {
      test: /\.(js|css)(\?.*)?$/i, // 需要压缩的文件正则
      threshold: 10240, // 文件大小大于这个值时启用压缩
      deleteOriginalAssets: false // 压缩后保留原文件
    }
  },
  // css 配置
  css: {
    loaderOptions: {
      sass: {
        additionalData: `@import "@/styles/mixin.scss"; \n @import "@/styles/variables.scss"`
      },
      scss: {
        additionalData: `@import "@/styles/mixin.scss"; \n @import "@/styles/variables.scss";`
      },
      less: {
        lessOptions: {
          javascriptEnabled: true
        }
      }
    }
  }
}